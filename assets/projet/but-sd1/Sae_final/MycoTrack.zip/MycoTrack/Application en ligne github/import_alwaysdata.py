"""
import_alwaysdata.py  —  v16
Ce fichier sert à importer des fichiers Excel PCR dans la base de données MySQL.

Il fonctionne en 5 étapes :
    1. Lire le fichier Excel
    2. Nettoyer et préparer les données
    3. Deviner la série et l'année automatiquement
    4. Enregistrer les données dans la base
    5. Recalculer les classements A à I de chaque élevage

Utilisation depuis app.py :
    from import_alwaysdata import importer_fichier
    ok, message = importer_fichier(fichier, config_connexion)
"""

import re                     # pour chercher des patterns dans du texte
import uuid                   # pour générer des identifiants uniques
import pandas as pd           # pour lire et manipuler des tableaux
import mysql.connector        # pour se connecter à MySQL
from io import BytesIO        # pour lire un fichier en mémoire
from datetime import datetime # pour manipuler les dates


# Les 4 bactéries détectables dans les analyses PCR
# Chaque clé correspond à une colonne dans la base de données
LES_4_ESPECES = {
    "ct_mycoides":     "M. mycoïdes capri",
    "ct_agalactiae":   "M. agalactiae",
    "ct_capricolum":   "M. capricolum",
    "ct_putrefaciens": "M. putrefaciens",
}

# Correspondance entre numéro de mois et numéro de série
# Série 1 = janvier à avril, Série 2 = mai à août, Série 3 = septembre à décembre
MOIS_VERS_SERIE = {
    1: 1, 2: 1, 3: 1, 4: 1,
    5: 2, 6: 2, 7: 2, 8: 2,
    9: 3, 10: 3, 11: 3, 12: 3,
}

# Mots présents dans le nom de fichier pour deviner la série
# Ex: "mars_2023.xls" contient "mars" donc c'est la Série 1
MOTS_MOIS = [
    (["janv", "jan", "fevr", "fev", "mars", "mar", "avri", "apr"], 1),
    (["mai",  "may", "juin", "jun", "juil", "jul", "aout", "aug"], 2),
    (["sept", "sep", "octo", "oct", "nove", "nov", "dece", "dec"], 3),
]

# Noms possibles des colonnes dans les fichiers Excel selon les GDS
# Les variantes les plus spécifiques sont en premier pour éviter les confusions
NOMS_COLONNES = {
    "n_ede":            ["n° ede", "n°ede", "nede", "n ede"],
    "nom_exploitant":   ["nom exploitant"],
    "date_prel":        ["date de prélèvement", "date prélèvement", "date prélvmt", "date prelevement"],
    "matrice":          ["matrice"],
    "n_panier":         ["n° panier", "n°panier", "panier"],
    "n_identification": ["n° identification prélèvement", "n° identification plvt",
                         "n° éch lilco", "n° ech lilco", "n° identification p", "n° identification"],
    "ct_mycoides":      ["m. mycoïdes capri", "m mycoïdes capri", "m. mycoides capri",
                         "pcr m. mycoïdes capri", "m. mycoïdes", "m mycoïdes", "m. mycoides"],
    "ct_agalactiae":    ["m. agalactiae", "m agalactiae", "pcr m. agalactiae"],
    "ct_capricolum":    ["m. capricolum", "m capricolum", "m.  capricolum"],
    "ct_putrefaciens":  ["m. putrefaciens", "m putrefaciens"],
}


# ÉTAPE 1 — LIRE LE FICHIER EXCEL

def lire_excel(fichier) -> pd.DataFrame:
    # Ouvre un fichier Excel et retourne un tableau de données propre.
    # Détecte automatiquement quelle ligne est l'en-tête (cherche "N° EDE").

    # Récupérer les octets bruts du fichier selon son type
    if hasattr(fichier, "getvalue"):
        octets = fichier.getvalue()       # fichier uploadé via Streamlit
    elif hasattr(fichier, "read"):
        fichier.seek(0)                   # revenir au début du fichier
        octets = fichier.read()           # fichier ouvert en Python classique
    else:
        f = open(fichier, "rb")           # ouvrir le fichier depuis le disque
        octets = f.read()                 # lire tous les octets
        f.close()                         # refermer le fichier

    # Récupérer le nom du fichier pour savoir si c'est .xls ou .xlsx
    nom_fichier = getattr(fichier, "name", str(fichier)).lower()

    # Lire toutes les lignes brutes du fichier
    if nom_fichier.endswith(".xlsx"):
        # Pour les .xlsx on utilise openpyxl
        tableau_brut = pd.read_excel(BytesIO(octets), sheet_name=0, engine="openpyxl", header=None)
        toutes_les_lignes = tableau_brut.values.tolist() # convertir en liste Python
    else:
        # Pour les anciens .xls on utilise xlrd directement
        import xlrd
        classeur = xlrd.open_workbook(file_contents=octets) # ouvrir le classeur
        feuille  = classeur.sheet_by_index(0)               # prendre la première feuille

        toutes_les_lignes = [] # on va remplir cette liste ligne par ligne
        for numero_ligne in range(feuille.nrows):   # parcourir chaque ligne
            ligne_courante = []                     # liste des valeurs de cette ligne
            for numero_col in range(feuille.ncols): # parcourir chaque colonne
                cellule = feuille.cell(numero_ligne, numero_col) # lire la cellule
                if cellule.ctype == xlrd.XL_CELL_DATE:
                    try:
                        valeur = xlrd.xldate_as_datetime(cellule.value, classeur.datemode) # convertir en datetime
                    except Exception:
                        valeur = None # si la conversion échoue on met None
                elif cellule.ctype == xlrd.XL_CELL_EMPTY:
                    valeur = None # cellule vide
                else:
                    valeur = cellule.value # valeur normale (texte ou nombre)
                ligne_courante.append(valeur) # ajouter la valeur à la ligne
            toutes_les_lignes.append(ligne_courante) # ajouter la ligne complète

    # Vérifier que le fichier n'est pas vide
    if not toutes_les_lignes:
        raise ValueError("Le fichier est vide.")

    def normaliser_texte(valeur):
        # Convertit en minuscules et supprime le caractère °
        texte = str(valeur).strip().lower()
        texte = texte.replace("°", "")
        texte = texte.replace("  ", " ")
        return texte

    # Chercher la ligne qui contient "N° EDE" (c'est l'en-tête du tableau)
    numero_ligne_header = None # on cherche ce numéro
    for index, ligne in enumerate(toutes_les_lignes):
        for valeur in ligne:
            if valeur is not None:
                texte = normaliser_texte(valeur)
                if "n ede" in texte or "nede" in texte:
                    numero_ligne_header = index # on a trouvé l'en-tête
                    break
        if numero_ligne_header is not None:
            break # pas besoin de continuer

    if numero_ligne_header is None:
        raise ValueError("Colonne 'N° EDE' introuvable — ce fichier n'est pas un fichier PCR.")

    # Construire la liste des noms de colonnes depuis la ligne d'en-tête
    noms_colonnes = []
    for valeur in toutes_les_lignes[numero_ligne_header]:
        if valeur is not None and str(valeur).strip() != "":
            noms_colonnes.append(str(valeur).strip()) # nom de colonne normal
        else:
            noms_colonnes.append(None) # colonne sans nom, on l'ignorera

    nb_colonnes = len(noms_colonnes) # nombre total de colonnes

    # Récupérer les lignes de données (tout ce qui est après l'en-tête)
    lignes_donnees = []
    for ligne in toutes_les_lignes[numero_ligne_header + 1:]:
        ligne_completee = ligne + [None] * (nb_colonnes - len(ligne)) # remplir si trop courte
        lignes_donnees.append(ligne_completee[:nb_colonnes])          # couper si trop longue

    # Créer le DataFrame pandas avec les bonnes colonnes
    tableau = pd.DataFrame(lignes_donnees, columns=noms_colonnes)

    # Supprimer les colonnes sans nom
    colonnes_avec_nom = []
    for col in tableau.columns:
        if col: # ignorer None et ""
            colonnes_avec_nom.append(col)
    tableau = tableau[colonnes_avec_nom]

    return tableau # retourner le tableau propre


# ÉTAPE 2 — NETTOYER ET PRÉPARER LES DONNÉES

def enlever_accents(texte):
    # Convertit un texte en minuscules et enlève les accents pour comparer facilement
    texte = str(texte).strip().lower()
    remplacements = [("é","e"),("è","e"),("ê","e"),("à","a"),
                     ("ô","o"),("î","i"),("û","u"),("ï","i"),("ç","c")]
    for lettre_avec, lettre_sans in remplacements:
        texte = texte.replace(lettre_avec, lettre_sans) # remplacer chaque accent
    return texte


def trouver_colonne(tableau, nom_standard):
    # Cherche dans les colonnes du tableau celle qui correspond à nom_standard.
    # Retourne le vrai nom de la colonne trouvée, ou None si absente.

    variantes_possibles = NOMS_COLONNES.get(nom_standard, []) # liste des noms possibles

    # Construire un dictionnaire nom_normalisé → vrai_nom pour chaque colonne
    colonnes_normalisees = {}
    for col in tableau.columns:
        if col: # ignorer les colonnes sans nom
            colonnes_normalisees[enlever_accents(col)] = col

    # Passe 1 : chercher une correspondance exacte
    for variante in variantes_possibles:
        variante_normalisee = enlever_accents(variante)
        if variante_normalisee in colonnes_normalisees:
            return colonnes_normalisees[variante_normalisee] # trouvé exactement

    # Passe 2 : chercher si la variante est contenue dans le nom de colonne
    for variante in variantes_possibles:
        variante_normalisee = enlever_accents(variante)
        for col_norm, col_reel in colonnes_normalisees.items():
            if len(variante_normalisee) >= 6 and variante_normalisee in col_norm:
                return col_reel # trouvé partiellement

    return None # colonne absente du fichier


def nettoyer_ct(valeur):
    # Convertit une valeur Ct en nombre décimal.
    # None ou "neg" = résultat négatif (pas d'infection)
    # "32.5" = résultat positif (infection détectée)
    # Plus le Ct est bas, plus l'infection est forte (ex: Ct=25 fort, Ct=38 faible)

    if valeur is None:
        return None # pas de valeur = négatif
    if isinstance(valeur, float) and valeur != valeur:
        return None # NaN Python (float("nan") != float("nan") est toujours vrai)

    texte = str(valeur).strip().lower() # convertir en texte minuscule

    if texte in ("neg", "négatif", "negatif", "", "nan", "none", "-"):
        return None # valeurs qui signifient négatif

    if "mélange" in texte or "melange" in texte or "/" in texte:
        return None # valeurs de mélange, pas exploitables directement

    try:
        return float(texte.replace(",", ".")) # gérer les virgules françaises (32,5 → 32.5)
    except ValueError:
        return None # impossible à convertir = négatif


def nettoyer_ede(valeur):
    # Convertit un numéro EDE en chaîne de 8 chiffres.
    # Ex: 79345122.0 → "79345122" / "nan" → None

    if valeur is None:
        return None # pas de valeur = ignorer cette ligne

    texte = str(valeur).strip().lower()

    if texte in ("nan", "", "none"):
        return None # valeur vide = ignorer cette ligne

    try:
        return str(int(float(texte))).zfill(8) # zfill(8) ajoute des zéros à gauche si besoin
    except (ValueError, TypeError):
        return None # impossible à convertir = ignorer


def nettoyer_date(valeur):
    # Convertit une date en format texte "YYYY-MM-DD" pour MySQL.
    # Ex: datetime(2023, 3, 15) → "2023-03-15"

    if valeur is None:
        return None # pas de date

    if isinstance(valeur, datetime):
        return valeur.strftime("%Y-%m-%d") # déjà un objet datetime, juste formater

    try:
        return pd.to_datetime(valeur, dayfirst=True).strftime("%Y-%m-%d") # parser le texte
    except Exception:
        return None # impossible à parser


def preparer_donnees(tableau) -> list:
    # Parcourt le tableau ligne par ligne et retourne une liste de dictionnaires.
    # Chaque dictionnaire = un prélèvement avec ses informations nettoyées.
    # Les lignes sans numéro EDE valide sont ignorées.

    # Trouver chaque colonne standard dans le tableau
    colonnes = {}
    for nom_standard in NOMS_COLONNES:
        colonnes[nom_standard] = trouver_colonne(tableau, nom_standard) # chercher la colonne

    liste_prelevements = [] # on va remplir cette liste

    for index, ligne in tableau.iterrows(): # parcourir chaque ligne du tableau

        # Récupérer et nettoyer le numéro EDE (obligatoire)
        colonne_ede = colonnes.get("n_ede")              # nom de la colonne EDE dans ce fichier
        valeur_ede_brute = ligne[colonne_ede] if colonne_ede else None
        numero_ede = nettoyer_ede(valeur_ede_brute)      # nettoyer le numéro

        if not numero_ede:
            continue # ligne vide ou titre, on passe à la suivante

        def lire_valeur(nom_standard):
            # Lit la valeur d'une colonne et retourne None si vide ou NaN
            nom_col = colonnes.get(nom_standard) # trouver le vrai nom de la colonne
            if nom_col is None:
                return None # colonne absente du fichier
            valeur = ligne.get(nom_col) # lire la valeur
            if valeur is None or str(valeur).strip().lower() in ("nan", "none", ""):
                return None # valeur vide
            return valeur

        # Construire le dictionnaire pour ce prélèvement
        prelevement = {
            "n_ede":            numero_ede,                                                # EDE sur 8 chiffres
            "nom_exploitant":   str(lire_valeur("nom_exploitant") or "").strip() or None, # nom de l'éleveur
            "date_prel":        nettoyer_date(lire_valeur("date_prel")),                   # date du prélèvement
            "matrice":          str(lire_valeur("matrice") or "lait de tank").strip(),     # type de prélèvement
            "n_panier":         str(lire_valeur("n_panier") or "panier 1").strip(),        # numéro du panier
            "n_identification": str(lire_valeur("n_identification") or "").strip() or None, # ID labo
            "ct_mycoides":      nettoyer_ct(lire_valeur("ct_mycoides")),                   # Ct M. mycoïdes capri
            "ct_agalactiae":    nettoyer_ct(lire_valeur("ct_agalactiae")),                 # Ct M. agalactiae
            "ct_capricolum":    nettoyer_ct(lire_valeur("ct_capricolum")),                 # Ct M. capricolum
            "ct_putrefaciens":  nettoyer_ct(lire_valeur("ct_putrefaciens")),               # Ct M. putrefaciens
        }

        liste_prelevements.append(prelevement) # ajouter à la liste finale

    return liste_prelevements # retourner tous les prélèvements valides


# ÉTAPE 3 — DÉTECTER LA SÉRIE ET L'ANNÉE AUTOMATIQUEMENT

def detecter_serie_et_annee(liste_prelevements, nom_fichier=""):
    # Devine le numéro de série (1, 2 ou 3) et l'année
    # en regardant d'abord les dates dans le fichier, puis le nom du fichier.
    # Retourne (numero_serie, annee) ou (None, None) si impossible.

    # Priorité 1 : utiliser les dates dans les prélèvements (plus fiable)
    dates_trouvees = []
    for p in liste_prelevements:
        if p["date_prel"]: # ignorer les prélèvements sans date
            dates_trouvees.append(p["date_prel"])

    if dates_trouvees:
        toutes_les_annees = []
        tous_les_mois = []
        for date in dates_trouvees:
            toutes_les_annees.append(int(date[:4]))  # "2023-03-15" → 2023
            tous_les_mois.append(int(date[5:7]))     # "2023-03-15" → 3

        # Prendre l'année et le mois les plus fréquents
        annee_principale = max(set(toutes_les_annees), key=toutes_les_annees.count)
        mois_principal   = max(set(tous_les_mois),     key=tous_les_mois.count)

        numero_serie = MOIS_VERS_SERIE.get(mois_principal, 1) # convertir le mois en série
        return numero_serie, annee_principale

    # Priorité 2 : utiliser le nom du fichier si pas de dates
    nom_en_minuscules = nom_fichier.lower()

    # Chercher l'année dans le nom (ex: "2023" dans "Mycoplasmes_mars_2023.xls")
    annee_trouvee = None
    match_annee = re.search(r"20(\d{2})", nom_en_minuscules) # chercher "20XX"
    if match_annee:
        annee_trouvee = int("20" + match_annee.group(1)) # "23" → 2023

    # Chercher le mois dans le nom
    for liste_mots, numero_serie in MOTS_MOIS:
        for mot in liste_mots:
            if mot in nom_en_minuscules:
                return numero_serie, annee_trouvee # trouvé

    return 1, annee_trouvee # Série 1 par défaut si rien trouvé


# ÉTAPE 4 — ENREGISTRER EN BASE DE DONNÉES

def inserer_plusieurs_lignes(curseur, requete_base, lignes_a_inserer):
    # Insère plusieurs lignes en une seule requête SQL (beaucoup plus rapide).
    # Ex: INSERT INTO table (col1, col2) VALUES (%s,%s), (%s,%s), (%s,%s)
    # Retourne l'ID de la première ligne insérée.

    if not lignes_a_inserer:
        return None # rien à insérer

    nb_colonnes = len(lignes_a_inserer[0])                               # nombre de colonnes par ligne
    placeholder_une_ligne = "(" + ", ".join(["%s"] * nb_colonnes) + ")" # ex: (%s, %s, %s)

    tous_les_placeholders = []
    for i in range(len(lignes_a_inserer)):              # répéter le placeholder pour chaque ligne
        tous_les_placeholders.append(placeholder_une_ligne)

    requete_complete = requete_base + ", ".join(tous_les_placeholders) # construire la requête complète

    toutes_les_valeurs = [] # aplatir la liste de tuples en une seule liste
    for ligne in lignes_a_inserer:
        for valeur in ligne:
            toutes_les_valeurs.append(valeur)

    curseur.execute(requete_complete, toutes_les_valeurs) # exécuter la requête
    return curseur.lastrowid                              # retourner le 1er ID inséré


def enregistrer_en_base(connexion, liste_prelevements, numero_serie, annee):
    # Enregistre tous les prélèvements dans la base de données en 5 sous-étapes :
    # 4.1 Créer/récupérer la série
    # 4.2 Créer les nouveaux élevages
    # 4.3 Créer les nouveaux EDE
    # 4.4 Créer les résultats PCR
    # 4.5 Créer les prélèvements

    curseur = connexion.cursor() # créer un curseur pour exécuter les requêtes

    # 4.1 — SÉRIE
    # Créer la série si elle n'existe pas, sinon ne rien faire (INSERT IGNORE)
    curseur.execute(
        "INSERT IGNORE INTO serie (numero_serie, annee) VALUES (%s, %s)",
        (numero_serie, annee)
    )
    connexion.commit() # valider l'insertion

    # Récupérer l'ID de la série
    curseur.execute(
        "SELECT id_serie FROM serie WHERE numero_serie = %s AND annee = %s",
        (numero_serie, annee)
    )
    id_serie = curseur.fetchall()[0][0] # fetchall() pour éviter les bugs de curseur non vidé

    # 4.2 — ÉLEVAGES
    # Récupérer la liste de tous les EDE uniques dans ce fichier
    tous_les_edes = []
    for p in liste_prelevements:
        if p["n_ede"] not in tous_les_edes: # éviter les doublons
            tous_les_edes.append(p["n_ede"])

    # Vérifier lesquels existent déjà en base
    placeholders_edes = ", ".join(["%s"] * len(tous_les_edes)) # autant de %s que d'EDE
    curseur.execute(
        f"SELECT num_ede, id_elevage FROM ede WHERE num_ede IN ({placeholders_edes})",
        tous_les_edes
    )
    edes_deja_en_base = dict(curseur.fetchall()) # dictionnaire {num_ede: id_elevage}

    # Garder seulement les EDE qu'on n'a pas encore en base
    edes_nouveaux = []
    for ede in tous_les_edes:
        if ede not in edes_deja_en_base:
            edes_nouveaux.append(ede)

    if edes_nouveaux:
        # Trouver le nom de l'exploitant pour chaque nouvel EDE
        nom_par_ede = {}
        for p in liste_prelevements:
            if p["n_ede"] in edes_nouveaux and p["n_ede"] not in nom_par_ede:
                nom_par_ede[p["n_ede"]] = p["nom_exploitant"] # prendre le premier nom trouvé

        # Préparer les lignes à insérer pour la table elevage
        lignes_elevage = []
        for ede in edes_nouveaux:
            lignes_elevage.append((nom_par_ede.get(ede), None)) # nom + code_classement vide

        # Insérer tous les nouveaux élevages en 1 requête
        inserer_plusieurs_lignes(
            curseur,
            "INSERT INTO elevage (nom_exploitant, code_classement) VALUES ",
            lignes_elevage
        )
        connexion.commit() # valider

        # 4.3 — EDE
        # Récupérer les IDs des élevages qu'on vient de créer
        curseur.execute(
            "SELECT id_elevage FROM elevage ORDER BY id_elevage DESC LIMIT %s",
            (len(edes_nouveaux),)
        )
        ids_elev_crees = []
        for ligne in curseur.fetchall():
            ids_elev_crees.append(ligne[0]) # récupérer chaque ID
        ids_elev_crees = ids_elev_crees[::-1] # remettre dans l'ordre chronologique

        # Associer chaque EDE à son id_elevage dans notre dictionnaire
        for i in range(len(edes_nouveaux)):
            ede = edes_nouveaux[i]
            edes_deja_en_base[ede] = ids_elev_crees[i]

        # Décomposer chaque EDE en ses composants géographiques
        # Format EDE : 8 chiffres = département(2) + commune(3) + ordre(3)
        # Ex: "79345122" → dept="79", commune="345", ordre="122"
        lignes_ede = []
        for ede in edes_nouveaux:
            code_dept    = ede[0:2]               # 2 premiers chiffres = département
            code_commune = ede[2:5]               # 3 suivants = commune
            num_ordre    = ede[5:8]               # 3 derniers = numéro d'ordre
            id_elev      = edes_deja_en_base[ede] # ID de l'élevage associé
            lignes_ede.append((ede, code_dept, code_commune, num_ordre, id_elev))

        # Insérer tous les EDE en 1 requête
        inserer_plusieurs_lignes(
            curseur,
            "INSERT IGNORE INTO ede "
            "(num_ede, code_departement, code_commune, num_ordre, id_elevage) VALUES ",
            lignes_ede
        )
        connexion.commit() # valider

    # 4.4 — RÉSULTATS PCR
    # Préparer les 4 valeurs Ct pour chaque prélèvement
    lignes_resultats = []
    for p in liste_prelevements:
        lignes_resultats.append((
            p["ct_mycoides"],     # Ct M. mycoïdes capri (None si négatif)
            p["ct_agalactiae"],   # Ct M. agalactiae (None si négatif)
            p["ct_capricolum"],   # Ct M. capricolum (None si négatif)
            p["ct_putrefaciens"], # Ct M. putrefaciens (None si négatif)
            "actuelle"            # type d'analyse
        ))

    # Insérer tous les résultats en 1 requête et récupérer l'ID du premier
    id_premier_resultat = inserer_plusieurs_lignes(
        curseur,
        "INSERT INTO resultat_pcr "
        "(ct_mycoides, ct_agalactiae, ct_capricolum, ct_putrefaciens, type_analyse) VALUES ",
        lignes_resultats
    )
    connexion.commit() # valider

    # MySQL garantit que les IDs sont consécutifs pour un INSERT multi-lignes
    ids_resultats = list(range(id_premier_resultat, id_premier_resultat + len(liste_prelevements)))

    # 4.5 — PRÉLÈVEMENTS
    lignes_prelevements = []
    for i in range(len(liste_prelevements)):
        p = liste_prelevements[i] # prélèvement courant

        # Si pas d'ID labo dans le fichier, en générer un unique automatiquement
        num_prelev = p["n_identification"]
        if not num_prelev:
            num_prelev = "AUTO_" + str(uuid.uuid4())[:15] # ex: "AUTO_a3f8b2c1d4e5f67"

        lignes_prelevements.append((
            num_prelev,        # numéro unique du prélèvement
            p["date_prel"],    # date du prélèvement
            p["matrice"],      # type de prélèvement
            p["n_panier"],     # numéro du panier
            num_prelev,        # num_ech_LILco = même valeur
            p["n_ede"],        # EDE de l'élevage concerné
            ids_resultats[i],  # ID du résultat PCR correspondant
            id_serie           # ID de la série d'analyse
        ))

    # INSERT IGNORE = ignorer si le num_prelevement existe déjà (évite les doublons)
    inserer_plusieurs_lignes(
        curseur,
        "INSERT IGNORE INTO prelevement "
        "(num_prelevement, date_prelevement, matrice, num_panier, "
        " num_ech_LILco, num_ede, id_resultat, id_serie) VALUES ",
        lignes_prelevements
    )
    connexion.commit() # valider toutes les insertions
    curseur.close()    # fermer le curseur

    return len(liste_prelevements) # retourner le nombre de prélèvements traités


# ÉTAPE 5 — RECALCULER LES CLASSEMENTS A À I

def recalculer_classements(connexion):
    # Calcule le classement (A à I) de chaque élevage selon ses 6 derniers résultats.
    #
    # Règles de classement :
    # A = 6 derniers tous négatifs (élevage sain de longue date)
    # B = 6 derniers tous positifs (élevage très infecté)
    # C = dernier fortement positif + 5 précédents négatifs (nouvelle infection)
    # D = 3 à 5 positifs sur 6, tous forts (Ct < 35)
    # E = 3 à 5 positifs sur 6, pas tous forts
    # F = 1 à 2 positifs sur 6, tous forts (Ct < 35)
    # G = 1 à 2 positifs sur 6, pas tous forts
    # H = 4 derniers tous négatifs (en cours d'assainissement)
    # I = moins de 4 résultats ou situation indéfinie

    def est_negatif(ct):
        return ct is None or float(ct) >= 40 # Ct >= 40 = négatif

    def est_positif(ct):
        return ct is not None and float(ct) < 40 # Ct < 40 = positif

    def est_fortement_positif(ct):
        return ct is not None and float(ct) < 35 # Ct < 35 = fortement positif

    def trouver_ct_principal(ct_mycoides, ct_agalactiae, ct_capricolum, ct_putrefaciens):
        # Parmi les 4 valeurs Ct, retourne la plus basse (la plus critique).
        # Si toutes sont négatives, retourne None.
        valeurs_positives = []
        for ct in (ct_mycoides, ct_agalactiae, ct_capricolum, ct_putrefaciens):
            if ct is not None and float(ct) < 40:
                valeurs_positives.append(float(ct)) # garder seulement les positifs
        if valeurs_positives:
            return min(valeurs_positives) # le plus bas = le pire
        return None

    def calculer_classement(historique_cts):
        # Prend la liste des Ct dans l'ordre chronologique et retourne le code A-I.

        if len(historique_cts) < 1:
            return "I" # pas assez de données

        six_derniers    = historique_cts[-6:] # les 6 derniers résultats
        quatre_derniers = historique_cts[-4:] # les 4 derniers résultats

        if len(six_derniers) >= 6:

            # Vérifier si tous les 6 derniers sont négatifs
            tous_negatifs = True
            for ct in six_derniers:
                if not est_negatif(ct):
                    tous_negatifs = False
            if tous_negatifs:
                return "A" # sain

            # Vérifier si tous les 6 derniers sont positifs
            tous_positifs = True
            for ct in six_derniers:
                if not est_positif(ct):
                    tous_positifs = False
            if tous_positifs:
                return "B" # très infecté

            # Vérifier si le dernier est fortement positif et les 5 précédents négatifs
            precedents_negatifs = True
            for ct in six_derniers[:-1]: # tous sauf le dernier
                if not est_negatif(ct):
                    precedents_negatifs = False
            if est_fortement_positif(six_derniers[-1]) and precedents_negatifs:
                return "C" # nouvelle infection

            # Compter les positifs parmi les 6 derniers
            nb_positifs = 0
            for ct in six_derniers:
                if est_positif(ct):
                    nb_positifs = nb_positifs + 1

            # Vérifier si tous les positifs sont fortement positifs
            tous_forts = True
            for ct in six_derniers:
                if est_positif(ct) and not est_fortement_positif(ct):
                    tous_forts = False

            if 3 <= nb_positifs <= 5 and tous_forts:
                return "D" # 3 à 5 fortement positifs sur 6
            if 3 <= nb_positifs <= 5:
                return "E" # 3 à 5 positifs sur 6, pas tous forts
            if 1 <= nb_positifs <= 2 and tous_forts:
                return "F" # 1 à 2 fortement positifs sur 6
            if 1 <= nb_positifs <= 2:
                return "G" # 1 à 2 positifs sur 6, pas tous forts

        # Vérifier si les 4 derniers sont tous négatifs
        if len(quatre_derniers) >= 4:
            quatre_negatifs = True
            for ct in quatre_derniers:
                if not est_negatif(ct):
                    quatre_negatifs = False
            if quatre_negatifs:
                return "H" # en voie d'assainissement

        return "I" # situation indéfinie

    # Récupérer tous les résultats depuis la base de données
    curseur = connexion.cursor()
    curseur.execute("""
        SELECT
            el.id_elevage,
            r.ct_mycoides,
            r.ct_agalactiae,
            r.ct_capricolum,
            r.ct_putrefaciens
        FROM elevage el
        JOIN ede ed         ON el.id_elevage  = ed.id_elevage
        JOIN prelevement p  ON ed.num_ede      = p.num_ede
        JOIN resultat_pcr r ON p.id_resultat   = r.id_resultat
        JOIN serie s        ON p.id_serie      = s.id_serie
        ORDER BY el.id_elevage, s.annee, s.numero_serie, p.date_prelevement
    """)
    tous_les_resultats = curseur.fetchall() # lire tous les résultats d'un coup

    # Regrouper les Ct par élevage dans un dictionnaire
    historique_par_elevage = {} # dictionnaire {id_elevage: [ct1, ct2, ct3, ...]}
    for id_elev, ct_m, ct_a, ct_c, ct_p in tous_les_resultats:
        ct_ce_prelev = trouver_ct_principal(ct_m, ct_a, ct_c, ct_p) # le Ct le plus critique
        if id_elev not in historique_par_elevage:
            historique_par_elevage[id_elev] = [] # initialiser la liste pour cet élevage
        historique_par_elevage[id_elev].append(ct_ce_prelev) # ajouter à l'historique

    # Calculer et enregistrer le classement de chaque élevage
    for id_elev, historique in historique_par_elevage.items():
        code_classement = calculer_classement(historique) # calculer A, B, C... I
        curseur.execute(
            "UPDATE elevage SET code_classement = %s WHERE id_elevage = %s",
            (code_classement, id_elev)
        )

    connexion.commit() # sauvegarder tous les changements
    curseur.close()    # fermer le curseur


# FONCTION PRINCIPALE — appelée depuis app.py

def importer_fichier(fichier, config_db: dict,
                     numero_serie: int = None,
                     annee: int = None) -> tuple:
    # Fonction principale : importe un fichier Excel dans la base de données.
    # C'est la seule fonction qu'on appelle depuis app.py.
    #
    # Paramètres :
    #   fichier          : fichier Excel uploadé par Streamlit
    #   config_db        : dictionnaire avec les infos de connexion MySQL
    #   numero_serie     : numéro de série (1, 2 ou 3) — None = détecté automatiquement
    #   annee            : année du prélèvement — None = détectée automatiquement
    #
    # Retour :
    #   (True,  "396 prélèvements importés (Série 1 — 2025)") en cas de succès
    #   (False, "Message d'erreur explicatif")                  en cas d'échec

    nom_fichier = getattr(fichier, "name", str(fichier)) # récupérer le nom du fichier

    # Étape 1 : Lire le fichier Excel
    try:
        tableau = lire_excel(fichier) # lire et retourner un DataFrame propre
    except Exception as erreur:
        return False, f"Impossible de lire le fichier : {erreur}"

    if tableau.empty:
        return False, "Le fichier ne contient aucune donnée."

    # Étape 2 : Nettoyer et préparer les données
    try:
        liste_prelevements = preparer_donnees(tableau)
    except Exception as erreur:
        return False, f"Erreur lors du traitement des données : {erreur}"

    if not liste_prelevements:
        return False, "Aucune ligne valide trouvée (vérifiez que le fichier contient des N° EDE)."

    # Étape 3 : Détecter la série et l'année si non renseignées
    if numero_serie is None or annee is None:
        serie_detectee, annee_detectee = detecter_serie_et_annee(liste_prelevements, nom_fichier)
        numero_serie = numero_serie or serie_detectee or 1    # utiliser la valeur détectée ou 1
        annee        = annee        or annee_detectee or 2026 # utiliser la valeur détectée ou 2026

    # Étape 4 : Se connecter à la base de données
    try:
        connexion = mysql.connector.connect(**config_db) # ouvrir la connexion
    except mysql.connector.Error as erreur:
        return False, f"Connexion impossible à la base de données : {erreur}"

    # Étape 4 : Insérer les données (le recalcul des classements est fait dans app.py après tous les imports)
    try:
        nb_inseres = enregistrer_en_base(connexion, liste_prelevements, numero_serie, annee)
        connexion.close() # fermer proprement la connexion
    except mysql.connector.Error as erreur:
        try:
            connexion.rollback() # annuler les changements partiels
            connexion.close()
        except Exception:
            pass
        return False, f"Erreur MySQL pendant l'import : {erreur}"
    except Exception as erreur:
        try:
            connexion.close()
        except Exception:
            pass
        return False, f"Erreur inattendue : {erreur}"

    # Succès !
    return True, f"{nb_inseres} prélèvements importés (Série {numero_serie} — {annee})."
