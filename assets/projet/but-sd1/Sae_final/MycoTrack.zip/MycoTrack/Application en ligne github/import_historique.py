"""
import_historique.py
Ce fichier importe les données PCR historiques (avant 2023) depuis deux fichiers Excel
au format pivot : une ligne par élevage, une colonne par série/année.

Les deux fichiers attendus :
    - fichier Mycoïdes   : colonnes "N° EDE" + "AAAA_serieN.PCR M mycoïdes"
    - fichier Agalactiae : colonnes "N° EDE" + "AAAA_serieN.PCR M agalactiae"

Utilisation depuis app.py :
    from import_historique import importer_historique
    ok, message = importer_historique(fichier_mycoides, fichier_agalactiae, config_db)
"""

import re
import uuid
import pandas as pd
import mysql.connector
from io import BytesIO


def lire_fichier_pivot(fichier):
    # Lit un fichier Excel au format pivot et retourne un DataFrame propre.
    # Détecte automatiquement .xls ou .xlsx.

    if hasattr(fichier, "getvalue"):
        octets = fichier.getvalue()    # fichier Streamlit
    elif hasattr(fichier, "read"):
        fichier.seek(0)
        octets = fichier.read()        # fichier Python classique
    else:
        f = open(fichier, "rb")
        octets = f.read()
        f.close()

    nom = getattr(fichier, "name", str(fichier)).lower()

    if nom.endswith(".xlsx"):
        df = pd.read_excel(BytesIO(octets), sheet_name=0, engine="openpyxl", header=0)
    else:
        df = pd.read_excel(BytesIO(octets), sheet_name=0, engine="xlrd", header=0)

    return df


def nettoyer_ede(valeur):
    # Convertit un EDE en chaîne de 8 chiffres. Retourne None si invalide.
    if valeur is None:
        return None
    texte = str(valeur).strip().lower()
    if texte in ("nan", "", "none"):
        return None
    try:
        return str(int(float(texte))).zfill(8)  # ex: 79001040.0 → "79001040"
    except (ValueError, TypeError):
        return None


def nettoyer_ct(valeur):
    # Convertit une valeur Ct en float.
    # None = cellule vide (pas de test effectué).
    # 40.0 = négatif (Ct >= 40) — on stocke 40.0 et pas NULL
    #        pour que is_pos() puisse le détecter correctement.
    # valeur réelle = positif (Ct < 40).
    if valeur is None:
        return None
    if isinstance(valeur, float) and valeur != valeur:
        return None  # NaN pandas = cellule vide
    texte = str(valeur).strip().lower()
    if texte in ("", "nan", "none", "-"):
        return None  # pas de test effectué
    if texte in ("neg", "négatif", "negatif"):
        return 40.0  # négatif explicite
    try:
        ct = float(texte.replace(",", "."))
        return max(ct, 40.0) if ct >= 40 else ct
    except ValueError:
        return None


def parser_colonne_serie(nom_colonne):
    # Extrait l'année et le numéro de série depuis un nom de colonne.
    # Ex: "2020_serie3.PCR M mycoïdes" → (2020, 3)
    # Retourne (None, None) si le format ne correspond pas.

    match = re.search(r"(\d{4})_serie(\d)", nom_colonne.lower())
    if match:
        annee = int(match.group(1))
        serie = int(match.group(2))
        return annee, serie
    return None, None


def trouver_colonne_ede(df):
    # Cherche la colonne EDE dans le DataFrame (peut s'appeler "N° EDE", "N°EDE", etc.)
    for col in df.columns:
        col_norm = str(col).strip().lower().replace("°", "").replace(" ", "")
        if "nede" in col_norm or "n ede" in col_norm.replace("", " "):
            return col
        if col_norm == "nede" or col_norm == "n°ede":
            return col
    # Deuxième passe plus large
    for col in df.columns:
        col_norm = str(col).strip().lower()
        if "ede" in col_norm and "serie" not in col_norm and "pcr" not in col_norm:
            return col
    return None


def fusionner_fichiers(df_mycoides, df_agalactiae):
    # Fusionne les deux fichiers pivot sur le N° EDE.
    # Un des deux peut être un DataFrame vide (si un seul fichier uploadé).
    # Retourne une liste de dictionnaires prêts à insérer en base.

    # Vérifier si les DataFrames sont vides (un seul fichier fourni)
    mycoides_vide    = df_mycoides.empty    or len(df_mycoides.columns) <= 1
    agalactiae_vide  = df_agalactiae.empty  or len(df_agalactiae.columns) <= 1

    col_ede_m = trouver_colonne_ede(df_mycoides)    if not mycoides_vide   else None
    col_ede_a = trouver_colonne_ede(df_agalactiae)  if not agalactiae_vide else None

    # Si les deux sont vides ou sans colonne EDE reconnue → erreur
    if col_ede_m is None and col_ede_a is None:
        raise ValueError("Colonne EDE introuvable dans les fichiers fournis.")

    # Nettoyer les EDE dans les fichiers disponibles
    df_mycoides   = df_mycoides.copy()
    df_agalactiae = df_agalactiae.copy()
    if col_ede_m:
        df_mycoides["_ede"]   = df_mycoides[col_ede_m].apply(nettoyer_ede)
        df_mycoides = df_mycoides[df_mycoides["_ede"].notna()].copy()
    else:
        df_mycoides = df_mycoides.iloc[0:0].copy()  # vider proprement
        df_mycoides["_ede"] = []
    if col_ede_a:
        df_agalactiae["_ede"] = df_agalactiae[col_ede_a].apply(nettoyer_ede)
        df_agalactiae = df_agalactiae[df_agalactiae["_ede"].notna()].copy()
    else:
        df_agalactiae = df_agalactiae.iloc[0:0].copy()
        df_agalactiae["_ede"] = []

    # Identifier les colonnes de séries dans chaque fichier
    # Format attendu : "AAAA_serieN.PCR M ..."
    cols_mycoides = []
    for col in df_mycoides.columns:
        annee, serie = parser_colonne_serie(str(col))
        if annee is not None:
            cols_mycoides.append((col, annee, serie))

    cols_agalactiae = []
    for col in df_agalactiae.columns:
        annee, serie = parser_colonne_serie(str(col))
        if annee is not None:
            cols_agalactiae.append((col, annee, serie))

    if not cols_mycoides and not cols_agalactiae:
        raise ValueError("Aucune colonne série/année trouvée dans les fichiers.")

    # Construire un index EDE → ligne pour l'agalactiae (pour la fusion)
    index_agalactiae = {}
    for _, ligne in df_agalactiae.iterrows():
        ede = ligne["_ede"]
        if ede not in index_agalactiae:
            index_agalactiae[ede] = ligne  # garder la première ligne si doublon

    # Rassembler tous les couples (annee, serie) présents dans les deux fichiers
    tous_les_couples = set()
    for _, annee, serie in cols_mycoides:
        tous_les_couples.add((annee, serie))
    for _, annee, serie in cols_agalactiae:
        tous_les_couples.add((annee, serie))

    # Construire un index colonne → (annee, serie) pour mycoïdes
    index_cols_m = {}
    for col, annee, serie in cols_mycoides:
        index_cols_m[(annee, serie)] = col

    # Construire un index colonne → (annee, serie) pour agalactiae
    index_cols_a = {}
    for col, annee, serie in cols_agalactiae:
        index_cols_a[(annee, serie)] = col

    # Parcourir toutes les lignes mycoïdes et tous les couples annee/serie
    liste_resultats = []

    for _, ligne_m in df_mycoides.iterrows():
        ede = ligne_m["_ede"]
        ligne_a = index_agalactiae.get(ede)  # ligne agalactiae correspondante (peut être None)

        for (annee, serie) in tous_les_couples:
            # Lire le Ct mycoïdes pour ce couple
            col_m = index_cols_m.get((annee, serie))
            ct_mycoides = None
            if col_m is not None:
                ct_mycoides = nettoyer_ct(ligne_m.get(col_m))

            # Lire le Ct agalactiae pour ce couple
            col_a = index_cols_a.get((annee, serie))
            ct_agalactiae = None
            if col_a is not None and ligne_a is not None:
                ct_agalactiae = nettoyer_ct(ligne_a.get(col_a))

            # On insère seulement si au moins un des deux Ct est renseigné
            if ct_mycoides is not None or ct_agalactiae is not None:
                liste_resultats.append({
                    "n_ede":          ede,
                    "annee":          annee,
                    "serie":          serie,
                    "ct_mycoides":    ct_mycoides,
                    "ct_agalactiae":  ct_agalactiae,
                    "ct_capricolum":  None,   # pas de données avant 2023
                    "ct_putrefaciens": None,  # pas de données avant 2023
                })

    # Ajouter aussi les EDE présents seulement dans agalactiae (pas dans mycoïdes)
    edes_mycoides = set(df_mycoides["_ede"].tolist())
    for _, ligne_a in df_agalactiae.iterrows():
        ede = ligne_a["_ede"]
        if ede in edes_mycoides:
            continue  # déjà traité dans la boucle précédente

        for col_a, annee, serie in cols_agalactiae:
            ct_agalactiae = nettoyer_ct(ligne_a.get(col_a))
            if ct_agalactiae is not None:
                liste_resultats.append({
                    "n_ede":           ede,
                    "annee":           annee,
                    "serie":           serie,
                    "ct_mycoides":     None,
                    "ct_agalactiae":   ct_agalactiae,
                    "ct_capricolum":   None,
                    "ct_putrefaciens": None,
                })

    return liste_resultats


def inserer_plusieurs_lignes(curseur, requete_base, lignes):
    # Insère plusieurs lignes en une seule requête SQL.
    # Retourne l'ID de la première ligne insérée.
    if not lignes:
        return None
    nb_col = len(lignes[0])
    placeholder = "(" + ", ".join(["%s"] * nb_col) + ")"
    tous_placeholders = []
    for i in range(len(lignes)):
        tous_placeholders.append(placeholder)
    requete = requete_base + ", ".join(tous_placeholders)
    valeurs = []
    for ligne in lignes:
        for val in ligne:
            valeurs.append(val)
    curseur.execute(requete, valeurs)
    return curseur.lastrowid


def enregistrer_historique(connexion, liste_resultats):
    # Enregistre les données historiques dans la base.
    # Crée les séries, élevages, EDE, résultats PCR et prélèvements manquants.

    curseur = connexion.cursor()

    # Récupérer tous les couples (annee, serie) uniques
    couples_series = set()
    for r in liste_resultats:
        couples_series.add((r["annee"], r["serie"]))

    # Créer toutes les séries manquantes et mémoriser leurs IDs
    ids_series = {}
    for annee, serie in couples_series:
        curseur.execute(
            "INSERT IGNORE INTO serie (numero_serie, annee) VALUES (%s, %s)",
            (serie, annee)
        )
        connexion.commit()
        curseur.execute(
            "SELECT id_serie FROM serie WHERE numero_serie = %s AND annee = %s",
            (serie, annee)
        )
        id_serie = curseur.fetchall()[0][0]
        ids_series[(annee, serie)] = id_serie

    # Récupérer tous les EDE uniques dans les données
    tous_les_edes = []
    for r in liste_resultats:
        if r["n_ede"] not in tous_les_edes:
            tous_les_edes.append(r["n_ede"])

    # Vérifier lesquels existent déjà en base
    placeholders = ", ".join(["%s"] * len(tous_les_edes))
    curseur.execute(
        f"SELECT num_ede, id_elevage FROM ede WHERE num_ede IN ({placeholders})",
        tous_les_edes
    )
    edes_en_base = dict(curseur.fetchall())  # {num_ede: id_elevage}

    # Créer les élevages et EDE manquants
    edes_nouveaux = []
    for ede in tous_les_edes:
        if ede not in edes_en_base:
            edes_nouveaux.append(ede)

    if edes_nouveaux:
        # Insérer les nouveaux élevages (sans nom car les fichiers historiques n'en ont pas)
        lignes_elevage = []
        for ede in edes_nouveaux:
            lignes_elevage.append((None, None))  # nom_exploitant et code_classement vides

        inserer_plusieurs_lignes(
            curseur,
            "INSERT INTO elevage (nom_exploitant, code_classement) VALUES ",
            lignes_elevage
        )
        connexion.commit()

        # Récupérer les IDs des élevages créés
        curseur.execute(
            "SELECT id_elevage FROM elevage ORDER BY id_elevage DESC LIMIT %s",
            (len(edes_nouveaux),)
        )
        ids_crees = []
        for ligne in curseur.fetchall():
            ids_crees.append(ligne[0])
        ids_crees = ids_crees[::-1]  # remettre dans l'ordre

        # Associer chaque EDE à son id_elevage
        for i in range(len(edes_nouveaux)):
            edes_en_base[edes_nouveaux[i]] = ids_crees[i]

        # Insérer les EDE avec leurs composants géographiques
        lignes_ede = []
        for ede in edes_nouveaux:
            code_dept    = ede[0:2]              # département
            code_commune = ede[2:5]              # commune
            num_ordre    = ede[5:8]              # numéro d'ordre
            id_elev      = edes_en_base[ede]
            lignes_ede.append((ede, code_dept, code_commune, num_ordre, id_elev))

        inserer_plusieurs_lignes(
            curseur,
            "INSERT IGNORE INTO ede "
            "(num_ede, code_departement, code_commune, num_ordre, id_elevage) VALUES ",
            lignes_ede
        )
        connexion.commit()

    # Insérer les résultats PCR
    lignes_resultats_pcr = []
    for r in liste_resultats:
        lignes_resultats_pcr.append((
            r["ct_mycoides"],
            r["ct_agalactiae"],
            r["ct_capricolum"],
            r["ct_putrefaciens"],
            "historique"  # type_analyse = historique pour distinguer des données actuelles
        ))

    id_premier = inserer_plusieurs_lignes(
        curseur,
        "INSERT INTO resultat_pcr "
        "(ct_mycoides, ct_agalactiae, ct_capricolum, ct_putrefaciens, type_analyse) VALUES ",
        lignes_resultats_pcr
    )
    connexion.commit()

    # Calculer les IDs de tous les résultats insérés (MySQL garantit la consécutivité)
    ids_resultats = list(range(id_premier, id_premier + len(liste_resultats)))

    # Insérer les prélèvements
    lignes_prelevements = []
    for i in range(len(liste_resultats)):
        r = liste_resultats[i]
        num_prelev  = "HIST_" + str(uuid.uuid4())[:15]  # ID unique généré automatiquement
        id_serie    = ids_series[(r["annee"], r["serie"])]
        lignes_prelevements.append((
            num_prelev,   # num_prelevement
            None,         # date_prelevement inconnue pour les données historiques
            "lait de tank",
            "panier 1",
            num_prelev,   # num_ech_LILco
            r["n_ede"],
            ids_resultats[i],
            id_serie
        ))

    inserer_plusieurs_lignes(
        curseur,
        "INSERT IGNORE INTO prelevement "
        "(num_prelevement, date_prelevement, matrice, num_panier, "
        " num_ech_LILco, num_ede, id_resultat, id_serie) VALUES ",
        lignes_prelevements
    )
    connexion.commit()
    curseur.close()

    return len(liste_resultats)


def importer_historique(fichier_mycoides, fichier_agalactiae, config_db: dict) -> tuple:
    # Fonction principale appelée depuis app.py.
    # Au moins un des deux fichiers doit être fourni (l'autre peut être None).
    #
    # Retour :
    #   (True, "X résultats importés") ou (False, "Message d'erreur")

    if fichier_mycoides is None and fichier_agalactiae is None:
        return False, "Aucun fichier fourni. Uploadez au moins un fichier."

    # Étape 1 : lire les fichiers disponibles
    df_m = None
    df_a = None

    if fichier_mycoides is not None:
        try:
            df_m = lire_fichier_pivot(fichier_mycoides)
        except Exception as e:
            return False, f"Impossible de lire le fichier Mycoïdes : {e}"

    if fichier_agalactiae is not None:
        try:
            df_a = lire_fichier_pivot(fichier_agalactiae)
        except Exception as e:
            return False, f"Impossible de lire le fichier Agalactiae : {e}"

    # Si un seul fichier : créer un DataFrame vide pour l'autre
    import pandas as pd
    if df_m is None:
        df_m = pd.DataFrame(columns=["N° EDE"])
    if df_a is None:
        df_a = pd.DataFrame(columns=["N° EDE"])

    # Étape 2 : fusionner et préparer les données
    try:
        liste_resultats = fusionner_fichiers(df_m, df_a)
    except Exception as e:
        return False, f"Erreur lors de la préparation des données : {e}"

    if not liste_resultats:
        return False, "Aucune donnée valide trouvée dans les fichiers."

    # Étape 3 : connexion à la base
    try:
        connexion = mysql.connector.connect(**config_db)
    except mysql.connector.Error as e:
        return False, f"Connexion impossible à la base de données : {e}"

    # Étape 4 : insérer en base
    try:
        nb = enregistrer_historique(connexion, liste_resultats)
        connexion.close()
    except mysql.connector.Error as e:
        try:
            connexion.rollback()
            connexion.close()
        except Exception:
            pass
        return False, f"Erreur MySQL pendant l'import historique : {e}"
    except Exception as e:
        try:
            connexion.close()
        except Exception:
            pass
        return False, f"Erreur inattendue : {e}"

    return True, f"{nb} résultats historiques importés (2018–2022)."
