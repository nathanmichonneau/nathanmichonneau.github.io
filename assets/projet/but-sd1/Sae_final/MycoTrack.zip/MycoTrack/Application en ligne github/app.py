"""
MycoTrack — Application Streamlit v15
PCR Mycoplasmes · Tableau de bord · Carte réelle · Import Excel · CRUD
"""

import streamlit as st
import mysql.connector
import pandas as pd
import io
import plotly.express as px
import plotly.graph_objects as go
import atexit
from datetime import date, datetime
try:
    from sshtunnel import SSHTunnelForwarder
    SSHTUNNEL_DISPONIBLE = True
except ImportError:
    SSHTUNNEL_DISPONIBLE = False

# folium chargé uniquement quand la page Carte est ouverte
# (évite 200-400ms de chargement sur toutes les autres pages)

# import_alwaysdata chargé en lazy sur la page Import uniquement
# (le subprocess pip check ralentissait TOUS les rechargements)
IMPORT_OK = None  # None = pas encore vérifié

# ══════════════════════════════════════════════════════════════
# CONFIG
# ══════════════════════════════════════════════════════════════

st.set_page_config(
    page_title="MycoTrack", page_icon="🐐",
    layout="wide", initial_sidebar_state="collapsed"
)

# ── Détection automatique : Streamlit Cloud ou local ──────────
# Sur Streamlit Cloud → connexion directe via secrets
# En local → connexion via tunnel SSH
EN_LIGNE = "database" in st.secrets

if EN_LIGNE:
    # Connexion directe AlwaysData (Streamlit Cloud)
    DB_CONFIG = {
        "host":     st.secrets["database"]["host"],
        "port":     int(st.secrets["database"]["port"]),
        "user":     st.secrets["database"]["user"],
        "password": st.secrets["database"]["password"],
        "database": st.secrets["database"]["database"],
    }
else:
    # Connexion locale via tunnel SSH
    SSH_CONFIG = {
        "host":     "ssh-saebdd.alwaysdata.net",
        "port":     22,
        "user":     "saebdd",
        "password": "SAEAlixNathan$",
    }
    DB_CONFIG = {
        "host":     "127.0.0.1",
        "port":     3306,
        "user":     "saebdd",
        "password": "SAEAlixNathan$",
        "database": "saebdd_analyse",
    }

@st.cache_resource
def get_tunnel():
    # En ligne : pas de tunnel, retourne None
    if EN_LIGNE:
        return None
    # En local : ouvrir le tunnel SSH
    if not SSHTUNNEL_DISPONIBLE:
        return None
    try:
        tunnel = SSHTunnelForwarder(
            (SSH_CONFIG["host"], SSH_CONFIG["port"]),
            ssh_username=SSH_CONFIG["user"],
            ssh_password=SSH_CONFIG["password"],
            remote_bind_address=("mysql-saebdd.alwaysdata.net", 3306),
        )
        tunnel.start()
        atexit.register(tunnel.stop)
        return tunnel
    except Exception:
        return None

# ── Classements — palette cohérente et sémantique
# Négatif: vert | Fort positif: rouge vif | Positif récurrent: orange | Ponctuel: jaune | Ancien: bleu | Inconnu: gris
CLASSEMENT = {
    "A": ("Toujours NEG",        "#16a34a", "#dcfce7", "🟢"),  # vert
    "B": ("Toujours POS",        "#b91c1c", "#fee2e2", "🔴"),  # rouge foncé
    "C": ("Nouveau POS",         "#dc2626", "#fee2e2", "🆕"),  # rouge
    "D": ("Fort POS récurrent",  "#c2410c", "#ffedd5", "⚠️"),  # rouge-orange
    "E": ("Autre POS récurrent", "#ea580c", "#ffedd5", "🟠"),  # orange
    "F": ("Fort POS ponctuel",   "#d97706", "#fef3c7", "🟡"),  # ambre
    "G": ("Autre POS ponctuel",  "#ca8a04", "#fefce8", "🌕"),  # jaune-or
    "H": ("Ancien POS",          "#2563eb", "#dbeafe", "🔵"),  # bleu
    "I": ("Non défini",          "#6b7280", "#f3f4f6", "⬜"),  # gris
}

# ── Couleurs carte : même palette, teintes marker distinctes
MAP_COLORS = {
    "A": "#16a34a",  # vert franc
    "B": "#991b1b",  # rouge sang
    "C": "#dc2626",  # rouge vif
    "D": "#c2410c",  # rouge-orange
    "E": "#ea580c",  # orange
    "F": "#d97706",  # ambre
    "G": "#ca8a04",  # or
    "H": "#2563eb",  # bleu
    "I": "#9ca3af",  # gris clair
}

from coords_communes import COORDS_COMMUNES


def get_coords(num_ede: str):
    # Retourne le centroïde exact de la commune depuis le N° EDE
    commune_key = num_ede[:5]  # 5 premiers chiffres = code INSEE commune
    base = COORDS_COMMUNES.get(commune_key)
    if not base:
        # Commune inconnue : centre du département par défaut
        dep = num_ede[:2]
        base = {"79": (46.32, -0.46),
                "86": (46.58,  0.34),
                "16": (45.90,  0.08)}.get(dep, (46.4, 0.0))
    return base


# ══════════════════════════════════════════════════════════════
# BASE DE DONNÉES — connexion légère, statut en cache
# ══════════════════════════════════════════════════════════════

def new_conn():
    try:
        if EN_LIGNE:
            # Streamlit Cloud : connexion directe sans tunnel
            return mysql.connector.connect(**DB_CONFIG, connection_timeout=8, autocommit=False)
        else:
            # Local : connexion via tunnel SSH
            tunnel = get_tunnel()
            if tunnel is None or not tunnel.is_active:
                if "db_errors" not in st.session_state:
                    st.session_state.db_errors = []
                msg = "Tunnel SSH inactif — vérifiez les identifiants SSH AlwaysData."
                if msg not in st.session_state.db_errors:
                    st.session_state.db_errors.append(msg)
                return None
            cfg = {**DB_CONFIG, "port": tunnel.local_bind_port}
            return mysql.connector.connect(**cfg, connection_timeout=8, autocommit=False)
    except Exception as e:
        if "db_errors" not in st.session_state:
            st.session_state.db_errors = []
        msg = f"Connexion MySQL échouée : {e}"
        if msg not in st.session_state.db_errors:
            st.session_state.db_errors.append(msg)
        return None


# Cache 60s pour éviter de bloquer chaque changement de page
@st.cache_data(ttl=120, show_spinner=False)
def db_ok_cached():
    """Vérifie la connexion DB — mis en cache 2 min."""
    try:
        if EN_LIGNE:
            cfg = DB_CONFIG
        else:
            tunnel = get_tunnel()
            if tunnel is None or not tunnel.is_active:
                return False
            cfg = {**DB_CONFIG, "port": tunnel.local_bind_port}
        conn = mysql.connector.connect(**cfg, connection_timeout=3)
        ok = conn.is_connected()
        conn.close()
        return ok
    except Exception:
        return False


def q(sql, params=None, fetch=True):
    conn = new_conn()
    if conn is None:
        if "db_errors" not in st.session_state:
            st.session_state.db_errors = []
        st.session_state.db_errors.append("Impossible de se connecter à la base de données.")
        return pd.DataFrame() if fetch else None
    try:
        cur = conn.cursor(dictionary=True)
        cur.execute(sql, params or ())
        if fetch:
            rows = cur.fetchall()
            cur.close(); conn.close()
            return pd.DataFrame(rows) if rows else pd.DataFrame()
        else:
            conn.commit()
            lid = cur.lastrowid
            cur.close(); conn.close()
            return lid
    except Exception as e:
        try: conn.close()
        except Exception: pass
        if "db_errors" not in st.session_state:
            st.session_state.db_errors = []
        st.session_state.db_errors.append(f"Erreur SQL : {e}\n→ Requête : {sql[:120]}")
        return pd.DataFrame() if fetch else None


def refresh():
    st.cache_data.clear()
    st.rerun()


# ── Lectures cachées 60s — ne met en cache que si des données sont présentes
@st.cache_data(ttl=300, show_spinner=False)
def get_elevages():
    df = q("SELECT * FROM elevage ORDER BY id_elevage")
    if df.empty: st.cache_data.clear()
    return df

@st.cache_data(ttl=300, show_spinner=False)
def get_edes():
    df = q("""SELECT e.*, el.nom_exploitant, el.code_classement
                FROM ede e JOIN elevage el ON e.id_elevage=el.id_elevage
                ORDER BY e.num_ede""")
    if df.empty: st.cache_data.clear()
    return df

@st.cache_data(ttl=300, show_spinner=False)
def get_series():
    df = q("SELECT * FROM serie ORDER BY annee DESC, numero_serie")
    if df.empty: st.cache_data.clear()
    return df

@st.cache_data(ttl=300, show_spinner=False)
def get_resultats():
    df = q("""
        SELECT r.id_resultat,
               r.ct_mycoides, r.ct_agalactiae, r.ct_capricolum, r.ct_putrefaciens,
               r.type_analyse,
               p.id_prelevement, p.num_prelevement, p.date_prelevement, p.num_ede,
               e.code_departement,
               el.nom_exploitant, el.code_classement, el.id_elevage,
               s.annee, s.numero_serie
        FROM resultat_pcr r
        JOIN prelevement p ON r.id_resultat = p.id_resultat
        JOIN ede e         ON p.num_ede     = e.num_ede
        JOIN elevage el    ON e.id_elevage  = el.id_elevage
        JOIN serie s       ON p.id_serie    = s.id_serie
        ORDER BY s.annee, s.numero_serie, p.date_prelevement
    """)
    if not df.empty:
        ct_cols = ["ct_mycoides","ct_agalactiae","ct_capricolum","ct_putrefaciens"]
        for col in ct_cols:
            if col not in df.columns:
                df[col] = None
        def _ct_min(row):
            vals = []
            for v in row:
                if v is None:
                    continue
                try:
                    f = float(str(v))
                    import math as _math
                    if not _math.isnan(f) and not _math.isinf(f):
                        vals.append(f)
                except (TypeError, ValueError):
                    pass
            pos = [v for v in vals if v < 40]
            return min(pos) if pos else None
        df["valeur_ct"] = df[ct_cols].apply(_ct_min, axis=1)
    return df

@st.cache_data(ttl=300, show_spinner=False)
def get_prelevements():
    return q("""
        SELECT p.*, s.annee, s.numero_serie, el.nom_exploitant
        FROM prelevement p
        LEFT JOIN serie s    ON p.id_serie   = s.id_serie
        LEFT JOIN ede e      ON p.num_ede    = e.num_ede
        LEFT JOIN elevage el ON e.id_elevage = el.id_elevage
        ORDER BY p.date_prelevement DESC""")

@st.cache_data(ttl=60, show_spinner=False)
def get_mycoplasmas():
    """Table mycoplasma supprimée en v15 — retourne DataFrame vide."""
    import pandas as pd; return pd.DataFrame()


# ══════════════════════════════════════════════════════════════
# EXPORTS — PDF et Excel
# ══════════════════════════════════════════════════════════════

def export_excel_elevages(ELV, EDE, RES):
    """Génère un Excel avec 3 onglets : Élevages, Résumé par classement, Résultats positifs"""
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        # Onglet 1 : Élevages
        if not ELV.empty:
            df1 = ELV.copy()
            df1["Libellé classement"] = df1["code_classement"].map(
                lambda c: CLASSEMENT.get(str(c or "I"), CLASSEMENT["I"])[0])
            df1.rename(columns={
                "id_elevage": "ID", "nom_exploitant": "Exploitant",
                "code_classement": "Code classement"
            }).to_excel(writer, sheet_name="Élevages", index=False)

        # Onglet 2 : Résumé par classement
        if not ELV.empty and "code_classement" in ELV.columns:
            cc = ELV["code_classement"].fillna("I").value_counts().reset_index()
            cc.columns = ["Code", "Nb élevages"]
            cc["Libellé"] = cc["Code"].map(lambda c: CLASSEMENT.get(c, CLASSEMENT["I"])[0])
            cc = cc.sort_values("Code")
            cc.to_excel(writer, sheet_name="Résumé classements", index=False)

        # Onglet 3 : Résultats positifs
        if not RES.empty:
            def is_pos(ct):
                try: return ct is not None and float(ct) < 40
                except: return False
            pos = RES[RES["valeur_ct"].apply(is_pos)].copy()
            pos["Statut"] = "Positif"
            cols = [c for c in ["num_ede","nom_exploitant","code_classement",
                                  "valeur_ct","annee","numero_serie","date_prelevement"] if c in pos.columns]
            pos[cols].rename(columns={
                "num_ede":"EDE","nom_exploitant":"Exploitant",
                "code_classement":"Classement","valeur_ct":"Ct",
                "annee":"Année","numero_serie":"Série","date_prelevement":"Date"
            }).to_excel(writer, sheet_name="Résultats positifs", index=False)

    buf.seek(0)
    return buf.getvalue()


def export_excel_resultats(RES):
    """Export brut de tous les résultats PCR"""
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        if not RES.empty:
            RES.to_excel(writer, sheet_name="Résultats PCR", index=False)
    buf.seek(0)
    return buf.getvalue()


def export_pdf_rapport(ELV, RES):
    """Génère un rapport PDF de synthèse (ReportLab)"""
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib import colors
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
        from reportlab.lib.units import cm

        buf = io.BytesIO()
        doc = SimpleDocTemplate(buf, pagesize=A4,
                                 topMargin=2*cm, bottomMargin=2*cm,
                                 leftMargin=2*cm, rightMargin=2*cm)
        styles = getSampleStyleSheet()
        story = []

        # Titre
        title_style = ParagraphStyle("title", parent=styles["Title"],
                                      fontSize=22, textColor=colors.HexColor("#1e1b4b"),
                                      spaceAfter=6)
        sub_style = ParagraphStyle("sub", parent=styles["Normal"],
                                    fontSize=10, textColor=colors.HexColor("#6b7280"),
                                    spaceAfter=20)
        story.append(Paragraph("🐐 MycoTrack — Rapport PCR Mycoplasmes", title_style))
        story.append(Paragraph(f"Généré le {datetime.now().strftime('%d/%m/%Y à %H:%M')}", sub_style))

        # KPIs
        def is_pos(ct):
            try: return ct is not None and float(ct) < 40
            except: return False

        n_elv = len(ELV) if not ELV.empty else 0
        n_res = len(RES) if not RES.empty else 0
        n_pos = RES["valeur_ct"].apply(is_pos).sum() if not RES.empty else 0
        taux  = round(n_pos / n_res * 100, 1) if n_res else 0

        kpi_data = [
            ["Indicateur", "Valeur"],
            ["Élevages suivis", str(n_elv)],
            ["Résultats PCR totaux", str(n_res)],
            ["Résultats positifs (Ct < 40)", str(int(n_pos))],
            ["Taux de positivité global", f"{taux} %"],
        ]
        kpi_table = Table(kpi_data, colWidths=[10*cm, 6*cm])
        kpi_table.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#1e1b4b")),
            ("TEXTCOLOR", (0,0), (-1,0), colors.white),
            ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
            ("FONTSIZE", (0,0), (-1,0), 12),
            ("FONTSIZE", (0,1), (-1,-1), 11),
            ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.HexColor("#f8f9ff"), colors.white]),
            ("BOX", (0,0), (-1,-1), 0.8, colors.HexColor("#e0e7ff")),
            ("INNERGRID", (0,0), (-1,-1), 0.4, colors.HexColor("#e0e7ff")),
            ("TOPPADDING", (0,0), (-1,-1), 7),
            ("BOTTOMPADDING", (0,0), (-1,-1), 7),
            ("LEFTPADDING", (0,0), (-1,-1), 10),
        ]))
        story.append(kpi_table)
        story.append(Spacer(1, 0.6*cm))

        # Tableau classements
        story.append(Paragraph("Répartition par classement PCR", styles["Heading2"]))
        story.append(Spacer(1, 0.2*cm))

        if not ELV.empty and "code_classement" in ELV.columns:
            cc = ELV["code_classement"].fillna("I").value_counts().reset_index()
            cc.columns = ["Code", "Nb"]
            cc["Libellé"] = cc["Code"].map(lambda c: CLASSEMENT.get(c, CLASSEMENT["I"])[0])
            cc["Emoji"]   = cc["Code"].map(lambda c: CLASSEMENT.get(c, CLASSEMENT["I"])[3])
            cc = cc.sort_values("Code")

            tbl_data = [["Code", "Libellé", "Nb élevages", "Pourcentage"]]
            for _, row in cc.iterrows():
                pct = round(row["Nb"] / n_elv * 100, 1) if n_elv else 0
                tbl_data.append([row["Code"], row["Libellé"], str(int(row["Nb"])), f"{pct} %"])

            tbl = Table(tbl_data, colWidths=[2*cm, 8*cm, 3.5*cm, 3.5*cm])
            row_styles = [
                ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#4338ca")),
                ("TEXTCOLOR", (0,0), (-1,0), colors.white),
                ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
                ("FONTSIZE", (0,0), (-1,-1), 10),
                ("ALIGN", (2,0), (-1,-1), "CENTER"),
                ("BOX", (0,0), (-1,-1), 0.8, colors.HexColor("#e0e7ff")),
                ("INNERGRID", (0,0), (-1,-1), 0.4, colors.HexColor("#e0e7ff")),
                ("TOPPADDING", (0,0), (-1,-1), 6),
                ("BOTTOMPADDING", (0,0), (-1,-1), 6),
                ("LEFTPADDING", (0,0), (-1,-1), 8),
            ]
            for i, row in enumerate(cc.itertuples(), start=1):
                bg = colors.HexColor("#f0fdf4") if row.Code == "A" else \
                     colors.HexColor("#fef2f2") if row.Code in ("B","C","D") else \
                     colors.HexColor("#fff7ed") if row.Code in ("E","F","G") else \
                     colors.HexColor("#eff6ff") if row.Code == "H" else \
                     colors.HexColor("#f9fafb")
                row_styles.append(("BACKGROUND", (0, i), (-1, i), bg))
            tbl.setStyle(TableStyle(row_styles))
            story.append(tbl)

        doc.build(story)
        buf.seek(0)
        return buf.getvalue()
    except Exception as e:
        return None


# ══════════════════════════════════════════════════════════════
# CLASSEMENT
# ══════════════════════════════════════════════════════════════

def calcul_classement(ct_list):
    """Calcule le classement A-I selon les règles officielles."""
    def _f(c):
        """Convertit en float ou None si invalide/NaN."""
        if c is None: return None
        try:
            v = float(c)
            import math
            return None if math.isnan(v) else v
        except (TypeError, ValueError):
            return None

    def neg(c):  v = _f(c); return v is None or v >= 40
    def pos(c):  v = _f(c); return v is not None and v < 40
    def fort(c): v = _f(c); return v is not None and v < 35

    l6 = ct_list[-6:]
    l4 = ct_list[-4:]

    if len(l6) >= 6:
        if all(neg(c) for c in l6):                                  return "A"
        if all(pos(c) for c in l6):                                  return "B"
        if fort(l6[-1]) and all(neg(c) for c in l6[:-1]):           return "C"
        pv = [c for c in l6 if pos(c)]
        n  = len(pv)
        if 3 <= n <= 5 and all(fort(c) for c in pv):                return "D"
        if 3 <= n <= 5:                                              return "E"
        if 1 <= n <= 2 and all(fort(c) for c in pv):                return "F"
        if 1 <= n <= 2:                                              return "G"
    if len(l4) >= 4 and all(neg(c) for c in l4):                    return "H"
    return "I"


def recalculer_classements():
    """Recalcule les classements A–I en utilisant le Ct le plus critique des 4 espèces."""
    from collections import defaultdict
    conn = new_conn()
    if not conn:
        return
    try:
        cur = conn.cursor(buffered=True)
        cur.execute("""
            SELECT el.id_elevage,
                   r.ct_mycoides, r.ct_agalactiae, r.ct_capricolum, r.ct_putrefaciens
            FROM elevage el
            JOIN ede e          ON el.id_elevage = e.id_elevage
            JOIN prelevement p  ON e.num_ede      = p.num_ede
            JOIN resultat_pcr r ON p.id_resultat  = r.id_resultat
            JOIN serie s        ON p.id_serie     = s.id_serie
            ORDER BY el.id_elevage, s.annee, s.numero_serie, p.date_prelevement
        """)
        rows = cur.fetchall()
        cur.close()
        if not rows:
            conn.close()
            return
        cts_par_elevage = defaultdict(list)
        for id_elv, ct_m, ct_a, ct_c, ct_p in rows:
            # Ct le plus critique = minimum des 4 espèces pour ce prélèvement
            vals = [float(v) for v in (ct_m, ct_a, ct_c, ct_p) if v is not None and float(v) < 40]
            ct   = min(vals) if vals else None
            cts_par_elevage[id_elv].append(ct)
        updates = [(calcul_classement(cts), id_elv)
                   for id_elv, cts in cts_par_elevage.items()]
        cur2 = conn.cursor(buffered=True)
        cur2.executemany(
            "UPDATE elevage SET code_classement=%s WHERE id_elevage=%s", updates)
        conn.commit()
        cur2.close()
    except Exception:
        try: conn.rollback()
        except: pass
    finally:
        try: conn.close()
        except: pass


# ══════════════════════════════════════════════════════════════
# FICHE ÉLEVAGE — réutilisée carte + recherche
# ══════════════════════════════════════════════════════════════

def _afficher_fiche_elevage(ede_sel, EDE, hist_ct, MAP_COLORS, CLASSEMENT, key_prefix=""):
    hist = hist_ct.get(ede_sel, [])
    if not hist:
        st.info("Aucun résultat PCR pour cet élevage.")
        return

    row_e   = EDE[EDE["num_ede"] == ede_sel].iloc[0] if not EDE.empty and ede_sel in EDE["num_ede"].values else None
    nom_e   = (row_e["nom_exploitant"] if row_e is not None else None) or "—"
    code_e  = str((row_e["code_classement"] if row_e is not None else None) or "I").upper()
    dep_e   = (row_e["code_departement"] if row_e is not None else "—") or "—"
    inf_e   = CLASSEMENT.get(code_e, CLASSEMENT["I"])
    col_e   = MAP_COLORS.get(code_e, "#9ca3af")

    st.markdown(f"""
    <div style="background:white;border:2px solid #e0e7ff;border-radius:14px;
                padding:16px 20px;margin:10px 0;">
      <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
        <div style="font-weight:800;font-size:1.1rem;color:#1e1b4b;">🐄 {ede_sel}</div>
        <div style="color:#374151;">👤 {nom_e}</div>
        <span style="background:{col_e};color:white;border-radius:12px;
                     padding:4px 14px;font-size:12px;font-weight:700;">
          {code_e} — {inf_e[0]}</span>
        <div style="color:#6b7280;font-size:13px;">Dep. {dep_e}</div>
        <div style="color:#6b7280;font-size:13px;">{len(hist)} résultat(s) au total</div>
      </div>
    </div>""", unsafe_allow_html=True)

    max_show = max(len(hist), 6)
    n_show   = st.slider("Nombre de résultats à afficher",
                         min_value=1, max_value=max_show,
                         value=min(6, len(hist)),
                         key=f"slider_{key_prefix}_{ede_sel}")
    derniers = hist[-n_show:]

    vals = [h["val"] for h in derniers if h["val"] is not None]
    labs = [h["Série"] for h in derniers if h["val"] is not None]

    gc1, gc2 = st.columns([3, 2])
    with gc1:
        if vals:
            fig_f = go.Figure()
            fig_f.add_hline(y=40, line_dash="dash", line_color="#16a34a",
                            annotation_text="Seuil 40 (NEG)", annotation_position="right")
            fig_f.add_hline(y=35, line_dash="dot", line_color="#d97706",
                            annotation_text="Seuil 35 (Fort POS)", annotation_position="right")
            pts_col = ["#16a34a" if v >= 40 else ("#b91c1c" if v < 35 else "#ea580c") for v in vals]
            fig_f.add_trace(go.Scatter(
                x=labs, y=vals, mode="lines+markers",
                line=dict(color="#4338ca", width=2.5),
                marker=dict(size=12, color=pts_col, line=dict(color="white", width=2)),
                hovertemplate="<b>%{x}</b><br>Ct : %{y:.1f}<extra></extra>"
            ))
            fig_f.update_layout(
                height=280, template="plotly_white", showlegend=False,
                yaxis=dict(title="Valeur Ct", autorange="reversed"),
                margin=dict(t=10, b=40, l=50, r=130)
            )
            st.plotly_chart(fig_f, use_container_width=True)
        else:
            st.info("Pas de valeurs numériques à afficher.")
    with gc2:
        df_f = pd.DataFrame(derniers)[["Série","Date","Ct","Statut"]]
        st.dataframe(df_f, use_container_width=True, hide_index=True, height=280)


# ══════════════════════════════════════════════════════════════
# CSS
# ══════════════════════════════════════════════════════════════

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
html,body,[class*="css"]{font-family:'Inter',sans-serif;}
.main .block-container{padding-top:1.2rem;max-width:1400px;}

.stButton>button{
    font-size:14px!important; font-weight:600!important;
    height:48px!important; padding:0 16px!important;
    border-radius:10px!important; border:none!important;
    width:100%!important; transition:all .15s ease!important;
}
.stButton>button:hover{
    transform:translateY(-2px)!important;
    box-shadow:0 6px 18px rgba(0,0,0,.15)!important;
    filter:brightness(1.06)!important;
}

[data-testid="stMetric"]{
    background:white; border:1.5px solid #e5e7eb;
    border-radius:14px; padding:18px 22px!important;
    box-shadow:0 1px 4px rgba(0,0,0,.06);
}
[data-testid="stMetricValue"]{font-size:2.3rem!important;font-weight:800!important;color:#1e1b4b!important;}
[data-testid="stMetricLabel"]{font-size:.82rem!important;font-weight:700!important;
    color:#6b7280!important;text-transform:uppercase!important;letter-spacing:.6px!important;}

h1{color:#1e1b4b!important;font-size:1.9rem!important;font-weight:800!important;}
h2{color:#1e1b4b!important;font-weight:700!important;}
h3{color:#374151!important;font-weight:600!important;}

.card{background:white;border:1.5px solid #e5e7eb;border-radius:14px;
      padding:20px 24px;box-shadow:0 1px 6px rgba(0,0,0,.06);margin-bottom:12px;}
.card-dark{background:linear-gradient(135deg,#1e1b4b 0%,#312e81 100%);
           border-radius:14px;padding:20px 24px;color:white;
           box-shadow:0 4px 16px rgba(30,27,75,.25);}
.card-dark .val{font-size:2rem;font-weight:800;}
.card-dark .lbl{font-size:.75rem;font-weight:700;text-transform:uppercase;
                letter-spacing:.8px;color:rgba(255,255,255,.45);margin-bottom:6px;}
.card-dark .sub{font-size:.8rem;color:rgba(255,255,255,.38);margin-top:3px;}

/* Boutons export */
.export-btn{display:inline-flex;align-items:center;gap:8px;padding:10px 20px;
            border-radius:10px;font-weight:700;font-size:13px;cursor:pointer;
            transition:all .15s;border:none;color:white;}

[data-testid="stForm"]{background:#f8f9ff;border:1.5px solid #e0e7ff;
    border-radius:14px;padding:22px!important;}
.stTextInput>div>div>input,.stNumberInput>div>div>input{
    height:44px!important;font-size:14px!important;
    border-radius:9px!important;border:1.5px solid #e0e7ff!important;}
.stSelectbox>div>div{min-height:44px!important;font-size:14px!important;
    border-radius:9px!important;border:1.5px solid #e0e7ff!important;}
.stTabs [data-baseweb="tab"]{font-size:14px!important;font-weight:600!important;
    height:44px!important;padding:0 22px!important;border-radius:9px 9px 0 0!important;}
[data-testid="stFileUploader"]{border:2px dashed #c7d2fe!important;
    border-radius:14px!important;padding:20px!important;background:#f5f7ff!important;}
.alerte{display:flex;align-items:flex-start;gap:10px;padding:12px 16px;
        border-radius:10px;margin:5px 0;font-size:13px;font-weight:500;}
hr{border:none;border-top:1.5px solid #f3f4f6;margin:16px 0;}

/* Badge classement */
.badge-cls{display:inline-block;padding:3px 11px;border-radius:20px;
           font-size:11px;font-weight:800;letter-spacing:.4px;color:white;}
</style>
""", unsafe_allow_html=True)


# ── Détection série/année depuis le nom du fichier ───────────
import re as _re
_MOIS_MOTS_APP = [
    (["janv","jan","fevr","fev","feb","mars","mar","avri","apr"], 1),
    (["mai","may","juin","jun","juil","jul","aout","aug"],         2),
    (["sept","sep","octo","oct","nove","nov","dece","dec"],        3),
]
def _detecter_serie_annee_nom(nom: str) -> tuple:
    """Détecte (serie, annee) depuis le nom du fichier Excel."""
    nom_l = nom.lower()
    annee = None
    m = _re.search(r"20(\d{2})", nom_l)
    if m: annee = int("20" + m.group(1))
    for mots, serie in _MOIS_MOTS_APP:
        if any(mot in nom_l for mot in mots):
            return serie, annee
    return None, annee

# ══════════════════════════════════════════════════════════════
# NAVIGATION — instantanée (db_ok en cache)
# ══════════════════════════════════════════════════════════════

if "page" not in st.session_state:
    st.session_state.page = "Tableau de bord"

PAGES = [
    ("📊", "Tableau de bord", "Bord",        "#4338ca"),
    ("🗺️", "Carte",           "Carte",      "#0891b2"),
    ("📥", "Import Excel",    "Import",     "#16a34a"),
    ("🐄", "Élevages",        "Élevages",   "#7c3aed"),
    ("🧪", "Prélèvements",    "Prélèvem.",  "#db2777"),
    ("📋", "Résultats PCR",   "Résultats",  "#ea580c"),
    ("📅", "Séries",          "Séries",     "#0284c7"),
    ("🦠", "Mycoplasmas",     "Myco.",      "#dc2626"),
    ("🔍", "Requêtes SQL",    "SQL",        "#374151"),
    ("🛡️", "Admin",           "Admin",      "#991b1b"),
]

hc1, hc2 = st.columns([1, 7])
with hc1:
    try:
        from PIL import Image
        logo = Image.open("logo.png")
        st.image(logo, use_container_width=True)
    except Exception:
        st.markdown("""
        <div style="background:linear-gradient(135deg,#0f4fa8,#1a6fd4);
                    border-radius:14px;padding:14px 18px;text-align:center;">
          <div style="color:white;font-size:20px;font-weight:800;letter-spacing:1px;">🐐 MycoTrack</div>
          <div style="color:rgba(255,255,255,.45);font-size:11px;margin-top:2px;">PCR Mycoplasmes</div>
        </div>""", unsafe_allow_html=True)

with hc2:
    nav_cols = st.columns(len(PAGES))
    for i, (icon, label, short, color) in enumerate(PAGES):
        active = (st.session_state.page == label)
        with nav_cols[i]:
            if st.button(f"{icon} {short}", key=f"nav_{i}",
                         type="primary" if active else "secondary",
                         use_container_width=True,
                         help=label):
                st.session_state.page = label
                st.rerun()

# Statut DB — lu depuis le cache (ne bloque pas la navigation)
sc1, sc2 = st.columns([1, 9])
with sc1:
    ok = db_ok_cached()
    st.markdown(
        f'<div style="background:{"#dcfce7" if ok else "#fee2e2"};'
        f'color:{"#16a34a" if ok else "#dc2626"};border-radius:8px;'
        f'padding:5px 12px;font-size:12px;font-weight:700;text-align:center;">'
        f'{"🟢 Base connectée" if ok else "🔴 Base déconnectée"}</div>',
        unsafe_allow_html=True)
with sc2:
    if not ok:
        st.markdown(
            '<span style="color:#6b7280;font-size:12px;">'
            'La base AlwaysData peut être déconnectée si inactive — normal en mode hébergement mutualisé.'
            '</span>', unsafe_allow_html=True)

st.markdown("<hr>", unsafe_allow_html=True)
PAGE = st.session_state.page


# ══════════════════════════════════════════════════════════════
# SECTION EXPORTS (réutilisable dans plusieurs pages)
# ══════════════════════════════════════════════════════════════

def render_export_buttons(ELV, RES, EDE=None):
    """Affiche les boutons d'export PDF et Excel prêts à l'emploi"""
    st.markdown("### 📤 Exports rapides")
    ecol1, ecol2, ecol3 = st.columns(3)

    with ecol1:
        if st.button("📄 Rapport PDF — Synthèse", use_container_width=True, type="primary"):
            with st.spinner("Génération du PDF..."):
                pdf_bytes = export_pdf_rapport(ELV, RES)
            if pdf_bytes:
                st.download_button(
                    label="⬇️ Télécharger le PDF",
                    data=pdf_bytes,
                    file_name=f"mycotrack_rapport_{date.today().strftime('%Y%m%d')}.pdf",
                    mime="application/pdf",
                    use_container_width=True
                )
            else:
                st.error("Erreur lors de la génération PDF. Vérifiez que reportlab est installé.")

    with ecol2:
        if st.button("📊 Excel — Élevages & Classements", use_container_width=True):
            ede_arg = EDE if (EDE is not None and not (hasattr(EDE, "empty") and EDE.empty)) else pd.DataFrame()
            xl_bytes = export_excel_elevages(ELV, ede_arg, RES)
            st.download_button(
                label="⬇️ Télécharger l'Excel",
                data=xl_bytes,
                file_name=f"mycotrack_elevages_{date.today().strftime('%Y%m%d')}.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                use_container_width=True
            )

    with ecol3:
        if st.button("🧪 Excel — Résultats PCR complets", use_container_width=True):
            xl_bytes = export_excel_resultats(RES)
            st.download_button(
                label="⬇️ Télécharger l'Excel",
                data=xl_bytes,
                file_name=f"mycotrack_resultats_{date.today().strftime('%Y%m%d')}.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                use_container_width=True
            )


# ══════════════════════════════════════════════════════════════
# PAGE TABLEAU DE BORD
# ══════════════════════════════════════════════════════════════

if PAGE == "Tableau de bord":
    st.title("📊 Tableau de bord")
    st.caption("Vue d'ensemble — MycoTrack PCR Mycoplasmes")

    # ── Affichage des erreurs DB éventuelles
    if st.session_state.get("db_errors"):
        with st.expander("⚠️ Erreurs de base de données détectées (cliquer pour voir)", expanded=True):
            for err in st.session_state["db_errors"]:
                st.error(err)
        st.session_state["db_errors"] = []

    ELV = get_elevages()
    EDE = get_edes()
    RES = get_resultats()
    SER = get_series()

    # ── Avertissement si toutes les données sont vides
    if ELV.empty and RES.empty and SER.empty:
        st.warning(
            "⚠️ **Aucune donnée chargée.** La base de données est peut-être "
            "inaccessible ou vide. Vérifiez la connexion, puis cliquez sur "
            "**Forcer le rechargement** pour réessayer.",
            icon="⚠️"
        )
        if st.button("🔄 Forcer le rechargement des données", type="primary"):
            st.cache_data.clear()
            if "db_errors" in st.session_state:
                del st.session_state["db_errors"]
            st.rerun()

    # ── Exports en haut
    render_export_buttons(ELV, RES, EDE)
    st.markdown("<hr>", unsafe_allow_html=True)

    # ── KPIs
    n79 = len(EDE[EDE["code_departement"] == "79"]) if not EDE.empty else 0
    n86 = len(EDE[EDE["code_departement"] == "86"]) if not EDE.empty else 0
    n16 = len(EDE[EDE["code_departement"] == "16"]) if not EDE.empty else 0

    k1,k2,k3,k4,k5,k6 = st.columns(6)
    k1.metric("🐄 Élevages",  len(ELV))
    k2.metric("🧪 Résultats", len(RES))
    k3.metric("📅 Séries",    len(SER))
    k4.metric("📍 Dep. 79",   n79)
    k5.metric("📍 Dep. 86",   n86)
    k6.metric("📍 Dep. 16",   n16)

    st.markdown("<hr>", unsafe_allow_html=True)

    d1,d2,d3 = st.columns(3)
    total = max(len(ELV), 1)
    for col, dep, n, c in [
        (d1,"Deux-Sèvres (79)",n79,"#a5b4fc"),
        (d2,"Vienne (86)",     n86,"#4ade80"),
        (d3,"Charente — 16",  n16,"#fb923c"),
    ]:
        pct = round(n/total*100) if total else 0
        col.markdown(f"""<div class="card-dark">
          <div class="lbl">Département — {dep}</div>
          <div class="val" style="color:{c};">{n}</div>
          <div class="sub">élevages · {pct}% du total</div>
        </div>""", unsafe_allow_html=True)

    st.markdown("<hr>", unsafe_allow_html=True)

    def is_pos(ct):
        try: return ct is not None and float(ct) < 40
        except: return False

    if not ELV.empty and "code_classement" in ELV.columns:
        g1, g2 = st.columns([3, 2])
        cc = ELV["code_classement"].fillna("I").value_counts().reset_index()
        cc.columns = ["Code","Nb"]
        cc["Couleur"] = cc["Code"].map(lambda c: CLASSEMENT.get(c, CLASSEMENT["I"])[1])
        cc["Label"]   = cc["Code"].map(lambda c: f"{CLASSEMENT.get(c, CLASSEMENT['I'])[3]} {c} — {CLASSEMENT.get(c, CLASSEMENT['I'])[0]}")
        cc = cc.sort_values("Code")

        with g1:
            st.subheader("Répartition par classement PCR")
            fig1 = go.Figure(go.Bar(
                x=cc["Code"], y=cc["Nb"],
                text=cc["Nb"], textposition="outside", textfont_size=14,
                marker_color=cc["Couleur"].tolist(),
                hovertemplate="<b>%{x}</b><br>%{y} élevages<extra></extra>"
            ))
            fig1.update_layout(height=360, template="plotly_white", showlegend=False,
                xaxis_title="Classement", yaxis_title="Nb élevages",
                font_size=13, margin=dict(t=30,b=40,l=40,r=20), plot_bgcolor="white")
            st.plotly_chart(fig1, use_container_width=True)

        with g2:
            st.subheader("Camembert")
            fig2 = go.Figure(go.Pie(
                labels=cc["Label"], values=cc["Nb"],
                marker_colors=cc["Couleur"].tolist(),
                hole=0.5, textfont_size=12,
                hovertemplate="<b>%{label}</b><br>%{value} élevages<extra></extra>"
            ))
            fig2.add_annotation(text=f"<b>{len(ELV)}</b><br>élevages",
                x=0.5, y=0.5, showarrow=False,
                font=dict(size=16, color="#1e1b4b"))
            fig2.update_layout(height=360, showlegend=False,
                margin=dict(t=30,b=20,l=20,r=20))
            st.plotly_chart(fig2, use_container_width=True)

        st.markdown("<hr>", unsafe_allow_html=True)

    if not RES.empty:
        g3, g4 = st.columns(2)

        with g3:
            st.subheader("📈 Nb de positifs par année")
            # On compte le nb d'élevages distincts positifs (au moins 1 résultat positif)
            # et le total d'élevages distincts testés — pour éviter les % > 100
            evo_rows = []
            for annee, grp in RES.groupby("annee"):
                elv_testes  = grp["num_ede"].nunique()
                elv_positifs = grp[grp["valeur_ct"].apply(is_pos)]["num_ede"].nunique()
                taux = round(elv_positifs / elv_testes * 100, 1) if elv_testes else 0
                evo_rows.append({"Année": annee, "Taux (%)": taux,
                                 "Élevages positifs": elv_positifs,
                                 "Élevages testés": elv_testes})
            evo = pd.DataFrame(evo_rows)
            fig3 = go.Figure()
            fig3.add_trace(go.Bar(x=evo["Année"], y=evo["Taux (%)"],
                marker_color="#c7d2fe",
                text=evo.apply(lambda r: f"{r['Taux (%)']}%", axis=1),
                textposition="outside", textfont_size=13, name="Taux",
                customdata=evo[["Élevages positifs","Élevages testés"]].values,
                hovertemplate="%{x}<br>%{customdata[0]} positifs / %{customdata[1]} testés<extra></extra>"))
            fig3.add_trace(go.Scatter(x=evo["Année"], y=evo["Taux (%)"],
                mode="lines+markers", line=dict(color="#4338ca",width=3),
                marker=dict(size=9), name="Tendance"))
            fig3.update_layout(height=320, template="plotly_white", showlegend=False,
                yaxis=dict(title="% élevages positifs",
                           range=[0, min(max(evo["Taux (%)"].max()+15, 15), 100)]),
                font_size=13, margin=dict(t=30,b=40,l=50,r=20))
            st.plotly_chart(fig3, use_container_width=True)

        with g4:
            st.subheader("📅 Positifs par série")
            sess = (RES.groupby("numero_serie")
                    .apply(lambda x: round(x["valeur_ct"].apply(is_pos).sum()/len(x)*100,1))
                    .reset_index())
            sess.columns = ["Série","Taux (%)"]
            # Séries 1, 2, 3 uniquement
            sess = sess[sess["Série"].isin([1, 2, 3])].copy()
            SERIE_LABELS = {1: "Série 1 (Janv–Avr)", 2: "Série 2 (Mai–Aoû)", 3: "Série 3 (Sep–Déc)"}
            sess["Label"] = sess["Série"].map(SERIE_LABELS)
            colors_s = ["#4338ca", "#dc2626", "#d97706"]
            fig4 = go.Figure()
            for _, row in sess.iterrows():
                idx = int(row["Série"]) - 1
                fig4.add_trace(go.Bar(
                    x=[row["Label"]], y=[row["Taux (%)"]],
                    marker_color=colors_s[idx],
                    text=f"{row['Taux (%)']}%", textposition="outside",
                    textfont_size=14, width=0.5))
            fig4.update_layout(height=320, template="plotly_white", showlegend=False,
                yaxis=dict(title="Taux positifs (%)",
                           range=[0, max(sess["Taux (%)"].max()+15, 15)]),
                font_size=13, margin=dict(t=20,b=40,l=50,r=20))
            st.plotly_chart(fig4, use_container_width=True)

        st.markdown("<hr>", unsafe_allow_html=True)

        g5, g6 = st.columns(2)

        with g5:
            st.subheader("🗂️ Taux de positivité par département")
            if not EDE.empty:
                # code_departement est déjà dans RES — on l'utilise directement
                if "code_departement" in RES.columns:
                    ede_res = RES.copy()
                else:
                    ede_res = RES.merge(
                        EDE[["num_ede","code_departement"]].drop_duplicates(),
                        on="num_ede", how="left", suffixes=("","_ede"))
                dep_stat = (ede_res.groupby("code_departement")
                            .apply(lambda x: round(x["valeur_ct"].apply(is_pos).sum()/len(x)*100,1))
                            .reset_index())
                dep_stat.columns = ["Département","Taux (%)"]
                dep_stat["Label"] = dep_stat["Département"].map(
                    {"79":"Deux-Sèvres (79)","86":"Vienne (86)","16":"Charente (16)"})
                dep_colors = {"79":"#6366f1","86":"#16a34a","16":"#d97706"}
                fig5 = go.Figure(go.Bar(
                    x=dep_stat["Label"], y=dep_stat["Taux (%)"],
                    marker_color=[dep_colors.get(d,"#9ca3af") for d in dep_stat["Département"]],
                    text=dep_stat["Taux (%)"].apply(lambda v: f"{v}%"),
                    textposition="outside", textfont_size=14, width=0.5))
                fig5.update_layout(height=300, template="plotly_white", showlegend=False,
                    yaxis=dict(title="Taux positifs (%)",
                               range=[0, max(dep_stat["Taux (%)"].max()+15, 15)]),
                    font_size=13, margin=dict(t=20,b=40,l=50,r=20))
                st.plotly_chart(fig5, use_container_width=True)
            else:
                st.info("Données insuffisantes.")

        with g6:
            st.subheader("🏆 Top 10 élevages les plus positifs")
            top = (RES[RES["valeur_ct"].apply(is_pos)]
                   .groupby(["num_ede","nom_exploitant"]).size()
                   .reset_index(name="Nb positifs")
                   .sort_values("Nb positifs", ascending=False).head(10))
            if not top.empty:
                top["Label"] = top["num_ede"] + " — " + top["nom_exploitant"].fillna("—")
                fig6 = go.Figure(go.Bar(
                    x=top["Nb positifs"], y=top["Label"],
                    orientation="h",
                    marker=dict(color=top["Nb positifs"],
                                colorscale=[[0,"#fbbf24"],[0.5,"#dc2626"],[1,"#7f1d1d"]],
                                showscale=False),
                    text=top["Nb positifs"], textposition="outside",
                    textfont_size=13))
                fig6.update_layout(height=300, template="plotly_white", showlegend=False,
                    xaxis_title="Nb résultats positifs",
                    font_size=12, margin=dict(t=20,b=40,l=200,r=60))
                st.plotly_chart(fig6, use_container_width=True)
            else:
                st.info("Aucun positif trouvé.")


        if not ELV.empty and not EDE.empty:
            st.subheader("📊 Répartition des classements par département")
            elv_ede = ELV.merge(EDE[["id_elevage","code_departement"]].drop_duplicates(),
                                on="id_elevage", how="left")
            heat = (elv_ede.groupby(["code_departement","code_classement"])
                    .size().reset_index(name="Nb"))
            if not heat.empty:
                # Barres groupées : une couleur par classement, une barre par département
                noms_dep = {"79": "Deux-Sèvres (79)", "86": "Vienne (86)", "16": "Charente (16)"}
                heat["Département"] = heat["code_departement"].map(lambda d: noms_dep.get(d, d))
                heat["code_classement"] = heat["code_classement"].fillna("I")
                couleurs_cls = {c: CLASSEMENT[c][1] for c in CLASSEMENT}
                fig7 = go.Figure()
                for code in list(CLASSEMENT.keys()):
                    df_c = heat[heat["code_classement"] == code]
                    if df_c.empty:
                        continue
                    fig7.add_trace(go.Bar(
                        name=f"{code} — {CLASSEMENT[code][0]}",
                        x=df_c["Département"], y=df_c["Nb"],
                        marker_color=couleurs_cls.get(code, "#9ca3af"),
                        text=df_c["Nb"], textposition="outside"))
                fig7.update_layout(
                    barmode="group", height=320,
                    template="plotly_white",
                    legend=dict(orientation="h", y=-0.35, font_size=11),
                    yaxis=dict(title="Nb élevages"),
                    margin=dict(t=10, b=100, l=40, r=20),
                    font_size=12)
                st.plotly_chart(fig7, use_container_width=True)

    st.markdown("<hr>", unsafe_allow_html=True)
    st.subheader("🔔 Alertes")
    if not ELV.empty:
        alertes = [(CLASSEMENT[c][1], CLASSEMENT[c][2], CLASSEMENT[c][3], c,
                    row["nom_exploitant"], CLASSEMENT[c][0])
                   for _, row in ELV.iterrows()
                   if (c := str(row.get("code_classement") or "I")) in ("B","C","D")]
        if alertes:
            for col, bg, em, code, nom, lbl in alertes[:8]:
                st.markdown(
                    f'<div class="alerte" style="background:{bg};border-left:4px solid {col};">'
                    f'{em} <b>{nom}</b> — Classement <b>{code}</b> : {lbl}</div>',
                    unsafe_allow_html=True)
        else:
            st.success("✅ Aucune alerte critique.")
    else:
        st.info("Aucune donnée disponible.")


# ══════════════════════════════════════════════════════════════
# PAGE CARTE — code couleur cohérent
# ══════════════════════════════════════════════════════════════

elif PAGE == "Carte":
    import folium
    from streamlit_folium import st_folium

    st.title("🗺️ Carte des élevages")
    st.caption("Localisation et statut de chaque élevage suivi")

    ELV = get_elevages()
    EDE = get_edes()
    RES = get_resultats()

    # ── Construire l'historique Ct par élevage
    last_ct  = {}
    hist_ct  = {}   # num_ede → [{Série, Date, Ct, Statut, val}]
    if not RES.empty:
        for ede_val, grp in RES.groupby("num_ede"):
            gs = grp.sort_values(["annee", "numero_serie", "date_prelevement"])
            ct_last = gs["valeur_ct"].iloc[-1]
            last_ct[ede_val] = f"{float(ct_last):.1f}" if ct_last is not None else "Négatif"
            rows_h = []
            for _, r in gs.iterrows():
                val = r["valeur_ct"]
                try:
                    vf = float(val)
                    statut = "✅ NEG" if vf >= 40 else ("🔴 Fort POS" if vf < 35 else "🟠 POS")
                    ct_str = f"{vf:.1f}"
                except Exception:
                    vf, statut, ct_str = None, "—", "—"
                rows_h.append({
                    "Série": f"{int(r['numero_serie'])} / {int(r['annee'])}",
                    "Date": str(r["date_prelevement"])[:10] if r["date_prelevement"] else "—",
                    "Ct": ct_str, "Statut": statut, "val": vf,
                })
            hist_ct[ede_val] = rows_h

    # ── Légende classements
    leg_cols = st.columns(len(CLASSEMENT))
    for i, (code, (lbl, col, _, _)) in enumerate(CLASSEMENT.items()):
        leg_cols[i].markdown(
            f'<div style="text-align:center;padding:6px 4px;">'
            f'<div style="width:22px;height:22px;border-radius:50%;background:{col};'
            f'margin:0 auto 4px;border:2px solid white;box-shadow:0 1px 4px rgba(0,0,0,.2);"></div>'
            f'<div style="font-size:11px;font-weight:800;color:#1e1b4b;">{code}</div>'
            f'<div style="font-size:10px;color:#6b7280;line-height:1.2;">{lbl}</div>'
            f'</div>', unsafe_allow_html=True)

    st.markdown("<hr>", unsafe_allow_html=True)

    # ── Filtres — même présentation que l'ancienne version
    fc1, fc2, fc3, fc4 = st.columns(4)
    with fc1:
        dep_f = st.multiselect("Départements", ["79","86","16"], default=["79","86","16"], key="f_dep")
    with fc2:
        class_f = st.multiselect(
            "Classements", list(CLASSEMENT.keys()),
            default=list(CLASSEMENT.keys()), key="f_cls",
            format_func=lambda c: f"{CLASSEMENT[c][3]} {c} — {CLASSEMENT[c][0]}")
    with fc3:
        st.write("")
        if st.button("🔄 Recalculer classements", use_container_width=True, type="primary", key="btn_recalc_carte"):
            with st.spinner("Calcul en cours..."):
                recalculer_classements()
            st.success("✅ Classements mis à jour !")
            refresh()
    with fc4:
        st.write("")
        if st.button("↻ Actualiser", use_container_width=True, key="btn_refresh_carte"):
            refresh()

    edes_map = EDE.copy() if not EDE.empty else pd.DataFrame()
    if not edes_map.empty:
        # Nettoyer code_classement : strip + upper + valeur par défaut I
        edes_map["code_classement"] = (
            edes_map["code_classement"]
            .fillna("I")
            .astype(str)
            .str.strip()
            .str.upper()
        )
        # Garder seulement les codes valides A→I
        codes_valides = list(CLASSEMENT.keys())
        edes_map["code_classement"] = edes_map["code_classement"].apply(
            lambda c: c if c in codes_valides else "I")
        edes_map["last_ct"] = edes_map["num_ede"].map(last_ct).fillna("—")
        if dep_f:
            edes_map = edes_map[edes_map["code_departement"].isin(dep_f)]
        if class_f:
            edes_map = edes_map[edes_map["code_classement"].isin(class_f)]

    # ── Carte Folium
    m = folium.Map(location=[46.4, 0.0], zoom_start=8,
                   tiles="OpenStreetMap", control_scale=True)

    # ── Zones géographiques colorées
    ZONES = {
        "79": ("Deux-Sèvres (79)", "#6366f1", [
            [46.9758,-0.892], [46.9777,-0.8571], [46.9913,-0.8114], [47.0038,-0.7843], [46.9919,-0.7429],
            [46.9947,-0.6964], [46.9988,-0.6611], [46.9945,-0.6266], [47.0054,-0.5877], [47.0307,-0.555],
            [47.0606,-0.5571], [47.081,-0.5003], [47.077,-0.4623], [47.0579,-0.4719], [47.0663,-0.4093],
            [47.0927,-0.3659], [47.0956,-0.3082], [47.1033,-0.2632], [47.0973,-0.2148], [47.1067,-0.1759],
            [47.0774,-0.1703], [47.0638,-0.1366], [47.05,-0.0958], [47.012,-0.0895], [46.991,-0.051],
            [46.9665,-0.0462], [46.9269,-0.0156], [46.8713,-0.0304], [46.8529,0.0256], [46.8466,-0.0074],
            [46.8244,-0.0442], [46.8208,-0.0091], [46.783,-0.0213], [46.7602,0.0006], [46.7239,0.0137],
            [46.6933,-0.0212], [46.6626,-0.0327], [46.6266,-0.0663], [46.6397,-0.0168], [46.6207,-0.0103],
            [46.6145,0.0228], [46.5813,0.0136], [46.5498,-0.0007], [46.5248,-0.0229], [46.5006,-0.0386],
            [46.4805,-0.0431], [46.4615,-0.0158], [46.4241,-0.0142], [46.4016,-0.0095], [46.3916,0.0154],
            [46.3571,0.0138], [46.3287,0.0302], [46.3073,0.0829], [46.3402,0.1163], [46.333,0.1742],
            [46.2971,0.1554], [46.2671,0.1555], [46.2284,0.1393], [46.198,0.1124], [46.1756,0.1423],
            [46.1495,0.1897], [46.142,0.2163], [46.1159,0.1982], [46.0835,0.1766], [46.1017,0.129],
            [46.0922,0.1003], [46.0783,0.052], [46.0559,0.0251], [46.0548,-0.0343], [46.0209,-0.0435],
            [45.9942,-0.0387], [45.978,-0.0819], [45.9872,-0.1366], [46.0222,-0.1625], [46.0316,-0.1898],
            [46.0507,-0.247], [46.0866,-0.2933], [46.085,-0.3648], [46.0842,-0.4014], [46.1046,-0.4402],
            [46.1043,-0.4751], [46.1197,-0.5111], [46.1363,-0.5272], [46.1455,-0.573], [46.1394,-0.6211],
            [46.1646,-0.6274], [46.185,-0.6697], [46.1922,-0.6978], [46.2192,-0.6907], [46.2631,-0.7403],
            [46.3041,-0.733], [46.3199,-0.7043], [46.329,-0.6394], [46.3543,-0.6033], [46.3782,-0.5448],
            [46.4102,-0.5942], [46.4023,-0.6311], [46.445,-0.6177], [46.4688,-0.6166], [46.5023,-0.6343],
            [46.5256,-0.6371], [46.5387,-0.603], [46.5646,-0.6176], [46.5953,-0.6145], [46.6192,-0.6173],
            [46.6398,-0.6594], [46.6678,-0.6447], [46.7008,-0.6562], [46.7257,-0.688], [46.7402,-0.6961],
            [46.7649,-0.7223], [46.8005,-0.7178], [46.8208,-0.7128], [46.8322,-0.7592], [46.8513,-0.7857],
            [46.8717,-0.8094], [46.8983,-0.8208], [46.9313,-0.8272], [46.9376,-0.8542], [46.945,-0.8789],
            [46.9522,-0.8642], [46.959,-0.8816], [46.9686,-0.8961], [46.9758,-0.892],
        ]),
        "86": ("Vienne (86)", "#16a34a", [
            [47.0648,-0.1021], [47.0988,-0.0784], [47.0898,-0.034], [47.1436,-0.0216], [47.1653,0.0451],
            [47.1463,0.0784], [47.1221,0.0929], [47.1223,0.1258], [47.102,0.1603], [47.0977,0.1938],
            [47.068,0.1736], [47.055,0.2069], [47.0702,0.2611], [47.0455,0.2717], [47.0351,0.3066],
            [46.9963,0.3116], [46.9751,0.3046], [46.9422,0.309], [46.947,0.3622], [46.934,0.4261],
            [46.9561,0.4951], [46.9555,0.5644], [46.9776,0.5935], [47.0061,0.5856], [46.9867,0.6334],
            [46.9743,0.6926], [46.9212,0.7078], [46.8735,0.7376], [46.859,0.7702], [46.8405,0.7868],
            [46.8035,0.8171], [46.7744,0.8338], [46.7443,0.8747], [46.7257,0.9132], [46.6877,0.9144],
            [46.6518,0.9165], [46.6176,0.9051], [46.5948,0.9351], [46.5711,0.9637], [46.5673,1.0024],
            [46.5367,1.0379], [46.5377,1.0913], [46.4976,1.1334], [46.4577,1.1454], [46.4292,1.1834],
            [46.4141,1.1976], [46.3892,1.157], [46.36,1.1301], [46.3588,1.0745], [46.339,1.0253],
            [46.3138,1.0228], [46.291,1.0026], [46.2853,0.977], [46.2855,0.9328], [46.2894,0.8993],
            [46.2512,0.8592], [46.2287,0.848], [46.2121,0.7935], [46.1935,0.8182], [46.1746,0.8283],
            [46.1536,0.8312], [46.1312,0.8355], [46.133,0.8014], [46.1339,0.774], [46.1361,0.7381],
            [46.123,0.6884], [46.0977,0.6741], [46.0936,0.6246], [46.0746,0.598], [46.0891,0.5625],
            [46.0994,0.533], [46.1248,0.5041], [46.1297,0.4749], [46.1037,0.4467], [46.087,0.4679],
            [46.0682,0.4693], [46.0499,0.4292], [46.0621,0.3791], [46.0655,0.332], [46.0608,0.2845],
            [46.0804,0.2435], [46.0958,0.2026], [46.1301,0.1994], [46.1581,0.2202], [46.1558,0.1719],
            [46.1807,0.137], [46.2077,0.1111], [46.2323,0.1428], [46.2666,0.1596], [46.2971,0.1554],
            [46.3316,0.1744], [46.345,0.1214], [46.3113,0.0834], [46.3239,0.0403], [46.3457,0.0366],
            [46.3819,0.0234], [46.3941,-0.0063], [46.4128,-0.0165], [46.4363,-0.0152], [46.4755,-0.016],
            [46.4873,-0.0356], [46.5118,-0.0307], [46.5262,-0.0148], [46.5528,-0.0105], [46.5851,0.0201],
            [46.6147,0.0204], [46.6207,-0.0103], [46.6401,-0.0139], [46.6226,-0.0593], [46.6575,-0.0345],
            [46.6842,-0.0079], [46.7109,0.0032], [46.7469,0.0162], [46.7651,-0.0202], [46.8056,0.0003],
            [46.8204,-0.0364], [46.839,-0.0297], [46.8418,0.0062], [46.8623,0.0017], [46.8769,-0.0313],
            [46.9385,-0.0222], [46.97,-0.0435], [46.9919,-0.0532], [47.012,-0.0895], [47.0483,-0.0943],
            [47.0648,-0.1021],
        ]),
        "16": ("Charente (16)", "#d97706", [
            [45.9697,-0.1029], [45.9893,-0.0478], [46.0031,-0.0489], [46.0359,-0.0296], [46.0555,-0.0009],
            [46.068,0.0424], [46.0912,0.0664], [46.103,0.0926], [46.0959,0.1461], [46.0885,0.1865],
            [46.089,0.2274], [46.0724,0.2608], [46.0651,0.3144], [46.0639,0.3553], [46.0597,0.4039],
            [46.0516,0.4496], [46.077,0.4757], [46.0868,0.4479], [46.1124,0.4631], [46.134,0.4916],
            [46.1167,0.5153], [46.0864,0.5444], [46.081,0.5797], [46.0856,0.6062], [46.0947,0.6485],
            [46.1066,0.682], [46.1363,0.711], [46.1384,0.7551], [46.1295,0.787], [46.1337,0.8151],
            [46.1178,0.8171], [46.0953,0.8323], [46.0663,0.8258], [46.046,0.829], [46.0219,0.8578],
            [46.0254,0.8939], [46.0092,0.9264], [45.9864,0.9323], [45.9701,0.9435], [45.9509,0.9237],
            [45.9269,0.8908], [45.9241,0.835], [45.9202,0.8125], [45.8946,0.8167], [45.8698,0.8149],
            [45.8369,0.802], [45.8101,0.7831], [45.7891,0.7684], [45.8039,0.7383], [45.7903,0.7113],
            [45.7618,0.7008], [45.7406,0.6607], [45.7176,0.6402], [45.6994,0.6224], [45.6774,0.5984],
            [45.6586,0.5839], [45.6449,0.5733], [45.6316,0.5408], [45.6416,0.5273], [45.6131,0.5038],
            [45.5896,0.514], [45.5588,0.5069], [45.5384,0.4737], [45.5143,0.4454], [45.4849,0.4209],
            [45.4787,0.379], [45.4608,0.346], [45.4499,0.3246], [45.4357,0.3177], [45.4208,0.2714],
            [45.388,0.2573], [45.3496,0.259], [45.3023,0.2673], [45.2918,0.2302], [45.2624,0.2031],
            [45.2492,0.1715], [45.2249,0.1513], [45.2112,0.1222], [45.2206,0.0662], [45.2037,0.0205],
            [45.2178,0.0053], [45.2345,-0.0334], [45.2463,-0.0902], [45.2774,-0.1115], [45.2899,-0.143],
            [45.3082,-0.1779], [45.3204,-0.2217], [45.3071,-0.258], [45.3163,-0.283], [45.3462,-0.2727],
            [45.3575,-0.2511], [45.3704,-0.2902], [45.3873,-0.2913], [45.401,-0.2505], [45.4178,-0.2431],
            [45.4384,-0.2531], [45.4575,-0.2793], [45.4844,-0.2584], [45.5031,-0.2473], [45.5251,-0.2661],
            [45.5288,-0.2992], [45.5494,-0.307], [45.58,-0.32], [45.5979,-0.3606], [45.6249,-0.3848],
            [45.6211,-0.4251], [45.6544,-0.3915], [45.7006,-0.4167], [45.732,-0.4056], [45.7586,-0.4531],
            [45.7691,-0.4063], [45.7837,-0.3756], [45.7853,-0.3226], [45.8036,-0.2821], [45.7962,-0.2435],
            [45.7773,-0.2196], [45.7877,-0.1661], [45.7965,-0.1553], [45.8277,-0.1376], [45.8594,-0.123],
            [45.8914,-0.1354], [45.9105,-0.1358], [45.9291,-0.1348], [45.9443,-0.0888], [45.9697,-0.1029],
        ]),
    }

    for dep, (name, color, poly) in ZONES.items():
        if dep_f and dep not in dep_f:
            continue
        folium.Polygon(
            locations=poly, color=color, weight=2.5,
            fill=True, fill_color=color, fill_opacity=0.07,
            tooltip=f"<b>{name}</b>"
        ).add_to(m)
        clat = sum(c[0] for c in poly) / len(poly)
        clon = sum(c[1] for c in poly) / len(poly)
        folium.Marker([clat, clon], icon=folium.DivIcon(
            html=f'<div style="font-size:12px;font-weight:700;color:{color};'
                 f'text-shadow:1px 1px 3px white,-1px -1px 3px white;'
                 f'white-space:nowrap;">{name}</div>',
            icon_size=(230, 28), icon_anchor=(115, 14)
        )).add_to(m)

    if not edes_map.empty:
        for _, row in edes_map.iterrows():
            ede  = row.get("num_ede", "")
            lat, lon = get_coords(ede)
            code = str(row.get("code_classement") or "I").upper()
            inf  = CLASSEMENT.get(code, CLASSEMENT["I"])
            map_col = MAP_COLORS.get(code, "#9ca3af")
            nom  = row.get("nom_exploitant", "—") or "—"
            ct   = row.get("last_ct", "—")
            radius = 14 if code in ("B","C","D") else 11 if code in ("E","F","G") else 9

            # Tableau des 6 derniers résultats dans le popup
            hist = hist_ct.get(ede, [])
            derniers = hist[-6:]
            rows_html = ""
            for h in reversed(derniers):
                bg = "#fef2f2" if h["val"] is not None and h["val"] < 40 else "#f0fdf4"
                rows_html += (
                    f'<tr style="background:{bg};">'
                    f'<td style="padding:3px 7px;font-size:11px;">{h["Série"]}</td>'
                    f'<td style="padding:3px 7px;font-size:11px;">{h["Date"]}</td>'
                    f'<td style="padding:3px 7px;font-size:11px;font-weight:700;">{h["Ct"]}</td>'
                    f'<td style="padding:3px 7px;font-size:11px;">{h["Statut"]}</td>'
                    "</tr>"
                )
            table_html = (
                f'<table style="width:100%;border-collapse:collapse;margin-top:6px;">'
                f'<thead><tr style="background:#e0e7ff;">'
                f'<th style="padding:3px 7px;font-size:11px;text-align:left;">Série/An</th>'
                f'<th style="padding:3px 7px;font-size:11px;text-align:left;">Date</th>'
                f'<th style="padding:3px 7px;font-size:11px;text-align:left;">Ct</th>'
                f'<th style="padding:3px 7px;font-size:11px;text-align:left;">Statut</th>'
                f'</tr></thead><tbody>{rows_html}</tbody></table>'
            ) if derniers else "<p style=\'font-size:11px;color:#9ca3af;\'>Aucun résultat</p>"

            popup_html = f"""
<div style="font-family:Inter,sans-serif;min-width:290px;max-width:350px;">
  <div style="background:#1e1b4b;color:white;padding:9px 14px;
              border-radius:10px 10px 0 0;font-weight:700;font-size:14px;">{ede}</div>
  <div style="padding:12px 14px;background:white;border:1px solid #e5e7eb;
              border-top:none;border-radius:0 0 10px 10px;">
    <div style="margin-bottom:5px;color:#374151;font-size:13px;">👤 {nom}</div>
    <div style="margin-bottom:5px;">
      <span style="background:{map_col};color:white;border-radius:12px;
                   padding:3px 10px;font-size:12px;font-weight:700;">
        {code} — {inf[0]}</span></div>
    <div style="color:#6b7280;font-size:12px;margin-bottom:5px;">
      <b>Dep. {row.get("code_departement","")}</b> &nbsp;|&nbsp; Dernier Ct : {ct}</div>
    <div style="font-size:11px;font-weight:700;color:#1e1b4b;margin-bottom:2px;">
      📋 {len(hist)} résultat(s) — 6 derniers :</div>
    {table_html}
  </div>
</div>"""

            folium.CircleMarker(
                [lat, lon], radius=radius,
                color="white", weight=2,
                fill=True, fill_color=map_col, fill_opacity=0.92,
                tooltip=f"{ede} — {nom} ({code})",
                popup=folium.Popup(popup_html, max_width=370)
            ).add_to(m)

    map_data = st_folium(m, width=None, height=520,
                         returned_objects=["last_object_clicked_tooltip"])

    # ── Fiche détaillée sur clic carte
    clicked_ede = None
    if map_data and map_data.get("last_object_clicked_tooltip"):
        tip = str(map_data["last_object_clicked_tooltip"])
        clicked_ede = tip.split(" — ")[0].strip() if " — " in tip else None

    if clicked_ede and clicked_ede in hist_ct:
        _afficher_fiche_elevage(clicked_ede, EDE, hist_ct, MAP_COLORS, CLASSEMENT, key_prefix="click")

    st.markdown("<hr>", unsafe_allow_html=True)

    # ── Recherche élevage — filtre la carte sur cet élevage
    st.subheader("🔍 Rechercher un élevage")
    if not EDE.empty:
        opts = ["— Tous les élevages —"] + [
            f"{r['num_ede']} — {r['nom_exploitant']}" if r["nom_exploitant"] else r["num_ede"]
            for _, r in EDE.iterrows()
        ]
        choix = st.selectbox("Sélectionner un élevage pour le mettre en avant",
            opts, key="search_elv_carte",
            help="Sélectionner un élevage pour zoomer dessus sur la carte et voir sa fiche.")
        ede_zoom = None
        if choix and choix != "— Tous les élevages —":
            ede_zoom = choix.split(" — ")[0].strip()

        if ede_zoom:
            # Afficher la fiche
            if ede_zoom in hist_ct:
                _afficher_fiche_elevage(ede_zoom, EDE, hist_ct, MAP_COLORS, CLASSEMENT, key_prefix="search")
            # Reconstruire la carte centrée + zoomée sur cet élevage seulement
            row_zoom = EDE[EDE["num_ede"] == ede_zoom]
            if not row_zoom.empty:
                lat_z, lon_z = get_coords(ede_zoom)
                m_zoom = folium.Map(location=[lat_z, lon_z], zoom_start=13,
                                    tiles="OpenStreetMap", control_scale=True)
                row_z = row_zoom.iloc[0]
                code_z   = str(row_z.get("code_classement") or "I").strip().upper()
                code_z   = code_z if code_z in CLASSEMENT else "I"
                map_col_z = MAP_COLORS.get(code_z, "#9ca3af")
                inf_z    = CLASSEMENT.get(code_z, CLASSEMENT["I"])
                nom_z    = row_z.get("nom_exploitant", "—") or "—"
                folium.CircleMarker(
                    [lat_z, lon_z], radius=18,
                    color="white", weight=3,
                    fill=True, fill_color=map_col_z, fill_opacity=0.95,
                    tooltip=f"{ede_zoom} — {nom_z} ({code_z})",
                    popup=folium.Popup(f"<b>{ede_zoom}</b><br>{nom_z}<br>Classement : {code_z} — {inf_z[0]}", max_width=250)
                ).add_to(m_zoom)
                st.markdown("**📍 Position sur la carte**")
                st.caption("Le point indique le centre de la commune de l'élevage.")
                st_folium(m_zoom, width=None, height=350, returned_objects=[])

    st.markdown("<hr>", unsafe_allow_html=True)
    st.subheader("📋 Élevages affichés")
    if not edes_map.empty:
        df_show = edes_map[["num_ede","nom_exploitant","code_departement","code_classement","last_ct"]].copy()
        df_show["Classement"] = df_show["code_classement"].map(
            lambda c: f"{CLASSEMENT.get(c or 'I', CLASSEMENT['I'])[3]} "
                      f"{c or 'I'} — {CLASSEMENT.get(c or 'I', CLASSEMENT['I'])[0]}")
        st.dataframe(df_show.rename(columns={
            "num_ede":"N° EDE","nom_exploitant":"Exploitant",
            "code_departement":"Dep.","code_classement":"Code","last_ct":"Dernier Ct"}),
            use_container_width=True, height=260, hide_index=True)
    else:
        st.info("Aucun élevage à afficher avec ces filtres.")

elif PAGE == "Import Excel":
    st.title("📥 Import de fichier Excel")
    st.caption("Importez vos fichiers GDS79, GDS86 ou Compilation dans la base")

    onglet_actuel, onglet_histo = st.tabs(["📂 Import 2023 et après", "🗂️ Import avant 2023"])

    # ONGLET 1 — Import standard (2023 et après)
    with onglet_actuel:
        if IMPORT_OK is None:
            try:
                from import_alwaysdata import importer_fichier as _importer
                IMPORT_OK = True
            except ImportError:
                IMPORT_OK = False
        if not IMPORT_OK:
            st.error("❌ Le fichier `import_alwaysdata.py` est introuvable dans le dossier de l'application.")
        else:
            from import_alwaysdata import importer_fichier

            col_form, col_info = st.columns([3, 2])

            with col_form:
                st.markdown('<div class="card">', unsafe_allow_html=True)
                st.subheader("📂 Choisissez vos fichiers Excel")
                st.caption("Sélectionnez un ou plusieurs fichiers Excel GDS. La série et l'année sont détectées automatiquement. Chaque fichier est importé indépendamment.")
                fichiers = st.file_uploader(
                    "", type=["xlsx", "xls"],
                    label_visibility="collapsed",
                    accept_multiple_files=True,
                    key="uploader_actuel",
                    help="Formats acceptés : .xlsx (GDS79/GDS86) et .xls (anciens formats).")

                if fichiers:
                    for f in fichiers:
                        _s, _a = _detecter_serie_annee_nom(f.name)
                        if _s and _a:
                            st.success(f"✅ **{f.name}** ({round(f.size/1024,1)} Ko) → détecté **Série {_s} — {_a}**")
                        else:
                            st.warning(f"⚠️ **{f.name}** — série/année non détectée, sera importé en Série 1 — 2026")
                st.markdown("</div>", unsafe_allow_html=True)

                st.markdown("<br>", unsafe_allow_html=True)
                cb1, _ = st.columns([2, 3])
                btn_import = cb1.button("🚀 Lancer l'import", type="primary",
                                        use_container_width=True, disabled=(not fichiers))

                if btn_import and fichiers:
                    if EN_LIGNE:
                        db_cfg_tunnel = DB_CONFIG
                    else:
                        tunnel = get_tunnel()
                        db_cfg_tunnel = {**DB_CONFIG, "port": tunnel.local_bind_port} if tunnel and tunnel.is_active else DB_CONFIG
                    resultats_import = []
                    for f in fichiers:
                        with st.spinner(f"Import de **{f.name}** en cours..."):
                            _s_imp, _a_imp = _detecter_serie_annee_nom(f.name)
                            ok, message = importer_fichier(
                                fichier=f, config_db=db_cfg_tunnel,
                                numero_serie=_s_imp or 1, annee=_a_imp or 2026)
                        if ok:
                            st.success(f"✅ {f.name} — {message}")
                            resultats_import.append(True)
                        else:
                            st.error(f"❌ {f.name} — {message}")
                            resultats_import.append(False)
                    if any(resultats_import):
                        st.balloons()
                        with st.spinner("Recalcul des classements A–I..."):
                            recalculer_classements()
                            refresh()
                        st.info("ℹ️ Classements recalculés automatiquement.")

            with col_info:
                st.markdown("""
                <div class="card">
                <h3 style="margin-top:0;">ℹ️ Comment ça marche</h3>
                <p style="color:#6b7280;font-size:13px;line-height:1.7;">
                Le programme <code>import_alwaysdata.py</code> lit automatiquement
                votre fichier, détecte le format et insère les données en base.
                </p>
                <hr>
                <b style="font-size:13px;">📁 Formats acceptés</b>
                <div style="color:#6b7280;font-size:13px;line-height:1.9;margin-top:4px;">
                • GDS79 <code>.xlsx</code><br>
                • GDS86 <code>.xlsx</code><br>
                • Compilation <code>.xls</code>
                </div>
                <hr>
                <b style="font-size:13px;">✅ Ce qui est importé</b>
                <div style="color:#6b7280;font-size:13px;line-height:1.9;margin-top:4px;">
                • Élevages + EDE (créés si nouveaux)<br>
                • Prélèvements (date, matrice, panier)<br>
                • Résultats PCR (valeur Ct)<br>
                • Série créée automatiquement
                </div>
                <hr>
                <b style="font-size:13px;">⚙️ Après l'import</b>
                <div style="color:#6b7280;font-size:13px;line-height:1.9;margin-top:4px;">
                Les classements A–I sont recalculés automatiquement.
                </div>
                </div>
                """, unsafe_allow_html=True)

                SER = get_series()
                if not SER.empty:
                    st.markdown('<div class="card">', unsafe_allow_html=True)
                    st.markdown("**📋 Séries déjà en base**")
                    for _, row in SER.iterrows():
                        st.markdown(
                            f"<div style='padding:4px 0;font-size:13px;color:#374151;'>"                            f"📅 Série <b>{row['numero_serie']}</b> — <b>{row['annee']}</b></div>",
                            unsafe_allow_html=True)
                    st.markdown("</div>", unsafe_allow_html=True)

    # ONGLET 2 — Import historique (avant 2023)
    with onglet_histo:
        HISTO_OK = False
        try:
            from import_historique import importer_historique
            HISTO_OK = True
        except ImportError:
            st.error("❌ Le fichier `import_historique.py` est introuvable dans le dossier de l'application.")

        if HISTO_OK:
            col_h, col_hinfo = st.columns([3, 2])

            with col_h:
                st.markdown('<div class="card">', unsafe_allow_html=True)
                st.subheader("🗂️ Import des données avant 2023")
                st.caption("Deux fichiers sont nécessaires : un pour M. mycoïdes, un pour M. agalactiae.")

                fics_histo = st.file_uploader(
                    "Fichiers historiques (mycoïdes + agalactiae)", type=["xlsx", "xls"],
                    key="uploader_histo",
                    accept_multiple_files=True,
                    help="Sélectionner les 2 fichiers en même temps : un mycoïdes et un agalactiae.")

                # Identifier automatiquement lequel est mycoïdes et lequel est agalactiae
                fic_mycoides   = None
                fic_agalactiae = None
                if fics_histo:
                    for f in fics_histo:
                        nom = f.name.lower()
                        if "mycoid" in nom or "myco" in nom:
                            fic_mycoides = f
                        elif "agalac" in nom or "agal" in nom:
                            fic_agalactiae = f
                    # Si on n'arrive pas à distinguer par le nom, prendre dans l'ordre
                    if len(fics_histo) == 2 and (fic_mycoides is None or fic_agalactiae is None):
                        fic_mycoides   = fics_histo[0]
                        fic_agalactiae = fics_histo[1]
                    if fic_mycoides:
                        st.success(f"✅ Mycoïdes : **{fic_mycoides.name}**")
                    if fic_agalactiae:
                        st.success(f"✅ Agalactiae : **{fic_agalactiae.name}**")
                    if not fic_mycoides and not fic_agalactiae:
                        st.warning("⚠️ Aucun fichier reconnu. Vérifiez que le nom contient 'myco' ou 'agal'.")

                st.markdown("</div>", unsafe_allow_html=True)

                st.markdown("<br>", unsafe_allow_html=True)
                ch1, _ = st.columns([2, 3])
                # Au moins un fichier suffit pour lancer l'import
                btn_histo = ch1.button(
                    "🚀 Lancer l'import historique", type="primary",
                    use_container_width=True,
                    disabled=(not fics_histo))

                if btn_histo and fics_histo:
                    if EN_LIGNE:
                        db_cfg_tunnel = DB_CONFIG
                    else:
                        tunnel = get_tunnel()
                        db_cfg_tunnel = {**DB_CONFIG, "port": tunnel.local_bind_port} if tunnel and tunnel.is_active else DB_CONFIG
                    with st.spinner("Import des données historiques en cours..."):
                        # Passer seulement les fichiers effectivement uploadés
                        ok, message = importer_historique(
                            fichier_mycoides=fic_mycoides if fic_mycoides else None,
                            fichier_agalactiae=fic_agalactiae if fic_agalactiae else None,
                            config_db=db_cfg_tunnel)
                    if ok:
                        st.success(f"✅ {message}")
                        st.balloons()
                        with st.spinner("Recalcul des classements A–I..."):
                            recalculer_classements()
                            refresh()
                        st.info("ℹ️ Classements recalculés automatiquement.")
                    else:
                        st.error(f"❌ {message}")

            with col_hinfo:
                st.markdown("""
                <div class="card">
                <h3 style="margin-top:0;">ℹ️ Format attendu</h3>
                <p style="color:#6b7280;font-size:13px;line-height:1.7;">
                Les fichiers historiques ont un format <b>pivot</b> :
                une ligne par élevage, une colonne par combinaison série/année.
                </p>
                <hr>
                <b style="font-size:13px;">📁 Colonnes attendues</b>
                <div style="color:#6b7280;font-size:13px;line-height:1.9;margin-top:4px;">
                • <code>N° EDE</code> — identifiant de l'élevage<br>
                • <code>2018_serie1.PCR M mycoïdes</code><br>
                • <code>2019_serie2.PCR M agalactiae</code><br>
                • etc.
                </div>
                <hr>
                <b style="font-size:13px;">📅 Années couvertes</b>
                <div style="color:#6b7280;font-size:13px;line-height:1.9;margin-top:4px;">
                2018 → 2022, séries 1 à 3<br>
                (M. capricolum et M. putrefaciens non disponibles avant 2023)
                </div>
                </div>
                """, unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════
# PAGE ÉLEVAGES
# ══════════════════════════════════════════════════════════════

elif PAGE == "Élevages":
    st.title("🐄 Élevages")
    ELV = get_elevages()

    c1, c2 = st.columns([4, 2])
    with c1:
        srch = st.text_input("🔎", placeholder="Rechercher nom, classement...",
                              label_visibility="collapsed")
    with c2:
        if st.button("↻ Actualiser", use_container_width=True): refresh()

    EDE_s = get_edes()
    df_f = ELV.copy()
    if srch and not ELV.empty:
        df_f = ELV[
            ELV["nom_exploitant"].fillna("").str.lower().str.contains(srch.lower()) |
            ELV["code_classement"].fillna("").str.lower().str.contains(srch.lower())]
    # Joindre le num_ede pour l'afficher
    if not df_f.empty and not EDE_s.empty:
        ede_mini = EDE_s[["id_elevage","num_ede","code_departement"]].drop_duplicates("id_elevage")
        df_f = df_f.merge(ede_mini, on="id_elevage", how="left")

    if not df_f.empty:
        st.write(f"**{len(df_f)} élevage(s)**")
        cols_elv = [c for c in ["id_elevage","num_ede","nom_exploitant","code_departement","code_classement"] if c in df_f.columns]
        st.dataframe(df_f[cols_elv].rename(columns={
            "id_elevage":"ID","num_ede":"N° EDE","nom_exploitant":"Exploitant",
            "code_departement":"Dep.","code_classement":"Classement"}),
            use_container_width=True, height=280, hide_index=True)
    else:
        st.info("Aucun élevage.")

    st.markdown("<hr>", unsafe_allow_html=True)
    t1, t2, t3 = st.tabs(["➕  Ajouter","✏️  Modifier","🗑️  Supprimer"])

    with t1:
        with st.form("add_elv", clear_on_submit=True):
            st.subheader("➕ Nouvel élevage")
            st.caption("Créer une nouvelle fiche élevage et son identifiant EDE dans la base.")
            c1, c2 = st.columns(2)
            nom = c1.text_input("Nom de l'exploitant *",
                placeholder="ex : DUPONT Jean",
                help="Nom et prénom du responsable de l'élevage. Obligatoire.")
            ede_new = c2.text_input("N° EDE *",
                placeholder="ex : 79001122",
                help="8 chiffres : département(2) + commune(3) + ordre(3). Ex: 79001122 = Deux-Sèvres, commune 001, exploitation 122.")
            c3, c4 = st.columns(2)
            code = c3.selectbox("Classement initial",
                [""] + list(CLASSEMENT.keys()),
                format_func=lambda x: x if not x else f"{x} — {CLASSEMENT[x][0]}",
                help="Laisser vide si inconnu, il sera calculé automatiquement après import des résultats PCR.")
            if st.form_submit_button("✔ Enregistrer l'élevage", type="primary", use_container_width=True):
                ede_clean = ede_new.strip().replace(" ", "")
                if not nom.strip():
                    st.error("❌ Le nom de l'exploitant est obligatoire.")
                elif not ede_clean.isdigit() or len(ede_clean) != 8:
                    st.error("❌ Le N° EDE doit contenir exactement 8 chiffres.")
                else:
                    # Créer l'élevage
                    id_elv = q("INSERT INTO elevage (nom_exploitant, code_classement) VALUES (%s,%s)",
                               (nom.strip(), code or None), fetch=False)
                    if id_elv:
                        # Créer l'EDE associé
                        code_dept    = ede_clean[0:2]
                        code_commune = ede_clean[2:5]
                        num_ordre    = ede_clean[5:8]
                        q("INSERT IGNORE INTO ede (num_ede, code_departement, code_commune, num_ordre, id_elevage) VALUES (%s,%s,%s,%s,%s)",
                          (ede_clean, code_dept, code_commune, num_ordre, id_elv), fetch=False)
                        # Ajouter les coordonnées de la commune dans coords_communes.py si absentes
                        from coords_communes import COORDS_COMMUNES
                        commune_key = ede_clean[:5]
                        if commune_key not in COORDS_COMMUNES:
                            dep_coords = {"79": (46.32, -0.46), "86": (46.58, 0.34), "16": (45.90, 0.08)}
                            lat, lon = dep_coords.get(code_dept, (46.4, 0.0))
                            try:
                                import os
                                coords_path = os.path.join(os.path.dirname(__file__), "coords_communes.py")
                                with open(coords_path, "r", encoding="utf-8") as _f:
                                    _src = _f.read()
                                nouvelle_ligne = '    "' + commune_key + '": (' + str(lat) + ', ' + str(lon) + '),\n'
                                _src = _src.replace("}", nouvelle_ligne + "}")
                                with open(coords_path, "w", encoding="utf-8") as _f:
                                    _f.write(_src)
                                st.info(f"📍 Commune {commune_key} ajoutée à coords_communes.py (centre département par défaut).")
                            except Exception as _e:
                                st.warning(f"⚠️ Coordonnées non ajoutées : {_e}")
                        st.success(f"✅ Élevage **{nom.strip()}** (EDE {ede_clean}) ajouté !"); refresh()
                    else:
                        st.error("❌ Erreur lors de l'ajout en base.")

    with t2:
        EDE_mod = get_edes()
        if EDE_mod.empty:
            st.info("Aucun élevage en base.")
        else:
            with st.form("edit_elv"):
                st.subheader("✏️ Modifier un élevage existant")
                st.caption("Corriger le nom de l'exploitant ou le classement d'un élevage existant.")
                opts_elv = [f"{r['num_ede']} — {r['nom_exploitant'] or '?'}" for _, r in EDE_mod.iterrows()]
                sel_str = st.selectbox("Élevage à modifier", opts_elv,
                    help="Sélectionner l'élevage par son numéro EDE et le nom de l'exploitant.")
                ede_sel = sel_str.split(" — ")[0].strip()
                row_e = EDE_mod[EDE_mod["num_ede"] == ede_sel].iloc[0]
                id_elv_e = int(row_e["id_elevage"])
                c1, c2 = st.columns(2)
                nom_e = c1.text_input("Nouveau nom exploitant",
                    value=str(row_e["nom_exploitant"] or ""),
                    help="Modifier uniquement si le nom a changé.")
                opts = [""] + list(CLASSEMENT.keys())
                curr = str(row_e["code_classement"] or "")
                code_e = c2.selectbox("Classement",
                    opts, index=opts.index(curr) if curr in opts else 0,
                    format_func=lambda x: x if not x else f"{x} — {CLASSEMENT[x][0]}",
                    help="Le classement est normalement recalculé automatiquement après import.")
                if st.form_submit_button("✔ Enregistrer les modifications", type="primary", use_container_width=True):
                    q("UPDATE elevage SET nom_exploitant=%s, code_classement=%s WHERE id_elevage=%s",
                      (nom_e or None, code_e or None, id_elv_e), fetch=False)
                    st.success("✅ Élevage modifié !"); refresh()

    with t3:
        EDE_sup = get_edes()
        if EDE_sup.empty:
            st.info("Aucun élevage en base.")
        else:
            with st.form("del_elv"):
                st.subheader("🗑️ Retirer un élevage de la base")
                st.warning("⚠️ Supprime l'élevage ET tous ses prélèvements et résultats PCR associés. Irréversible.")
                opts_sup = [f"{r['num_ede']} — {r['nom_exploitant'] or '?'}" for _, r in EDE_sup.iterrows()]
                sel_sup = st.selectbox("Élevage à supprimer", opts_sup,
                    help="Choisir l'élevage à retirer définitivement de la base.")
                ede_sup = sel_sup.split(" — ")[0].strip()
                row_sup = EDE_sup[EDE_sup["num_ede"] == ede_sup].iloc[0]
                id_sup = int(row_sup["id_elevage"])
                ok_sup = st.checkbox("Je confirme la suppression définitive de cet élevage et de tous ses résultats")
                if st.form_submit_button("🗑️ Supprimer définitivement", type="primary", use_container_width=True):
                    if ok_sup:
                        q("DELETE FROM prelevement WHERE num_ede=%s", (ede_sup,), fetch=False)
                        q("DELETE FROM ede WHERE num_ede=%s", (ede_sup,), fetch=False)
                        q("DELETE FROM elevage WHERE id_elevage=%s", (id_sup,), fetch=False)
                        st.success(f"✅ Élevage {ede_sup} supprimé."); refresh()
                    else:
                        st.error("Cochez la case de confirmation.")


# ══════════════════════════════════════════════════════════════
# PAGE PRÉLÈVEMENTS
# ══════════════════════════════════════════════════════════════

elif PAGE == "Prélèvements":
    st.title("🧪 Prélèvements")
    PREL = get_prelevements(); EDE = get_edes(); SER = get_series()

    c1, c2 = st.columns([4, 2])
    with c1:
        srch = st.text_input("🔎", placeholder="EDE, exploitant...",
                              label_visibility="collapsed")
    with c2:
        if st.button("↻ Actualiser", use_container_width=True): refresh()

    df_f = PREL
    if srch and not PREL.empty:
        df_f = PREL[
            PREL["num_ede"].fillna("").str.lower().str.contains(srch.lower()) |
            PREL["nom_exploitant"].fillna("").str.lower().str.contains(srch.lower())]

    cols_s = [c for c in ["num_prelevement","date_prelevement","matrice","num_panier",
                            "num_ede","nom_exploitant","annee","numero_serie"]
              if not PREL.empty and c in PREL.columns]
    if cols_s:
        st.write(f"**{len(df_f)} prélèvement(s)**")
        st.dataframe(df_f[cols_s].rename(columns={
            "num_prelevement":"N° Prél.","date_prelevement":"Date",
            "matrice":"Matrice","num_panier":"Panier","num_ede":"EDE",
            "nom_exploitant":"Exploitant","annee":"Année","numero_serie":"Série"}),
            use_container_width=True, height=280, hide_index=True)

    st.markdown("<hr>", unsafe_allow_html=True)
    t1, t2 = st.tabs(["➕  Ajouter","🗑️  Supprimer"])

    with t1:
        with st.form("add_prel", clear_on_submit=True):
            st.subheader("➕ Nouveau prélèvement")
            st.caption("Un prélèvement = un échantillon de lait de tank prélevé dans un élevage à une date donnée.")
            c1, c2, c3 = st.columns(3)
            num_p  = c1.text_input("N° prélèvement *",
                placeholder="ex : P2401001",
                help="Numéro d'identification unique attribué par le labo LILco. Figurant sur le bon de résultat.")
            date_p = c2.date_input("Date du prélèvement *",
                value=date.today(),
                help="Date à laquelle l'échantillon a été prélevé dans l'élevage.")
            mat    = c3.text_input("Matrice",
                placeholder="Lait de tank",
                help="Type d'échantillon analysé. Laisser vide pour utiliser 'Lait de tank' par défaut.")
            c4, c5, c6 = st.columns(3)
            pan   = c4.text_input("N° panier",
                placeholder="ex : Panier 1",
                help="Numéro du panier de collecte GDS. Laisser vide pour utiliser 'Panier 1' par défaut.")
            edes_ = EDE["num_ede"].tolist() if not EDE.empty else []
            ede_s = c5.selectbox("Élevage (N° EDE) *",
                edes_ if edes_ else ["—"],
                help="Numéro EDE de l'élevage concerné par ce prélèvement.")
            sers_ = SER["id_serie"].tolist() if not SER.empty else []
            ser_s = c6.selectbox("Série d'analyse *", sers_,
                format_func=lambda x: f"S{SER[SER['id_serie']==x].iloc[0]['numero_serie']} — {SER[SER['id_serie']==x].iloc[0]['annee']}" if not SER.empty else str(x),
                help="Série dans laquelle ce prélèvement s'inscrit (S1=janv-avr, S2=mai-août, S3=sept-déc).")
            if st.form_submit_button("✔ Enregistrer le prélèvement", type="primary", use_container_width=True):
                if not num_p.strip():
                    st.error("❌ Le numéro de prélèvement est obligatoire.")
                elif not edes_:
                    st.error("❌ Aucun élevage en base. Créez d'abord un élevage.")
                else:
                    q("INSERT INTO prelevement (num_prelevement, date_prelevement, matrice, num_panier, num_ede, id_serie) VALUES (%s,%s,%s,%s,%s,%s)",
                      (num_p.strip(), date_p, mat.strip() or "Lait de tank",
                       pan.strip() or "Panier 1",
                       ede_s if edes_ else None,
                       ser_s if sers_ else None), fetch=False)
                    st.success("✅ Prélèvement enregistré !"); refresh()

    with t2:
        if PREL.empty:
            st.info("Aucun prélèvement en base.")
        else:
            with st.form("del_prel"):
                st.subheader("🗑️ Retirer un prélèvement")
                st.warning("⚠️ Supprime uniquement le prélèvement, pas le résultat PCR associé.")
                opts_prel = []
                for _, r in PREL.iterrows():
                    label = f"{r['num_prelevement']} — {r.get('num_ede','?')} ({str(r.get('date_prelevement','?'))[:10]})"
                    opts_prel.append((label, r["num_prelevement"]))
                sel_label = st.selectbox("Prélèvement à supprimer",
                    [o[0] for o in opts_prel],
                    help="Choisir le prélèvement à retirer. Format : N°prélèvement — EDE (date).")
                sel_num = [o[1] for o in opts_prel if o[0] == sel_label][0]
                ok_p = st.checkbox("Je confirme la suppression de ce prélèvement")
                if st.form_submit_button("🗑️ Supprimer ce prélèvement", type="primary", use_container_width=True):
                    if ok_p:
                        q("DELETE FROM prelevement WHERE num_prelevement=%s", (sel_num,), fetch=False)
                        st.success("✅ Prélèvement supprimé."); refresh()
                    else:
                        st.error("Cochez la case de confirmation.")


# ══════════════════════════════════════════════════════════════
# PAGE RÉSULTATS PCR
# ══════════════════════════════════════════════════════════════

elif PAGE == "Résultats PCR":
    st.title("📋 Résultats PCR")
    RES = get_resultats(); PREL = get_prelevements()

    c1, c2, c3 = st.columns([3, 2, 1])
    with c1:
        f_ede = st.text_input("🔎 EDE", placeholder="Filtrer par EDE...",
                               label_visibility="collapsed")
    with c2:
        annees = (["Toutes"] +
                  sorted(RES["annee"].dropna().unique().astype(int).tolist(), reverse=True)
                  if not RES.empty else ["Toutes"])
        f_an = st.selectbox("Année", annees, label_visibility="collapsed")
    with c3:
        if st.button("↻", use_container_width=True): refresh()

    res_f = RES.copy()
    if f_ede and not res_f.empty:
        res_f = res_f[
            res_f["num_ede"].astype(str).str.lower().str.contains(f_ede.lower()) |
            res_f["nom_exploitant"].fillna("").str.lower().str.contains(f_ede.lower())]
    if f_an != "Toutes" and not res_f.empty:
        res_f = res_f[res_f["annee"].astype(str) == str(f_an)]

    if not res_f.empty:
        res_f["Statut"] = res_f["valeur_ct"].apply(
            lambda ct: "⚠️ Positif" if (ct and float(ct)<40) else "✅ Négatif")
        st.write(f"**{len(res_f)} résultat(s)**")
        st.dataframe(res_f[["id_resultat","num_ede","nom_exploitant","annee",
                              "numero_serie","valeur_ct","Statut","code_classement"]].rename(columns={
            "id_resultat":"ID","num_ede":"EDE","nom_exploitant":"Exploitant",
            "annee":"Année","numero_serie":"Série","valeur_ct":"Ct","code_classement":"Classement"}),
            use_container_width=True, height=280, hide_index=True)

    st.markdown("<hr>", unsafe_allow_html=True)
    t1, t2, t3 = st.tabs(["➕  Ajouter","✏️  Modifier","🗑️  Supprimer"])

    with t1:
        with st.form("add_res", clear_on_submit=True):
            st.subheader("➕ Nouveau résultat PCR")
            st.caption("Un résultat PCR = la valeur Ct mesurée pour un prélèvement. Plus le Ct est bas, plus l'infection est forte. Ct ≥ 40 = négatif.")
            c1, c2 = st.columns(2)
            pr_l = PREL["num_prelevement"].tolist() if not PREL.empty else []
            pr_s = c1.selectbox("Prélèvement associé *",
                pr_l if pr_l else ["—"],
                help="Choisir le numéro de prélèvement auquel ce résultat correspond.")
            type_a = c2.selectbox("Type d'analyse",
                ["actuelle", "historique"],
                help="'actuelle' pour les analyses récentes (2023+), 'historique' pour les données importées.")
            st.markdown("**Valeurs Ct par espèce**")
            st.caption("Entrer la valeur numérique du Ct (ex: 32.5). Laisser à 0 si l'espèce n'a pas été détectée (= négatif). Plus le Ct est bas, plus l'infection est forte.")
            c3, c4, c5, c6 = st.columns(4)
            ct_myc = c3.number_input("M. mycoïdes",  min_value=0.0, max_value=50.0, value=0.0, step=0.5, format="%.1f", help="Ct pour M. mycoïdes capri. 0 = négatif.")
            ct_aga = c4.number_input("M. agalactiae", min_value=0.0, max_value=50.0, value=0.0, step=0.5, format="%.1f", help="Ct pour M. agalactiae. 0 = négatif.")
            ct_cap = c5.number_input("M. capricolum", min_value=0.0, max_value=50.0, value=0.0, step=0.5, format="%.1f", help="Ct pour M. capricolum. 0 = négatif.")
            ct_put = c6.number_input("M. putrefaciens",min_value=0.0, max_value=50.0, value=0.0, step=0.5, format="%.1f", help="Ct pour M. putrefaciens. 0 = négatif.")
            if st.form_submit_button("✔ Enregistrer le résultat PCR", type="primary", use_container_width=True):
                if not pr_l:
                    st.error("❌ Aucun prélèvement en base. Créez d'abord un prélèvement.")
                else:
                    v_myc = float(ct_myc) if ct_myc > 0 else None
                    v_aga = float(ct_aga) if ct_aga > 0 else None
                    v_cap = float(ct_cap) if ct_cap > 0 else None
                    v_put = float(ct_put) if ct_put > 0 else None
                    res_id = q("INSERT INTO resultat_pcr (ct_mycoides, ct_agalactiae, ct_capricolum, ct_putrefaciens, type_analyse) VALUES (%s,%s,%s,%s,%s)",
                               (v_myc, v_aga, v_cap, v_put, type_a), fetch=False)
                    if res_id and pr_l:
                        q("UPDATE prelevement SET id_resultat=%s WHERE num_prelevement=%s",
                          (res_id, pr_s), fetch=False)
                    recalculer_classements()
                    st.success("✅ Résultat PCR enregistré + classements recalculés !"); refresh()

    with t2:
        if RES.empty:
            st.info("Aucun résultat PCR en base.")
        else:
            with st.form("edit_res"):
                st.subheader("✏️ Modifier un résultat PCR")
                st.caption("Modifier la valeur Ct d'un résultat existant. Le classement sera recalculé automatiquement.")
                opts_res = [f"#{r['id_resultat']} — {r['num_ede']} ({r['annee']} S{int(r['numero_serie']) if r['numero_serie'] else '?'})" for _, r in RES.iterrows()]
                sel_str = st.selectbox("Résultat à modifier", opts_res,
                    help="Sélectionner le résultat par son ID, l'EDE et la série.")
                sel = RES.iloc[opts_res.index(sel_str)]["id_resultat"]
                row = RES[RES["id_resultat"] == sel].iloc[0]
                st.caption(f"Élevage : {row['nom_exploitant']} | Série {int(row['numero_serie']) if row['numero_serie'] else '?'} — {row['annee']}")
                c1, c2, c3, c4 = st.columns(4)
                ct_myc = c1.number_input("M. mycoïdes",  min_value=0.0, max_value=50.0, step=0.5, format="%.1f",
                    value=float(row["ct_mycoides"]) if row.get("ct_mycoides") else 0.0)
                ct_aga = c2.number_input("M. agalactiae", min_value=0.0, max_value=50.0, step=0.5, format="%.1f",
                    value=float(row["ct_agalactiae"]) if row.get("ct_agalactiae") else 0.0)
                ct_cap = c3.number_input("M. capricolum", min_value=0.0, max_value=50.0, step=0.5, format="%.1f",
                    value=float(row["ct_capricolum"]) if row.get("ct_capricolum") else 0.0)
                ct_put = c4.number_input("M. putrefaciens",min_value=0.0, max_value=50.0, step=0.5, format="%.1f",
                    value=float(row["ct_putrefaciens"]) if row.get("ct_putrefaciens") else 0.0)
                if st.form_submit_button("✔ Enregistrer les corrections", type="primary", use_container_width=True):
                    q("UPDATE resultat_pcr SET ct_mycoides=%s, ct_agalactiae=%s, ct_capricolum=%s, ct_putrefaciens=%s WHERE id_resultat=%s",
                      (float(ct_myc) if ct_myc > 0 else None,
                       float(ct_aga) if ct_aga > 0 else None,
                       float(ct_cap) if ct_cap > 0 else None,
                       float(ct_put) if ct_put > 0 else None, sel), fetch=False)
                    recalculer_classements()
                    st.success("✅ Résultat corrigé + classements recalculés !"); refresh()

    with t3:
        if RES.empty:
            st.info("Aucun résultat PCR en base.")
        else:
            with st.form("del_res"):
                st.subheader("🗑️ Retirer un résultat PCR")
                st.warning("⚠️ Supprime uniquement le résultat PCR. Le prélèvement associé reste en base.")
                opts_res = [f"#{r['id_resultat']} — {r['num_ede']} ({r['annee']} S{int(r['numero_serie']) if r['numero_serie'] else '?'})" for _, r in RES.iterrows()]
                sel_str = st.selectbox("Résultat à supprimer", opts_res,
                    help="Choisir le résultat à supprimer.")
                sel = RES.iloc[opts_res.index(sel_str)]["id_resultat"]
                ok_r = st.checkbox("Je confirme la suppression de ce résultat PCR")
                if st.form_submit_button("🗑️ Supprimer ce résultat", type="primary", use_container_width=True):
                    if ok_r:
                        q("DELETE FROM resultat_pcr WHERE id_resultat=%s", (sel,), fetch=False)
                        recalculer_classements()
                        st.success("✅ Résultat supprimé."); refresh()
                    else:
                        st.error("Cochez la case de confirmation.")


# ══════════════════════════════════════════════════════════════
# PAGE SÉRIES
# ══════════════════════════════════════════════════════════════

elif PAGE == "Séries":
    st.title("📅 Séries d'analyses")
    SER = get_series()
    c1, c2 = st.columns([4,2])
    with c2:
        if st.button("↻ Actualiser", use_container_width=True): refresh()

    if not SER.empty:
        st.write(f"**{len(SER)} série(s)**")
        st.dataframe(SER.rename(columns={"id_serie":"ID","numero_serie":"N° Série","annee":"Année"}),
                     use_container_width=True, height=260, hide_index=True)

    st.markdown("<hr>", unsafe_allow_html=True)
    t1, t2, t3 = st.tabs(["➕  Ajouter","✏️  Modifier","🗑️  Supprimer"])

    with t1:
        with st.form("add_ser", clear_on_submit=True):
            st.subheader("➕ Nouvelle série d'analyses")
            st.caption("Une série regroupe tous les prélèvements réalisés sur une même période de l'année. Série 1 = janv–avr, Série 2 = mai–août, Série 3 = sept–déc.")
            c1, c2 = st.columns(2)
            an = c1.number_input("Année *",
                min_value=2018, max_value=2030, value=2026,
                help="Année de la campagne d'analyses.")
            ns = c2.selectbox("Numéro de série *",
                [1, 2, 3],
                format_func=lambda x: f"Série {x} — {'janv–avr' if x==1 else 'mai–août' if x==2 else 'sept–déc'}",
                help="Série 1 : janvier à avril | Série 2 : mai à août | Série 3 : septembre à décembre")
            if st.form_submit_button("✔ Créer cette série", type="primary", use_container_width=True):
                q("INSERT IGNORE INTO serie (numero_serie, annee) VALUES (%s,%s)", (ns, an), fetch=False)
                st.success(f"✅ Série {ns} — {an} créée !"); refresh()

    with t2:
        if SER.empty:
            st.info("Aucune série en base.")
        else:
            with st.form("edit_ser"):
                st.subheader("✏️ Modifier une série existante")
                st.caption("Corriger l'année ou le numéro d'une série existante.")
                sel = st.selectbox("Série à modifier", SER["id_serie"].tolist(),
                    format_func=lambda x: f"Série {SER[SER['id_serie']==x].iloc[0]['numero_serie']} — {SER[SER['id_serie']==x].iloc[0]['annee']}",
                    help="Choisir la série à corriger.")
                row = SER[SER["id_serie"] == sel].iloc[0]
                c1, c2 = st.columns(2)
                an = c1.number_input("Année", min_value=2018, max_value=2030, value=int(row["annee"]))
                ns = c2.selectbox("N° série", [1, 2, 3],
                    index=int(row["numero_serie"]) - 1,
                    format_func=lambda x: f"Série {x} — {'janv–avr' if x==1 else 'mai–août' if x==2 else 'sept–déc'}")
                if st.form_submit_button("✔ Enregistrer la modification", type="primary", use_container_width=True):
                    q("UPDATE serie SET numero_serie=%s, annee=%s WHERE id_serie=%s", (ns, an, sel), fetch=False)
                    st.success("✅ Série modifiée !"); refresh()

    with t3:
        if SER.empty:
            st.info("Aucune série en base.")
        else:
            with st.form("del_ser"):
                st.subheader("🗑️ Retirer une série")
                st.warning("⚠️ Supprime la série ET tous les prélèvements qui y sont rattachés. Irréversible.")
                sel = st.selectbox("Série à supprimer", SER["id_serie"].tolist(),
                    format_func=lambda x: f"Série {SER[SER['id_serie']==x].iloc[0]['numero_serie']} — {SER[SER['id_serie']==x].iloc[0]['annee']}",
                    help="Choisir la série à supprimer définitivement.")
                ok_s = st.checkbox("Je confirme la suppression de cette série et de tous ses prélèvements")
                if st.form_submit_button("🗑️ Supprimer cette série", type="primary", use_container_width=True):
                    if ok_s:
                        q("DELETE FROM prelevement WHERE id_serie=%s", (sel,), fetch=False)
                        q("DELETE FROM serie WHERE id_serie=%s", (sel,), fetch=False)
                        st.success("✅ Série supprimée."); refresh()
                    else:
                        st.error("Cochez la case de confirmation.")


# ══════════════════════════════════════════════════════════════
# PAGE MYCOPLASMAS
# ══════════════════════════════════════════════════════════════

elif PAGE == "Mycoplasmas":
    st.title("🦠 Résultats par espèce")
    st.caption("Analyse détaillée des 4 espèces de Mycoplasmes")

    RES = get_resultats()

    ESPECES_INFO = {
        "ct_mycoides":     {"nom":"M. mycoïdes capri",  "couleur":"#dc2626"},
        "ct_agalactiae":   {"nom":"M. agalactiae",      "couleur":"#7c3aed"},
        "ct_capricolum":   {"nom":"M. capricolum",      "couleur":"#d97706"},
        "ct_putrefaciens": {"nom":"M. putrefaciens",    "couleur":"#0891b2"},
    }

    if RES.empty:
        st.info("Aucun résultat en base.")
    else:
        # ── KPIs par espèce
        st.subheader("Taux de positivité par espèce")
        cols = st.columns(4)
        for i, (cle, info) in enumerate(ESPECES_INFO.items()):
            if cle in RES.columns:
                n_pos  = RES[cle].apply(lambda v: v is not None and float(v)<40 if v is not None else False).sum()
                n_tot  = len(RES)
                taux   = round(n_pos/n_tot*100, 1) if n_tot else 0
                with cols[i]:
                    st.markdown(
                        f"<div style='background:white;border:1.5px solid #e5e7eb;"
                        f"border-top:4px solid {info["couleur"]};border-radius:10px;"
                        f"padding:14px 18px;'>"
                        f"<div style='font-size:.75rem;font-weight:700;color:#6b7280;"
                        f"text-transform:uppercase;'>{info['nom']}</div>"
                        f"<div style='font-size:2rem;font-weight:800;color:{info["couleur"]};'>{n_pos}</div>"
                        f"<div style='font-size:.8rem;color:#6b7280;'>positifs / {n_tot} · {taux}%</div>"
                        f"</div>", unsafe_allow_html=True)

        st.markdown("<hr>", unsafe_allow_html=True)

        # ── Tableau des résultats avec recherche et filtres
        st.subheader("Tableau complet des résultats")
        mc1, mc2, mc3 = st.columns([3, 2, 1])
        srch_myco = mc1.text_input("🔎 Rechercher un élevage",
            placeholder="Nom exploitant ou N° EDE...",
            label_visibility="collapsed")
        annees_myco = ["Toutes"] + sorted(
            RES["annee"].dropna().unique().astype(int).tolist(), reverse=True
        ) if not RES.empty else ["Toutes"]
        f_an_myco = mc2.selectbox("Année", annees_myco,
            label_visibility="collapsed")
        f_pos_myco = mc3.checkbox("Positifs seulement")

        ct_cols = ["ct_mycoides","ct_agalactiae","ct_capricolum","ct_putrefaciens"]
        cols_disp = ["num_ede","nom_exploitant","annee","numero_serie","date_prelevement"] +                     [c for c in ct_cols if c in RES.columns]

        def fmt_ct(v):
            if v is None: return "NEG"
            try:
                f = float(v)
                return "✅ NEG" if f >= 40 else f"⚠️ {f:.1f}"
            except: return "—"

        df_show = RES[cols_disp].copy()

        # Appliquer les filtres sur les données brutes avant formatage
        if srch_myco:
            mask = (
                df_show["nom_exploitant"].fillna("").str.lower().str.contains(srch_myco.lower()) |
                df_show["num_ede"].fillna("").str.lower().str.contains(srch_myco.lower())
            )
            df_show = df_show[mask]
        if f_an_myco != "Toutes":
            df_show = df_show[df_show["annee"].astype(str) == str(f_an_myco)]
        if f_pos_myco:
            def est_positif(row):
                for c in ct_cols:
                    if c in row.index and row[c] is not None:
                        try:
                            if float(row[c]) < 40: return True
                        except: pass
                return False
            df_show = df_show[df_show.apply(est_positif, axis=1)]

        st.caption(f"**{len(df_show)}** résultat(s) affiché(s)")

        # Formater les Ct après le filtrage
        for c in ct_cols:
            if c in df_show.columns:
                df_show[c] = df_show[c].apply(fmt_ct)

        st.dataframe(df_show.rename(columns={
            "num_ede":"EDE","nom_exploitant":"Exploitant",
            "annee":"Année","numero_serie":"Série","date_prelevement":"Date",
            "ct_mycoides":"Mycoïdes capri","ct_agalactiae":"Agalactiae",
            "ct_capricolum":"Capricolum","ct_putrefaciens":"Putrefaciens"}),
            use_container_width=True, height=400, hide_index=True)

        st.markdown("<hr>", unsafe_allow_html=True)

        # ── Évolution par espèce et par année
        st.subheader("Évolution du taux de positivité par espèce")
        import plotly.graph_objects as go
        fig = go.Figure()
        for cle, info in ESPECES_INFO.items():
            if cle not in RES.columns: continue
            evo = (RES.groupby("annee")
                   .apply(lambda x: round(
                       x[cle].apply(lambda v: v is not None and float(v)<40 if v is not None else False).sum()
                       / len(x) * 100, 1))
                   .reset_index())
            evo.columns = ["Année","Taux (%)"]
            fig.add_trace(go.Scatter(
                x=evo["Année"], y=evo["Taux (%)"],
                mode="lines+markers", name=info["nom"],
                line=dict(color=info["couleur"], width=2.5),
                marker=dict(size=8)))
        fig.update_layout(height=320, template="plotly_white",
                          yaxis=dict(title="Taux positifs (%)"),
                          font_size=12, margin=dict(t=20,b=40,l=50,r=20),
                          legend=dict(orientation="h", yanchor="bottom", y=-0.3))
        st.plotly_chart(fig, use_container_width=True)
elif PAGE == "Requêtes SQL":
    st.title("🔍 Requêtes SQL")
    st.caption("Requêtes SELECT sur la base de données")

    PREDEF = {
        # Élevages
        "🐄 Élevages par classement":
            """SELECT code_classement AS Classement, COUNT(*) AS "Nb élevages"
FROM elevage
GROUP BY code_classement
ORDER BY code_classement;""",

        "🐄 Élevages par département":
            """SELECT e.code_departement AS Département,
       COUNT(DISTINCT e.id_elevage) AS "Nb élevages"
FROM ede e
GROUP BY e.code_departement
ORDER BY e.code_departement;""",

        "🐄 Élevages sans résultat PCR":
            """SELECT el.id_elevage, el.nom_exploitant, ed.num_ede
FROM elevage el
JOIN ede ed ON el.id_elevage = ed.id_elevage
WHERE ed.num_ede NOT IN (
    SELECT DISTINCT num_ede FROM prelevement WHERE num_ede IS NOT NULL
)
ORDER BY el.nom_exploitant;""",

        # Résultats positifs
        "⚠️ Tous les positifs (Ct < 40)":
            """SELECT p.num_ede, el.nom_exploitant, s.annee, s.numero_serie AS serie,
       r.ct_mycoides, r.ct_agalactiae, r.ct_capricolum, r.ct_putrefaciens
FROM resultat_pcr r
JOIN prelevement p  ON r.id_resultat = p.id_resultat
JOIN ede e          ON p.num_ede     = e.num_ede
JOIN elevage el     ON e.id_elevage  = el.id_elevage
JOIN serie s        ON p.id_serie    = s.id_serie
WHERE (r.ct_mycoides < 40 OR r.ct_agalactiae < 40
    OR r.ct_capricolum < 40 OR r.ct_putrefaciens < 40)
ORDER BY s.annee DESC, s.numero_serie DESC
LIMIT 100;""",

        "🔴 Fortement positifs (Ct < 35)":
            """SELECT p.num_ede, el.nom_exploitant, s.annee, s.numero_serie AS serie,
       LEAST(
           COALESCE(r.ct_mycoides, 99),
           COALESCE(r.ct_agalactiae, 99),
           COALESCE(r.ct_capricolum, 99),
           COALESCE(r.ct_putrefaciens, 99)
       ) AS ct_min
FROM resultat_pcr r
JOIN prelevement p  ON r.id_resultat = p.id_resultat
JOIN ede e          ON p.num_ede     = e.num_ede
JOIN elevage el     ON e.id_elevage  = el.id_elevage
JOIN serie s        ON p.id_serie    = s.id_serie
WHERE (r.ct_mycoides < 35 OR r.ct_agalactiae < 35
    OR r.ct_capricolum < 35 OR r.ct_putrefaciens < 35)
ORDER BY ct_min ASC
LIMIT 50;""",

        # Classements
        "🟢 Classement A — élevages sains":
            """SELECT ed.num_ede, el.nom_exploitant, ed.code_departement
FROM elevage el
JOIN ede ed ON el.id_elevage = ed.id_elevage
WHERE el.code_classement = 'A'
ORDER BY ed.code_departement, el.nom_exploitant;""",

        "🔵 Classement H — en assainissement":
            """SELECT ed.num_ede, el.nom_exploitant, ed.code_departement
FROM elevage el
JOIN ede ed ON el.id_elevage = ed.id_elevage
WHERE el.code_classement = 'H'
ORDER BY ed.code_departement;""",

        "📊 Répartition classements par département":
            """SELECT e.code_departement AS Département,
       el.code_classement  AS Classement,
       COUNT(*) AS "Nb élevages"
FROM elevage el
JOIN ede e ON el.id_elevage = e.id_elevage
GROUP BY e.code_departement, el.code_classement
ORDER BY e.code_departement, el.code_classement;""",

        # Historique
        "📈 Évolution positivité par série":
            """SELECT s.annee, s.numero_serie AS serie,
       COUNT(*) AS total_prelevements,
       SUM(CASE WHEN r.ct_mycoides < 40
                  OR r.ct_agalactiae < 40
                  OR r.ct_capricolum < 40
                  OR r.ct_putrefaciens < 40
                THEN 1 ELSE 0 END) AS positifs,
       ROUND(
           SUM(CASE WHEN r.ct_mycoides < 40
                      OR r.ct_agalactiae < 40
                      OR r.ct_capricolum < 40
                      OR r.ct_putrefaciens < 40
                    THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1
       ) AS "taux_positif_%"
FROM serie s
JOIN prelevement p  ON s.id_serie    = p.id_serie
JOIN resultat_pcr r ON p.id_resultat = r.id_resultat
GROUP BY s.annee, s.numero_serie
ORDER BY s.annee, s.numero_serie;""",

        "🦠 Nb positifs par espèce":
            """SELECT
    SUM(CASE WHEN ct_mycoides   < 40 THEN 1 ELSE 0 END) AS "M. mycoïdes",
    SUM(CASE WHEN ct_agalactiae < 40 THEN 1 ELSE 0 END) AS "M. agalactiae",
    SUM(CASE WHEN ct_capricolum < 40 THEN 1 ELSE 0 END) AS "M. capricolum",
    SUM(CASE WHEN ct_putrefaciens < 40 THEN 1 ELSE 0 END) AS "M. putrefaciens"
FROM resultat_pcr;""",

        "📋 Derniers résultats importés":
            """SELECT p.num_ede, el.nom_exploitant, s.annee, s.numero_serie AS serie,
       p.date_prelevement, r.ct_mycoides, r.ct_agalactiae,
       r.ct_capricolum, r.ct_putrefaciens
FROM prelevement p
JOIN resultat_pcr r ON p.id_resultat = r.id_resultat
JOIN ede e          ON p.num_ede     = e.num_ede
JOIN elevage el     ON e.id_elevage  = el.id_elevage
JOIN serie s        ON p.id_serie    = s.id_serie
ORDER BY p.date_prelevement DESC
LIMIT 50;""",

        "🔍 Élevages dep. 79":
            """SELECT e.num_ede, el.nom_exploitant, el.code_classement
FROM ede e
JOIN elevage el ON e.id_elevage = el.id_elevage
WHERE e.code_departement = '79'
ORDER BY el.code_classement, el.nom_exploitant;""",

        "🔍 Élevages dep. 86":
            """SELECT e.num_ede, el.nom_exploitant, el.code_classement
FROM ede e
JOIN elevage el ON e.id_elevage = el.id_elevage
WHERE e.code_departement = '86'
ORDER BY el.code_classement, el.nom_exploitant;""",

        "🔍 Élevages zone 16":
            """SELECT e.num_ede, el.nom_exploitant, el.code_classement
FROM ede e
JOIN elevage el ON e.id_elevage = el.id_elevage
WHERE e.code_departement = '16'
ORDER BY el.code_classement, el.nom_exploitant;""",
    }

    st.subheader("Requêtes prédéfinies")
    pdef_c = st.columns(3)
    for i,(name,rsql) in enumerate(PREDEF.items()):
        if pdef_c[i%3].button(name, key=f"q{i}", use_container_width=True):
            st.session_state["sql_txt"] = rsql

    st.markdown("<hr>", unsafe_allow_html=True)
    sql_txt = st.text_area("Requête SQL (SELECT uniquement)",
        value=st.session_state.get("sql_txt","SELECT * FROM elevage LIMIT 20;"),
        height=150)

    c1, _ = st.columns([1,4])
    if c1.button("▶  Exécuter", type="primary", use_container_width=True):
        if not sql_txt.strip().upper().startswith("SELECT"):
            st.error("❌ Seules les requêtes SELECT sont autorisées.")
        else:
            result = q(sql_txt.strip())
            if result is not None and not result.empty:
                st.success(f"✅ {len(result)} résultat(s)")
                st.dataframe(result, use_container_width=True, height=400, hide_index=True)
            else:
                st.info("Aucun résultat.")


# ══════════════════════════════════════════════════════════════
# PAGE ADMIN
# ══════════════════════════════════════════════════════════════

elif PAGE == "Admin":
    st.title("🛡️ Administration")
    st.caption("Zone réservée — opérations sensibles sur la base de données")

    st.markdown("<hr>", unsafe_allow_html=True)

    tab1, tab2, tab3, tab4 = st.tabs([
        "🗑️ Suppression de données",
        "🔄 Recalcul classements",
        "📊 État de la base",
        "⚙️ Maintenance",
    ])

    # ── Onglet 1 : Suppressions
    with tab1:
        st.subheader("🗑️ Suppression de données")
        st.error("⚠️ Ces opérations sont IRRÉVERSIBLES. Agissez avec précaution.")

        col_s1, col_s2 = st.columns(2)

        with col_s1:
            st.markdown("##### Supprimer une série")
            SER = get_series()
            if not SER.empty:
                opts_ser = [f"Série {int(r['numero_serie'])} — {int(r['annee'])}" for _, r in SER.iterrows()]
                choix_ser = st.selectbox("Choisir la série à supprimer", opts_ser, key="del_serie")
                idx_ser = opts_ser.index(choix_ser)
                id_serie_del = int(SER.iloc[idx_ser]["id_serie"])
                st.caption(f"id_serie = {id_serie_del}")
                confirm_ser = st.checkbox(f"Je confirme la suppression de {choix_ser}", key="conf_ser")
                if st.button("🗑️ Supprimer cette série", key="btn_del_serie", type="primary",
                             disabled=not confirm_ser):
                    q("DELETE FROM prelevement WHERE id_serie = %s", (id_serie_del,), fetch=False)
                    q("DELETE FROM serie WHERE id_serie = %s", (id_serie_del,), fetch=False)
                    st.cache_data.clear()
                    st.success(f"✅ Série supprimée.")
                    st.rerun()
            else:
                st.info("Aucune série en base.")

        with col_s2:
            st.markdown("##### Supprimer un élevage")
            ELV_A = get_elevages()
            EDE_A = get_edes()
            if not EDE_A.empty:
                opts_elv = [
                    f"{r['num_ede']} — {r['nom_exploitant'] or '?'}"
                    for _, r in EDE_A.iterrows()
                ]
                choix_elv = st.selectbox("Choisir l'élevage", opts_elv, key="del_elv")
                ede_del = choix_elv.split(" — ")[0].strip()
                row_del = EDE_A[EDE_A["num_ede"] == ede_del].iloc[0]
                id_elv_del = int(row_del["id_elevage"])
                st.caption(f"num_ede = {ede_del} | id_elevage = {id_elv_del}")
                confirm_elv = st.checkbox(f"Je confirme la suppression de {ede_del}", key="conf_elv")
                if st.button("🗑️ Supprimer cet élevage", key="btn_del_elv", type="primary",
                             disabled=not confirm_elv):
                    q("DELETE FROM prelevement WHERE num_ede = %s", (ede_del,), fetch=False)
                    q("DELETE FROM resultat_pcr WHERE id_resultat NOT IN (SELECT id_resultat FROM prelevement WHERE id_resultat IS NOT NULL)", fetch=False)
                    q("DELETE FROM ede WHERE num_ede = %s", (ede_del,), fetch=False)
                    q("DELETE FROM elevage WHERE id_elevage = %s", (id_elv_del,), fetch=False)
                    st.cache_data.clear()
                    st.success(f"✅ Élevage {ede_del} supprimé.")
                    st.rerun()
            else:
                st.info("Aucun élevage en base.")

        st.markdown("<hr>", unsafe_allow_html=True)
        st.markdown("##### 🔴 RESET COMPLET — Vider toute la base")
        st.error("⚠️ Efface TOUTES les données. À faire avant de réimporter.")
        with st.form("form_reset_total"):
            ok_reset = st.checkbox("Je confirme le reset total")
            if st.form_submit_button("🔴 RESET COMPLET", type="primary",
                                     use_container_width=True):
                if ok_reset:
                    for t in ["prelevement","resultat_pcr","serie","ede","elevage"]:
                        q(f"DELETE FROM {t}", fetch=False)
                    st.cache_data.clear()
                    st.success("✅ Base vidée. Réimportez vos fichiers.")
                    st.rerun()
                else:
                    st.error("Cochez la confirmation.")
    # ── Onglet 2 : Recalcul classements
    with tab2:
        st.subheader("🔄 Recalcul des classements A→I")
        st.info(
            "Recalcule les classements de **tous les élevages** selon les 6 derniers résultats PCR. "
            "À lancer après tout import de fichier Excel si les classements ne se sont pas mis à jour automatiquement."
        )

        RES_R = get_resultats()
        ELV_R = get_elevages()

        if not RES_R.empty and not ELV_R.empty:
            # Aperçu avant
            st.markdown("**Classements actuels :**")
            cc_now = ELV_R["code_classement"].fillna("I").value_counts().reset_index()
            cc_now.columns = ["Code","Nb"]
            cc_now["Libellé"] = cc_now["Code"].map(lambda c: CLASSEMENT.get(c, CLASSEMENT["I"])[0])
            st.dataframe(cc_now, use_container_width=True, hide_index=True)

        if st.button("🔄 Lancer le recalcul", type="primary", key="btn_recalc"):
            with st.spinner("Recalcul en cours…"):
                recalculer_classements()
                st.cache_data.clear()
            st.success("✅ Classements mis à jour !")
            st.rerun()

    # ── Onglet 3 : État de la base
    with tab3:
        st.subheader("📊 État de la base de données")

        if st.button("🔄 Actualiser", key="btn_refresh_admin"):
            st.cache_data.clear()
            st.rerun()

        tables_stat = ["elevage","ede","serie","prelevement","resultat_pcr","prelevement"]
        stat_data = []
        for tbl in tables_stat:
            res = q(f"SELECT COUNT(*) as nb FROM {tbl}")
            nb = int(res.iloc[0]["nb"]) if not res.empty else 0
            stat_data.append({"Table": tbl, "Nb de lignes": nb})

        df_stat = pd.DataFrame(stat_data)
        st.dataframe(df_stat, use_container_width=True, hide_index=True)

        # Résumé classements
        ELV_S = get_elevages()
        if not ELV_S.empty and "code_classement" in ELV_S.columns:
            st.markdown("**Répartition des classements :**")
            cc_s = ELV_S["code_classement"].fillna("I").value_counts().reset_index()
            cc_s.columns = ["Code","Nb"]
            cc_s["Libellé"] = cc_s["Code"].map(lambda c: CLASSEMENT.get(c, CLASSEMENT["I"])[0])
            cc_s["Emoji"]   = cc_s["Code"].map(lambda c: CLASSEMENT.get(c, CLASSEMENT["I"])[3])
            st.dataframe(cc_s[["Emoji","Code","Libellé","Nb"]], use_container_width=True, hide_index=True)

        # Dernières séries
        SER_S = get_series()
        if not SER_S.empty:
            st.markdown("**Séries enregistrées :**")
            st.dataframe(SER_S, use_container_width=True, hide_index=True, height=200)

    # ── Onglet 4 : Maintenance
    with tab4:
        st.subheader("⚙️ Maintenance")

        st.markdown("##### 🧹 Vider le cache applicatif")
        st.caption("Force le rechargement de toutes les données depuis la base.")
        if st.button("🧹 Vider le cache", key="btn_cache"):
            st.cache_data.clear()
            st.success("✅ Cache vidé. Les données seront rechargées au prochain accès.")

        st.markdown("<hr>", unsafe_allow_html=True)
        st.markdown("##### 🔗 Tester la connexion SSH + MySQL")
        if st.button("🔗 Tester", key="btn_test_conn"):
            with st.spinner("Test en cours…"):
                tunnel = get_tunnel()
                if tunnel and tunnel.is_active:
                    st.success(f"✅ Tunnel SSH actif — port local : {tunnel.local_bind_port}")
                    conn_t = new_conn()
                    if conn_t:
                        conn_t.close()
                        st.success("✅ Connexion MySQL OK")
                    else:
                        st.error("❌ Tunnel OK mais MySQL inaccessible")
                else:
                    st.error("❌ Tunnel SSH inactif")

        st.markdown("<hr>", unsafe_allow_html=True)
        st.markdown("##### 🔁 Redémarrer le tunnel SSH")
        st.caption("En cas de déconnexion prolongée.")
        if st.button("🔁 Redémarrer le tunnel", key="btn_restart_tunnel"):
            st.cache_resource.clear()
            st.cache_data.clear()
            st.success("✅ Tunnel réinitialisé. Rechargez la page.")
            st.rerun()

        st.markdown("<hr>", unsafe_allow_html=True)
        st.markdown("##### 🗂️ Corriger les doublons de séries")
        st.caption(
            "Si plusieurs séries identiques (même numéro + même année) existent en base, "
            "ce bouton les fusionne et ajoute la contrainte UNIQUE pour éviter les futurs doublons."
        )

        # Afficher les doublons actuels
        df_doublons = q("""
            SELECT numero_serie, annee, COUNT(*) as nb, GROUP_CONCAT(id_serie ORDER BY id_serie) as ids
            FROM serie
            GROUP BY numero_serie, annee
            HAVING COUNT(*) > 1
        """)
        if df_doublons is not None and not df_doublons.empty:
            st.warning(f"⚠️ {len(df_doublons)} doublon(s) détecté(s) :")
            st.dataframe(df_doublons, hide_index=True, use_container_width=True)
            if st.button("🔧 Fusionner les doublons", key="btn_fix_series", type="primary"):
                with st.spinner("Correction en cours..."):
                    conn_fix = new_conn()
                    if conn_fix:
                        try:
                            cur_fix = conn_fix.cursor(buffered=True)
                            # Rattacher les prélèvements vers le bon id_serie
                            cur_fix.execute("""
                                UPDATE prelevement p
                                JOIN serie s ON p.id_serie = s.id_serie
                                JOIN (
                                    SELECT numero_serie, annee, MIN(id_serie) AS id_a_garder
                                    FROM serie GROUP BY numero_serie, annee
                                ) bon ON bon.numero_serie = s.numero_serie AND bon.annee = s.annee
                                SET p.id_serie = bon.id_a_garder
                                WHERE p.id_serie != bon.id_a_garder
                            """)
                            # Supprimer les doublons
                            cur_fix.execute("""
                                DELETE s1 FROM serie s1
                                INNER JOIN serie s2
                                    ON s1.numero_serie = s2.numero_serie
                                   AND s1.annee = s2.annee
                                   AND s1.id_serie > s2.id_serie
                            """)
                            conn_fix.commit()
                            # Ajouter la contrainte UNIQUE si pas déjà présente
                            try:
                                cur_fix.execute("""
                                    ALTER TABLE serie
                                    ADD CONSTRAINT uq_serie_numero_annee
                                    UNIQUE (numero_serie, annee)
                                """)
                                conn_fix.commit()
                            except Exception:
                                pass  # Contrainte déjà existante
                            cur_fix.close()
                            conn_fix.close()
                            st.cache_data.clear()
                            st.success("✅ Doublons supprimés et contrainte UNIQUE ajoutée !")
                            st.rerun()
                        except Exception as e:
                            st.error(f"❌ Erreur : {e}")
                            try: conn_fix.close()
                            except: pass
        else:
            st.success("✅ Aucun doublon de série détecté.")
            # Ajouter la contrainte silencieusement si absente
            conn_uc = new_conn()
            if conn_uc:
                try:
                    cur_uc = conn_uc.cursor(buffered=True)
                    cur_uc.execute("""
                        ALTER TABLE serie
                        ADD CONSTRAINT uq_serie_numero_annee
                        UNIQUE (numero_serie, annee)
                    """)
                    conn_uc.commit()
                    cur_uc.close()
                except Exception:
                    pass
                conn_uc.close()

