-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  sam. 28 mars 2026 à 20:54
-- Version du serveur :  5.7.17
-- Version de PHP :  5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `conception_sae`
--

-- --------------------------------------------------------

--
-- Structure de la table `approvisionner`
--

CREATE TABLE `approvisionner` (
  `id_entree` int(11) NOT NULL,
  `id_tournee` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `approvisionner`
--

INSERT INTO `approvisionner` (`id_entree`, `id_tournee`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10),
(11, 11),
(12, 12),
(13, 13),
(14, 14);

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `id_client` int(11) NOT NULL,
  `nom_client` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ville_client` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`id_client`, `nom_client`, `ville_client`) VALUES
(1, 'Restaurant Le Gourmet', 'Paris'),
(2, 'Boutique Mode&Style', 'Boulogne'),
(3, 'Pharmacie Centrale', 'Versailles'),
(4, 'Supermarche BioPlus', 'Paris'),
(5, 'Librairie du Coin', 'Neuilly'),
(6, 'Cafe des Arts', 'Saint-Cloud'),
(7, 'Boulangerie Artisan', 'Levallois'),
(8, 'Fleuriste Jardin', 'Courbevoie'),
(9, 'Epicerie Fine', 'Suresnes'),
(10, 'Restaurant Saveurs', 'Puteaux'),
(11, 'Magasin Sport', 'Nanterre'),
(12, 'Bijouterie Etoile', 'Paris'),
(13, 'Pressing Eclair', 'Clichy'),
(14, 'Animalerie Compagnon', 'Asnieres'),
(15, 'Papeterie Bureau', 'Colombes'),
(16, 'Boulangerie du Centre', 'LaRochelle'),
(17, 'Panem', 'La Creche'),
(18, 'Tech&Co', 'Niort'),
(19, 'Tech and Co', 'NIORT'),
(20, 'Universite de Poitiers', 'Niort');

-- --------------------------------------------------------

--
-- Structure de la table `coefficientco2`
--

CREATE TABLE `coefficientco2` (
  `id_type_vehicule` int(11) NOT NULL,
  `annee` int(11) NOT NULL,
  `co2_g_km` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `coefficientco2`
--

INSERT INTO `coefficientco2` (`id_type_vehicule`, `annee`, `co2_g_km`) VALUES
(1, 2022, 0),
(1, 2023, 0),
(1, 2024, 0),
(2, 2022, 0),
(2, 2023, 0),
(2, 2024, 0),
(3, 2022, 190),
(3, 2023, 185),
(3, 2024, 180),
(4, 2022, 0),
(4, 2023, 0),
(4, 2024, 0),
(5, 2022, 105),
(5, 2023, 100),
(5, 2024, 95),
(6, 2022, 130),
(6, 2023, 125),
(6, 2024, 120),
(7, 2022, 0),
(7, 2023, 0),
(7, 2024, 0),
(8, 2022, 0),
(8, 2023, 0),
(8, 2024, 0),
(9, 2022, 0),
(9, 2023, 0),
(9, 2024, 0),
(10, 2022, 150),
(10, 2023, 145),
(10, 2024, 140);

-- --------------------------------------------------------

--
-- Structure de la table `entree`
--

CREATE TABLE `entree` (
  `id_entree` int(11) NOT NULL,
  `date_entree` date NOT NULL,
  `quantite_colis` int(11) NOT NULL,
  `id_partenaire` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `entree`
--

INSERT INTO `entree` (`id_entree`, `date_entree`, `quantite_colis`, `id_partenaire`) VALUES
(1, '2024-01-05', 50, 1),
(2, '2024-01-08', 75, 2),
(3, '2024-01-12', 100, 3),
(4, '2024-01-15', 60, 4),
(5, '2024-01-18', 85, 5),
(6, '2024-01-22', 120, 1),
(7, '2024-01-25', 90, 6),
(8, '2024-02-01', 110, 7),
(9, '2024-02-05', 95, 8),
(10, '2024-02-10', 70, 9),
(11, '2024-02-15', 80, 10),
(12, '2024-02-20', 105, 2),
(13, '2024-02-25', 65, 11),
(14, '2024-03-01', 125, 12),
(15, '2026-01-02', 120, 13),
(16, '2026-01-05', 80, 14),
(17, '2026-01-07', 50, 14),
(18, '2026-01-07', 60, 16);

-- --------------------------------------------------------

--
-- Structure de la table `livraison`
--

CREATE TABLE `livraison` (
  `id_livraison` int(11) NOT NULL,
  `date_sortie` date NOT NULL,
  `poids_total_kg` decimal(15,2) DEFAULT NULL,
  `adresse_complete` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nb_colis` int(11) NOT NULL,
  `id_client` int(11) NOT NULL,
  `id_tournee` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `livraison`
--

INSERT INTO `livraison` (`id_livraison`, `date_sortie`, `poids_total_kg`, `adresse_complete`, `nb_colis`, `id_client`, `id_tournee`) VALUES
(1, '2024-01-06', '120.50', '12 rue de Rivoli, Paris', 5, 1, 1),
(2, '2024-01-06', '85.75', '45 av Victor Hugo, Boulogne', 3, 2, 1),
(3, '2024-01-09', '40.00', '8 bd des Champs, Versailles', 2, 3, 2),
(4, '2024-01-13', '200.00', '30 rue du Louvre, Paris', 8, 5, 3),
(5, '2024-01-13', '150.25', '15 av de Neuilly, Neuilly', 6, 6, 3),
(6, '2024-01-16', '35.80', '7 pl de la Mairie, Saint-Cloud', 2, 7, 4),
(7, '2024-01-19', '95.40', '33 bd de la République, Courbevoie', 5, 9, 5),
(8, '2024-01-23', '175.90', '50 quai de Dion Bouton, Puteaux', 7, 11, 6),
(9, '2024-01-26', '45.75', '9 av des Champs, Paris', 2, 13, 7),
(10, '2024-02-02', '135.50', '19 rue de la Gare, Asnières', 6, 15, 8),
(11, '2024-02-06', '220.00', '28 rue de la Paix, Paris', 9, 2, 9),
(12, '2024-02-11', '78.90', '5 rue du Marché, Versailles', 3, 4, 10),
(13, '2026-01-10', '23.00', '12 Rue du Port, 17000 La Rochelle', 2, 16, 15),
(14, '2026-01-12', '100.00', 'Zone industrielle', 1, 17, 16),
(15, '2026-01-12', '12.00', '4 rue de la gare - Niort', 1, 18, 17),
(16, '2026-01-12', '12.00', '4 rue de la gare NIORT', 1, 19, 17),
(17, '2026-01-12', NULL, '8 Rue Archimede - 79000 Niort', 3, 20, 17);

-- --------------------------------------------------------

--
-- Structure de la table `livreur`
--

CREATE TABLE `livreur` (
  `id_livreur` int(11) NOT NULL,
  `nom_livreur` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prenom_livreur` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_embauche` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `livreur`
--

INSERT INTO `livreur` (`id_livreur`, `nom_livreur`, `prenom_livreur`, `date_embauche`) VALUES
(1, 'Dupont', 'Jean', '2022-01-10'),
(2, 'Martin', 'Sophie', '2022-03-15'),
(3, 'Bernard', 'Luc', '2022-06-01'),
(4, 'Petit', 'Marie', '2022-09-12'),
(5, 'Dubois', 'Thomas', '2023-01-20'),
(6, 'Leroy', 'Julie', '2023-02-14'),
(7, 'Moreau', 'Pierre', '2023-04-05'),
(8, 'Simon', 'Claire', '2023-06-18'),
(9, 'Laurent', 'Marc', '2023-08-22'),
(10, 'Lefebvre', 'Emma', '2023-10-10'),
(11, 'Michel', 'Alexandre', '2023-11-15'),
(12, 'Garcia', 'Léa', '2024-01-08'),
(13, 'Martin', 'Paul', '2023-12-05'),
(14, 'DUPONT', 'Alice', '2025-12-20'),
(15, 'RAMES', 'Pedro', '2018-02-04'),
(16, 'Didon', 'Robin', '2023-09-28'),
(17, 'Rivierez', 'Solene', '2020-04-03');

-- --------------------------------------------------------

--
-- Structure de la table `partenaire`
--

CREATE TABLE `partenaire` (
  `id_partenaire` int(11) NOT NULL,
  `nom_partenaire` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ville_partenaire` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `partenaire`
--

INSERT INTO `partenaire` (`id_partenaire`, `nom_partenaire`, `ville_partenaire`) VALUES
(1, 'LogiPro', 'Paris'),
(2, 'TransExpress', 'Lyon'),
(3, 'CargoMart', 'Marseille'),
(4, 'SupplyChain SA', 'Bordeaux'),
(5, 'EcoLogistique', 'Lille'),
(6, 'FastDelivery', 'Toulouse'),
(7, 'GreenSupply', 'Nantes'),
(8, 'MegaStock', 'Strasbourg'),
(9, 'ParcelPro', 'Nice'),
(10, 'Distribution+', 'Rennes'),
(11, 'ExpressLog', 'Montpellier'),
(12, 'CargoVert', 'Grenoble'),
(13, 'Entrepot Nord', 'Paris'),
(14, 'Hub Sud', 'Bordeaux'),
(15, 'Marche international', 'Rungis'),
(16, 'CRT', 'Lesquin'),
(17, 'Hub Miramas', 'St Martin de Crau');

-- --------------------------------------------------------

--
-- Structure de la table `requetes_sql`
--

CREATE TABLE `requetes_sql` (
  `ID_SQL` int(11) NOT NULL,
  `NOM` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `CODE_SQL` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `requetes_sql`
--

INSERT INTO `requetes_sql` (`ID_SQL`, `NOM`, `CODE_SQL`) VALUES
(1, 'Livraisons par livreur', 'SELECT CONCAT(l.prenom_livreur,\' \',l.nom_livreur) AS livreur,\n        COUNT(liv.id_livraison) AS nb_livraisons\n FROM livreur l\n LEFT JOIN tournee t ON l.id_livreur=t.id_livreur\n LEFT JOIN livraison liv ON t.id_tournee=liv.id_tournee\n GROUP BY l.id_livreur\n ORDER BY nb_livraisons DESC'),
(2, 'Vehicules utilises >= 2 fois', 'SELECT tv.nom_type_vehicule, COUNT(t.id_tournee) AS nb_fois\n FROM vehicule v\n JOIN type_vehicule tv ON v.id_type_vehicule=tv.id_type_vehicule\n LEFT JOIN tournee t ON v.id_vehicule=t.id_vehicule\n GROUP BY v.id_vehicule, tv.nom_type_vehicule\n HAVING COUNT(t.id_tournee) >= 2'),
(3, 'Clients sans livraison', 'SELECT c.nom_client, c.ville_client\n FROM client c\n LEFT JOIN livraison liv ON c.id_client=liv.id_client\n WHERE liv.id_livraison IS NULL'),
(4, 'Entrees par partenaire', 'SELECT p.nom_partenaire,\n        COUNT(e.id_entree) AS nb_entrees,\n        SUM(e.quantite_colis) AS total_colis\n FROM partenaire p\n LEFT JOIN entree e ON p.id_partenaire=e.id_partenaire\n GROUP BY p.id_partenaire\n ORDER BY total_colis DESC'),
(5, 'Top 3 villes', 'SELECT c.ville_client, COUNT(liv.id_livraison) AS nb_livraisons\n FROM client c\n JOIN livraison liv ON c.id_client=liv.id_client\n GROUP BY c.ville_client\n ORDER BY nb_livraisons DESC\n LIMIT 3'),
(6, 'Tournees par mois', 'SELECT DATE_FORMAT(date_tournee,\'%Y-%m\') AS mois,\n        COUNT(*) AS nb_tournees\n FROM tournee\n GROUP BY DATE_FORMAT(date_tournee,\'%Y-%m\')\n ORDER BY mois'),
(7, 'Emissions CO2 par tournee', 'SELECT t.id_tournee, t.date_tournee,\n        CONCAT(l.prenom_livreur,\' \',l.nom_livreur) AS livreur,\n        tv.nom_type_vehicule, c.co2_g_km\n FROM tournee t\n JOIN livreur l ON t.id_livreur=l.id_livreur\n JOIN vehicule v ON t.id_vehicule=v.id_vehicule\n JOIN type_vehicule tv ON v.id_type_vehicule=tv.id_type_vehicule\n JOIN coefficientCO2 c ON tv.id_type_vehicule=c.id_type_vehicule\n WHERE c.annee=2024'),
(8, 'CO2 moyen par type vehicule', 'SELECT tv.nom_type_vehicule,\n        COUNT(t.id_tournee) AS nb_tournees,\n        AVG(c.co2_g_km) AS co2_moyen\n FROM type_vehicule tv\n JOIN coefficientCO2 c ON tv.id_type_vehicule=c.id_type_vehicule\n LEFT JOIN vehicule v ON tv.id_type_vehicule=v.id_type_vehicule\n LEFT JOIN tournee t ON v.id_vehicule=t.id_vehicule\n GROUP BY tv.id_type_vehicule'),
(9, 'Livreurs sans tournee', 'SELECT CONCAT(l.prenom_livreur,\' \',l.nom_livreur) AS livreur\n FROM livreur l\n LEFT JOIN tournee t ON l.id_livreur=t.id_livreur\n WHERE t.id_tournee IS NULL'),
(10, 'Livraisons avec poids manquant', 'SELECT liv.id_livraison, c.nom_client, liv.nb_colis, liv.poids_total_kg\n FROM livraison liv\n JOIN client c ON liv.id_client=c.id_client\n WHERE liv.poids_total_kg IS NULL');

-- --------------------------------------------------------

--
-- Structure de la table `tournee`
--

CREATE TABLE `tournee` (
  `id_tournee` int(11) NOT NULL,
  `date_tournee` date NOT NULL,
  `id_livreur` int(11) NOT NULL,
  `id_vehicule` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `tournee`
--

INSERT INTO `tournee` (`id_tournee`, `date_tournee`, `id_livreur`, `id_vehicule`) VALUES
(1, '2024-01-06', 1, 1),
(2, '2024-01-09', 2, 2),
(3, '2024-01-13', 3, 3),
(4, '2024-01-16', 4, 4),
(5, '2024-01-19', 5, 5),
(6, '2024-01-23', 6, 6),
(7, '2024-01-26', 7, 7),
(8, '2024-02-02', 8, 8),
(9, '2024-02-06', 9, 9),
(10, '2024-02-11', 10, 10),
(11, '2024-02-16', 11, 11),
(12, '2024-02-21', 12, 12),
(13, '2024-02-26', 1, 13),
(14, '2024-03-02', 2, 1),
(15, '2026-01-10', 15, 18),
(16, '2026-01-12', 14, 18),
(17, '2026-01-12', 16, 14);

-- --------------------------------------------------------

--
-- Structure de la table `type_vehicule`
--

CREATE TABLE `type_vehicule` (
  `id_type_vehicule` int(11) NOT NULL,
  `nom_type_vehicule` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `type_vehicule`
--

INSERT INTO `type_vehicule` (`id_type_vehicule`, `nom_type_vehicule`) VALUES
(1, 'Camionnette electrique'),
(2, 'Velo cargo'),
(3, 'Camion diesel'),
(4, 'Scooter electrique'),
(5, 'Voiture hybride'),
(6, 'Camion GNV'),
(7, 'Triporteur electrique'),
(8, 'Fourgon electrique'),
(9, 'Camion electrique'),
(10, 'Voiture essence'),
(11, 'Triporteur'),
(12, 'Utilitaire electrique');

-- --------------------------------------------------------

--
-- Structure de la table `vehicule`
--

CREATE TABLE `vehicule` (
  `id_vehicule` int(11) NOT NULL,
  `autonomie_km` double NOT NULL,
  `capacite_kg` double NOT NULL,
  `id_type_vehicule` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `vehicule`
--

INSERT INTO `vehicule` (`id_vehicule`, `autonomie_km`, `capacite_kg`, `id_type_vehicule`) VALUES
(1, 250, 500, 1),
(2, 40, 150, 2),
(3, 600, 2000, 3),
(4, 80, 50, 4),
(5, 400, 800, 5),
(6, 500, 1800, 6),
(7, 35, 120, 7),
(8, 300, 1200, 8),
(9, 350, 3000, 9),
(10, 450, 700, 10),
(11, 280, 550, 1),
(12, 320, 1100, 8),
(13, 270, 480, 1),
(14, 45, 120, 2),
(15, 60, 160, 11),
(16, 150, 500, 12),
(17, 50, 130, 2),
(18, 200, 700, 12);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `approvisionner`
--
ALTER TABLE `approvisionner`
  ADD PRIMARY KEY (`id_entree`,`id_tournee`),
  ADD KEY `id_tournee` (`id_tournee`);

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id_client`);

--
-- Index pour la table `coefficientco2`
--
ALTER TABLE `coefficientco2`
  ADD PRIMARY KEY (`id_type_vehicule`,`annee`);

--
-- Index pour la table `entree`
--
ALTER TABLE `entree`
  ADD PRIMARY KEY (`id_entree`),
  ADD KEY `id_partenaire` (`id_partenaire`);

--
-- Index pour la table `livraison`
--
ALTER TABLE `livraison`
  ADD PRIMARY KEY (`id_livraison`),
  ADD KEY `id_client` (`id_client`),
  ADD KEY `id_tournee` (`id_tournee`);

--
-- Index pour la table `livreur`
--
ALTER TABLE `livreur`
  ADD PRIMARY KEY (`id_livreur`);

--
-- Index pour la table `partenaire`
--
ALTER TABLE `partenaire`
  ADD PRIMARY KEY (`id_partenaire`);

--
-- Index pour la table `requetes_sql`
--
ALTER TABLE `requetes_sql`
  ADD PRIMARY KEY (`ID_SQL`);

--
-- Index pour la table `tournee`
--
ALTER TABLE `tournee`
  ADD PRIMARY KEY (`id_tournee`),
  ADD KEY `id_livreur` (`id_livreur`),
  ADD KEY `id_vehicule` (`id_vehicule`);

--
-- Index pour la table `type_vehicule`
--
ALTER TABLE `type_vehicule`
  ADD PRIMARY KEY (`id_type_vehicule`);

--
-- Index pour la table `vehicule`
--
ALTER TABLE `vehicule`
  ADD PRIMARY KEY (`id_vehicule`),
  ADD KEY `id_type_vehicule` (`id_type_vehicule`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `client`
--
ALTER TABLE `client`
  MODIFY `id_client` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT pour la table `entree`
--
ALTER TABLE `entree`
  MODIFY `id_entree` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT pour la table `livraison`
--
ALTER TABLE `livraison`
  MODIFY `id_livraison` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT pour la table `livreur`
--
ALTER TABLE `livreur`
  MODIFY `id_livreur` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT pour la table `partenaire`
--
ALTER TABLE `partenaire`
  MODIFY `id_partenaire` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT pour la table `requetes_sql`
--
ALTER TABLE `requetes_sql`
  MODIFY `ID_SQL` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT pour la table `tournee`
--
ALTER TABLE `tournee`
  MODIFY `id_tournee` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT pour la table `type_vehicule`
--
ALTER TABLE `type_vehicule`
  MODIFY `id_type_vehicule` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT pour la table `vehicule`
--
ALTER TABLE `vehicule`
  MODIFY `id_vehicule` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `approvisionner`
--
ALTER TABLE `approvisionner`
  ADD CONSTRAINT `approvisionner_ibfk_1` FOREIGN KEY (`id_entree`) REFERENCES `entree` (`id_entree`),
  ADD CONSTRAINT `approvisionner_ibfk_2` FOREIGN KEY (`id_tournee`) REFERENCES `tournee` (`id_tournee`);

--
-- Contraintes pour la table `coefficientco2`
--
ALTER TABLE `coefficientco2`
  ADD CONSTRAINT `coefficientco2_ibfk_1` FOREIGN KEY (`id_type_vehicule`) REFERENCES `type_vehicule` (`id_type_vehicule`);

--
-- Contraintes pour la table `entree`
--
ALTER TABLE `entree`
  ADD CONSTRAINT `entree_ibfk_1` FOREIGN KEY (`id_partenaire`) REFERENCES `partenaire` (`id_partenaire`);

--
-- Contraintes pour la table `livraison`
--
ALTER TABLE `livraison`
  ADD CONSTRAINT `livraison_ibfk_1` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_client`),
  ADD CONSTRAINT `livraison_ibfk_2` FOREIGN KEY (`id_tournee`) REFERENCES `tournee` (`id_tournee`);

--
-- Contraintes pour la table `tournee`
--
ALTER TABLE `tournee`
  ADD CONSTRAINT `tournee_ibfk_1` FOREIGN KEY (`id_livreur`) REFERENCES `livreur` (`id_livreur`),
  ADD CONSTRAINT `tournee_ibfk_2` FOREIGN KEY (`id_vehicule`) REFERENCES `vehicule` (`id_vehicule`);

--
-- Contraintes pour la table `vehicule`
--
ALTER TABLE `vehicule`
  ADD CONSTRAINT `vehicule_ibfk_1` FOREIGN KEY (`id_type_vehicule`) REFERENCES `type_vehicule` (`id_type_vehicule`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
