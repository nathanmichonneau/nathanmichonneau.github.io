# -*- coding: utf-8 -*-
"""
Créateur : Nathan MICHONNEAU / Alix Gouriet
Application GreenSD - Version 11
"""

# ============================================================
# IMPORTS
# ============================================================

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import subprocess
import mysql.connector
from datetime import datetime
import json
import os

# =====================
# CHEMINS DES FICHIERS
# =====================

SCRIPT_DIR        = os.path.dirname(os.path.abspath(__file__))
FICHIER_CONFIG    = os.path.join(SCRIPT_DIR, "greensd_config.json")
FICHIER_CREATION  = os.path.join(SCRIPT_DIR, "greensd_create.sql")
FICHIER_INSERTION = os.path.join(SCRIPT_DIR, "greensd_insertion.sql")

# ===================================
# CONFIGURATION DE LA BASE DE DONNÉES
# ===================================

BD_CONFIG = {
    "host":     "127.0.0.1",
    "user":     "root",
    "password": "",
    "database": ""
}

# Liste des tables du projet (hors requetes_sql)
TABLES = [
    "partenaire", "livreur", "client", "vehicule",
    "type_vehicule", "entree", "tournee",
    "livraison", "coefficientco2"
]

# =======================================
# SAUVEGARDE ET CHARGEMENT DE LA CONFIG
# ======================================

def charger_config():
    """Charge la dernière base utilisée depuis le fichier JSON."""
    try:
        if os.path.exists(FICHIER_CONFIG):
            with open(FICHIER_CONFIG, "r", encoding="utf-8") as f:
                data = json.load(f)
            BD_CONFIG["database"] = data.get("last_database", "")
    except Exception:
        pass

def sauvegarder_config():
    """Sauvegarde le nom de la base active dans le fichier JSON."""
    try:
        with open(FICHIER_CONFIG, "w", encoding="utf-8") as f:
            json.dump({"last_database": BD_CONFIG["database"]}, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

# ======================
# COULEURS ET POLICES
# ======================

COULEURS = {
    "bg":              "#0f172a",
    "bg_clair":        "#1e293b",
    "bg_input":        "#334155",
    "topbar":          "#020617",
    "texte":           "#e2e8f0",
    "texte_gris":      "#94a3b8",
    "texte_blanc":     "#f8fafc",
    "vert":            "#10b981",
    "bleu":            "#6366f1",
    "orange":          "#f97316",
    "rouge":           "#f43f5e",
    "violet":          "#a855f7",
    "rose":            "#ec4899",
    "bleu_fonce":      "#3b82f6",
    "separateur":      "#1e3a5f",
    "carte_tables":    "#1e3a8a",
    "carte_data":      "#064e3b",
    "carte_requetes":  "#4c1d95",
    "accent_tables":   "#93c5fd",
    "accent_data":     "#6ee7b7",
    "accent_requetes": "#d8b4fe",
    "connecte":        "#34d399",
    "deconnecte":      "#fb7185",
    "survol":          "#334155",
    "requetes_card":   "#2d1b4e",
    "requetes_border": "#a855f7",
    "cyan":            "#06b6d4",
}

POLICE_TITRE  = ("Helvetica", 20, "bold")
POLICE_SOUS   = ("Helvetica", 13, "bold")
POLICE_CORPS  = ("Helvetica", 10)
POLICE_CORPS_B= ("Helvetica", 10, "bold")
POLICE_MONO   = ("Courier", 10)
POLICE_MONO_B = ("Courier", 11, "bold")
POLICE_STAT_N = ("Helvetica", 30, "bold")
POLICE_STAT_L = ("Helvetica", 9)

# ==============================
# CONNEXION À LA BASE DE DONNÉES
# ==============================

def connecter_bd():
    """
    Tente de se connecter à MySQL.
    Retourne (connexion, curseur) si succès, ou (None, None) si échec.
    """
    if not BD_CONFIG["database"]:
        return None, None
    try:
        db = mysql.connector.connect(**BD_CONFIG)
        return db, db.cursor()
    except Exception as erreur:
        messagebox.showerror("Erreur de connexion", f"Connexion impossible :\n{erreur}")
        return None, None

def tester_connexion():
    """Vérifie si la connexion fonctionne. Retourne True ou False."""
    if not BD_CONFIG["database"]:
        return False
    try:
        db = mysql.connector.connect(**BD_CONFIG)
        db.close()
        return True
    except:
        return False

# ============================
# EXÉCUTION DES FICHIERS SQL
# ============================

def decouper_sql(sql):
    """
    Découpe un fichier SQL en plusieurs requêtes séparées par des ';'.
    Retourne une liste de requêtes (chaînes de texte).
    """
    requetes = []
    for morceau in sql.split(";"):
        req = morceau.strip()
        if req:
            requetes.append(req)
    return requetes

def executer_fichier_sql(chemin_fichier):
    """
    Lit un fichier .sql et exécute chaque requête une par une.
    Retourne (True, "") si tout va bien, ou (False, "erreur") si problème.
    """
    if not os.path.exists(chemin_fichier):
        return False, f"Fichier introuvable :\n{chemin_fichier}"

    db, cur = connecter_bd()
    if not db:
        return False, "Connexion à la base impossible."

    try:
        with open(chemin_fichier, "r", encoding="utf-8") as f:
            sql = f.read()

        requetes = decouper_sql(sql)

        for req in requetes:
            try:
                cur.execute(req)
            except mysql.connector.Error as e:
                db.rollback()
                return False, f"Erreur sur la requête :\n{req[:120]}...\n\nMySQL : {e.msg}"

        db.commit()
        return True, ""

    except Exception as e:
        return False, str(e)
    finally:
        cur.close()
        db.close()

# =================================
# STATISTIQUES DU TABLEAU DE BORD
# =================================
def compter_tables_bdd():
    """Compte le nombre réel de tables dans la base de données."""
    try:
        db, cur = connecter_bd()
        if not db:
            return 0
        cur.execute("SHOW TABLES")  # récupère la liste des tables dans la base
        nb = len(cur.fetchall())    # fetchall retourne une liste, on compte sa longueur
        cur.close()
        db.close()
        return nb
    except:
        return 0
    
def compter_enregistrements_total():
    """Compte le nombre total de lignes dans toutes les tables."""
    try:
        db, cur = connecter_bd()
        if not db:
            return 0
        total = 0
        for table in TABLES:
            try:
                cur.execute(f"SELECT COUNT(*) FROM {table}")
                total += cur.fetchone()[0]
            except:
                pass
        cur.close()
        db.close()
        return total
    except:
        return 0

def compter_requetes_bdd():
    """Compte le nombre de requêtes dans la table requetes_sql."""
    try:
        db, cur = connecter_bd()
        if not db:
            return 0
        cur.execute("SELECT COUNT(*) FROM requetes_sql")
        nb = cur.fetchone()[0]
        cur.close()
        db.close()
        return nb
    except:
        return 0

# ============================================================
# BARRE DU HAUT (TOPBAR)
# ============================================================

def creer_topbar():
    """Crée la barre noire en haut avec l'heure, le titre et l'état de connexion."""
    wrapper = tk.Frame(fenetre, bg=COULEURS["bleu"], height=52)
    wrapper.pack(fill=tk.X, side=tk.TOP)
    wrapper.pack_propagate(False)

    bar = tk.Frame(wrapper, bg=COULEURS["topbar"], height=50)
    bar.pack(fill=tk.BOTH, expand=True, pady=(0, 2))
    bar.pack_propagate(False)

    horloge = tk.Label(bar, text="", bg=COULEURS["topbar"],
                       fg=COULEURS["texte_gris"], font=POLICE_MONO)
    horloge.pack(side=tk.LEFT, padx=15)

    def maj_heure():
        """Met à jour l'horloge toutes les secondes."""
        horloge.config(text="⏱  " + datetime.now().strftime("%H:%M:%S"))
        fenetre.after(1000, maj_heure)

    maj_heure()

    tk.Label(bar, text="🚛  GreenSD", bg=COULEURS["topbar"],
             fg=COULEURS["texte_blanc"], font=POLICE_MONO_B).pack(side=tk.LEFT, padx=10)

    tk.Button(bar, text="✕  Quitter", bg=COULEURS["rouge"], fg="white",
              font=POLICE_CORPS_B, relief="flat", padx=12,
              activebackground="#be123c", cursor="hand2",
              command=fenetre.destroy).pack(side=tk.RIGHT, padx=12, pady=8)

    global label_connexion, label_bd_active

    label_connexion = tk.Label(bar, text="", bg=COULEURS["topbar"], font=("Helvetica", 9), padx=8)
    label_connexion.pack(side=tk.RIGHT, padx=5)

    label_bd_active = tk.Label(bar, text="", bg=COULEURS["topbar"],
                               fg=COULEURS["cyan"], font=("Helvetica", 9, "bold"), padx=8)
    label_bd_active.pack(side=tk.RIGHT, padx=5)

    maj_indicateur_connexion()

def maj_indicateur_connexion():
    """Met à jour l'indicateur de connexion toutes les 5 secondes."""
    if tester_connexion():
        label_connexion.config(text="⬤  BDD connectée",   fg=COULEURS["connecte"],   bg=COULEURS["topbar"])
    else:
        label_connexion.config(text="⬤  BDD déconnectée", fg=COULEURS["deconnecte"], bg=COULEURS["topbar"])

    nom = BD_CONFIG['database'] if BD_CONFIG['database'] else "aucune"
    label_bd_active.config(text=f"🗄  {nom}")
    fenetre.after(5000, maj_indicateur_connexion)

# ============================================================
# UTILITAIRES D'AFFICHAGE
# ============================================================

def nettoyer():
    """Supprime tous les widgets de la zone principale."""
    for widget in zone.winfo_children():
        widget.destroy()

def titre(texte, sous=False):
    """Affiche un titre avec une ligne de séparation dessous."""
    police = POLICE_SOUS if sous else POLICE_TITRE
    tk.Label(zone, text=texte, font=police,
             bg=COULEURS["bg"], fg=COULEURS["texte"]).pack(pady=(18, 4))
    tk.Frame(zone, bg=COULEURS["separateur"], height=2).pack(fill=tk.X, padx=25, pady=4)

def btn_table(parent, texte, commande):
    """Crée un bouton de sélection de table avec bordure bleue."""
    frame = tk.Frame(parent, bg=COULEURS["bleu"], padx=2)
    frame.pack(pady=3, padx=30)
    tk.Button(frame, text=texte, command=commande,
              bg=COULEURS["bg_clair"], fg=COULEURS["texte"],
              font=POLICE_CORPS, activebackground=COULEURS["survol"],
              activeforeground=COULEURS["texte_blanc"],
              width=26, pady=8, relief="flat", cursor="hand2", anchor="w").pack()

def btn_action(parent, texte, couleur, commande):
    """Crée un grand bouton d'action coloré."""
    tk.Button(parent, text=texte, command=commande,
              bg=couleur, fg="white", font=("Helvetica", 11, "bold"),
              activebackground=couleur, width=30, pady=10,
              relief="flat", cursor="hand2").pack(pady=5)

def btn_retour(commande):
    """Crée le bouton '← Retour'."""
    tk.Button(zone, text="←  Retour", command=commande,
              bg=COULEURS["bg_clair"], fg=COULEURS["texte_gris"],
              font=POLICE_CORPS, relief="flat", padx=15, pady=6,
              activebackground=COULEURS["survol"], cursor="hand2").pack(pady=12)

# ============================================================
# SÉLECTION DE TABLE
# ============================================================

def afficher_selection_tables(cmd_par_table, retour_cmd):
    """
    Affiche la liste des tables à gauche et la table requetes_sql à droite.
    cmd_par_table : fonction à appeler quand on clique sur une table.
    """
    frame_principal = tk.Frame(zone, bg=COULEURS["bg"])
    frame_principal.pack(fill=tk.BOTH, expand=True, padx=10, pady=4)

    # Partie gauche : tables métier
    frame_gauche = tk.Frame(frame_principal, bg=COULEURS["bg"])
    frame_gauche.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    for t in TABLES:
        # lambda table=t capture la valeur de t à chaque tour de boucle
        btn_table(frame_gauche, t, lambda table=t: cmd_par_table(table))

    # Partie droite : requetes_sql en carte violette
    frame_droite = tk.Frame(frame_principal, bg=COULEURS["bg"])
    frame_droite.pack(side=tk.RIGHT, anchor="n", padx=(10, 20), pady=4)

    carte = tk.Frame(frame_droite, bg=COULEURS["requetes_card"],
                     bd=2, relief="groove", padx=6, pady=6)
    carte.pack(anchor="n")

    tk.Label(carte, text="🔍  Table des requetes SQL",
             bg=COULEURS["requetes_card"], fg=COULEURS["texte_gris"],
             font=("Helvetica", 8)).pack(anchor="w", padx=4)

    tk.Button(carte, text="📝  requetes_sql",
              command=lambda: cmd_par_table("requetes_sql"),
              bg=COULEURS["violet"], fg="white",
              font=("Helvetica", 11, "bold"),
              activebackground=COULEURS["requetes_border"],
              width=18, pady=12, relief="flat", cursor="hand2").pack(padx=4, pady=(2, 4))

    tk.Label(carte, text="Requêtes SQL enregistrées",
             bg=COULEURS["requetes_card"], fg=COULEURS["accent_requetes"],
             font=("Helvetica", 8)).pack(anchor="w", padx=4, pady=(0, 2))

    btn_retour(retour_cmd)

# ============================================================
# TREEVIEW (TABLEAU D'AFFICHAGE)
# ============================================================

def creer_treeview():
    """Crée et retourne un tableau Treeview stylisé avec scrollbar."""
    frame = tk.Frame(zone, bg=COULEURS["bg_clair"], bd=0)
    frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)

    style = ttk.Style()
    style.theme_use("default")
    style.configure("Treeview",
                    background=COULEURS["bg_clair"], foreground=COULEURS["texte"],
                    rowheight=28, fieldbackground=COULEURS["bg_clair"], font=POLICE_MONO)
    style.configure("Treeview.Heading",
                    background=COULEURS["topbar"], foreground=COULEURS["texte_blanc"],
                    font=POLICE_CORPS_B, relief="flat")
    style.map("Treeview",
              background=[("selected", COULEURS["bleu"])],
              foreground=[("selected", "white")])

    scroll = tk.Scrollbar(frame, bg=COULEURS["bg"])
    scroll.pack(side=tk.RIGHT, fill=tk.Y)

    tree = ttk.Treeview(frame, yscrollcommand=scroll.set)
    tree.pack(fill=tk.BOTH, expand=True)
    scroll.config(command=tree.yview)

    return tree

def charger_table(tree, table):
    """
    Charge toutes les données d'une table dans le Treeview.
    Retourne la liste des noms de colonnes.
    """
    db, cur = connecter_bd()
    if not db:
        return None

    cur.execute(f"SELECT * FROM {table}")
    rows = cur.fetchall()

    # On récupère les noms de colonnes depuis cur.description
    # cur.description contient des tuples : (nom, type, ...)
    # On prend juste le premier élément (l'index 0) de chaque tuple
    cols = []
    for description_colonne in cur.description:
        nom_colonne = description_colonne[0]
        cols.append(nom_colonne)

    tree["columns"] = cols
    tree["show"]    = "headings"

    for c in cols:
        tree.heading(c, text=c)
        tree.column(c, width=130)

    for r in rows:
        tree.insert("", "end", values=r)

    cur.close()
    db.close()
    return cols

# ============================================================
# TABLEAU DE BORD
# ============================================================

def creer_carte_stat(parent, valeur, label, couleur_fond, couleur_accent):
    """Crée une carte colorée qui affiche une statistique."""
    carte = tk.Frame(parent, bg=couleur_fond, padx=24, pady=18, relief="flat")
    carte.pack(side=tk.LEFT, padx=10, pady=8, fill=tk.BOTH, expand=True)
    tk.Label(carte, text=str(valeur), font=POLICE_STAT_N,
             bg=couleur_fond, fg=couleur_accent).pack()
    tk.Label(carte, text=label, font=POLICE_STAT_L,
             bg=couleur_fond, fg="#cbd5e1").pack(pady=(2, 0))

def menu_principal():
    """Affiche la page d'accueil avec les statistiques et les boutons."""
    nettoyer()
    titre("Tableau de bord")

    ligne_cartes = tk.Frame(zone, bg=COULEURS["bg"])
    ligne_cartes.pack(pady=(6, 14), padx=30, fill=tk.X)

    nb_tables = compter_tables_bdd()
    nb_enregistrements = compter_enregistrements_total()
    nb_requetes        = compter_requetes_bdd()

    creer_carte_stat(ligne_cartes, nb_tables, "📋  Tables",
                     COULEURS["carte_tables"], COULEURS["accent_tables"])
    creer_carte_stat(ligne_cartes, nb_enregistrements, "📦  Enregistrements",
                     COULEURS["carte_data"], COULEURS["accent_data"])
    creer_carte_stat(ligne_cartes, nb_requetes, "🔍  Requêtes SQL",
                     COULEURS["carte_requetes"], COULEURS["accent_requetes"])

    tk.Frame(zone, bg=COULEURS["separateur"], height=2).pack(fill=tk.X, padx=25, pady=6)

    actions = [
        ("📊  Visualiser",          COULEURS["bleu"],     visualiser),
        ("➕  Ajouter",              COULEURS["vert"],     ajouter),
        ("✏️   Modifier",            COULEURS["orange"],   modifier),
        ("🗑️   Supprimer",           COULEURS["rouge"],    supprimer),
        ("🔍  Requêtes SQL",         COULEURS["violet"],   requetes),
        ("⚙️   Administration BDD",  COULEURS["rose"],     admin),
    ]
    for texte, couleur, cmd in actions:
        btn_action(zone, texte, couleur, cmd)

# ============================================================
# VISUALISER
# ============================================================

def visualiser():
    """Affiche la liste des tables pour choisir laquelle visualiser."""
    nettoyer()
    titre("Visualiser une table")
    afficher_selection_tables(cmd_par_table=afficher_table, retour_cmd=menu_principal)

def afficher_table(table):
    """Affiche toutes les données d'une table dans un tableau."""
    nettoyer()
    titre(f"Table : {table}")
    tree = creer_treeview()
    charger_table(tree, table)
    btn_retour(visualiser)

# ============================================================
# ADMINISTRATION BDD
# ============================================================

def admin():
    """Page d'administration : créer, remplir, vider les tables."""
    nettoyer()
    titre("⚙️  Administration BDD")

    tk.Label(zone, text=f"Base active : {BD_CONFIG['database'] or '(aucune)'}",
             bg=COULEURS["bg"], fg=COULEURS["cyan"],
             font=("Helvetica", 10, "bold")).pack(pady=(0, 8))

    actions = [
        ("🗄️  Créer ou rejoindre une Database", COULEURS["cyan"],       creer_database),
        ("🏗️  Créer les tables",                COULEURS["bleu_fonce"], create),
        ("➕  Insérer les données",              COULEURS["rose"],       insertion),
        ("▶️  Exécuter script Python",           COULEURS["violet"],     executer_python),
        ("🔨  Supprimer les tables",             COULEURS["rouge"],      suppression_table),
    ]
    for texte, couleur, cmd in actions:
        btn_action(zone, texte, couleur, cmd)

    btn_retour(menu_principal)

# ============================================================
# CRÉER UNE BASE DE DONNÉES
# ============================================================

def creer_database():
    """Ouvre une popup pour créer une nouvelle base de données MySQL."""
    fen = tk.Toplevel(fenetre)
    fen.title("Créer une nouvelle base de données")
    fen.configure(bg=COULEURS["bg"])
    fen.resizable(False, False)
    fen.grab_set()
    fen.geometry("420x240")
    fen.update_idletasks()
    x = fenetre.winfo_x() + (fenetre.winfo_width()  // 2) - 210
    y = fenetre.winfo_y() + (fenetre.winfo_height() // 2) - 120
    fen.geometry(f"+{x}+{y}")

    tk.Label(fen, text="🗄️  Créer une nouvelle base de données",
             bg=COULEURS["bg"], fg=COULEURS["texte_blanc"],
             font=("Helvetica", 12, "bold")).pack(pady=(20, 6))
    tk.Frame(fen, bg=COULEURS["separateur"], height=2).pack(fill=tk.X, padx=20, pady=4)
    tk.Label(fen, text="Nom de la base :",
             bg=COULEURS["bg"], fg=COULEURS["texte"], font=POLICE_CORPS).pack(pady=(10, 4))

    entry_nom = tk.Entry(fen, font=POLICE_MONO, width=28,
                         bg=COULEURS["bg_input"], fg=COULEURS["texte"],
                         insertbackground=COULEURS["texte"], relief="flat")
    entry_nom.pack(ipady=6)
    entry_nom.focus_set()

    label_erreur = tk.Label(fen, text="", bg=COULEURS["bg"],
                            fg=COULEURS["rouge"], font=("Helvetica", 9))
    label_erreur.pack(pady=2)

    def valider():
        """Vérifie le nom et crée la base si tout est correct."""
        nom = entry_nom.get().strip()
        if not nom:
            label_erreur.config(text="⚠  Le nom ne peut pas être vide.")
            return
        if not nom.replace("_", "").replace("-", "").isalnum():
            label_erreur.config(text="⚠  Utilisez uniquement lettres, chiffres, _ ou -")
            return
        try:
            conn_sans_bd = mysql.connector.connect(
                host=BD_CONFIG["host"],
                user=BD_CONFIG["user"],
                password=BD_CONFIG["password"]
            )
            cur_tmp = conn_sans_bd.cursor()
            cur_tmp.execute(
                f"CREATE DATABASE IF NOT EXISTS `{nom}` "
                f"CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
            )
            conn_sans_bd.commit()
            cur_tmp.close()
            conn_sans_bd.close()

            BD_CONFIG["database"] = nom
            sauvegarder_config()
            label_bd_active.config(text=f"🗄  {BD_CONFIG['database']}")
            fen.destroy()
            messagebox.showinfo("Base créée", f"✔  La base « {nom} » a été créée.")
            admin()

        except mysql.connector.Error as e:
            label_erreur.config(text=f"⚠  Erreur MySQL : {e.msg}")
        except Exception as erreur:
            label_erreur.config(text=f"⚠  Erreur : {str(erreur)}")

    entry_nom.bind("<Return>", lambda event: valider())

    frame_btns = tk.Frame(fen, bg=COULEURS["bg"])
    frame_btns.pack(pady=10)

    tk.Button(frame_btns, text="✔  Créer",
              bg=COULEURS["cyan"], fg="white", font=POLICE_CORPS_B,
              relief="flat", padx=18, pady=8, cursor="hand2",
              activebackground="#0891b2", command=valider).pack(side=tk.LEFT, padx=8)

    tk.Button(frame_btns, text="✕  Annuler",
              bg=COULEURS["bg_clair"], fg=COULEURS["texte_gris"],
              font=POLICE_CORPS, relief="flat", padx=18, pady=8,
              cursor="hand2", activebackground=COULEURS["survol"],
              command=fen.destroy).pack(side=tk.LEFT, padx=8)

# ============================================================
# EXÉCUTER UN SCRIPT PYTHON
# ============================================================

def executer_python():
    """Ouvre un sélecteur de fichier pour lancer un script .py externe."""
    chemin_script = filedialog.askopenfilename(
        title="Choisir un script Python à exécuter",
        filetypes=[("Scripts Python", "*.py"), ("Tous les fichiers", "*.*")]
    )
    if not chemin_script:
        return
    try:
        subprocess.Popen(["python", chemin_script])
        messagebox.showinfo("Succès", f"Script lancé :\n{chemin_script}")
    except FileNotFoundError:
        try:
            subprocess.Popen(["python3", chemin_script])
            messagebox.showinfo("Succès", f"Script lancé :\n{chemin_script}")
        except Exception as erreur:
            messagebox.showerror("Erreur", f"Impossible de lancer le script :\n{erreur}")
    except Exception as erreur:
        messagebox.showerror("Erreur", f"Impossible de lancer le script :\n{erreur}")

# ============================================================
# CRÉER LES TABLES / INSÉRER / SUPPRIMER TOUTES LES TABLES
# ============================================================

def create():
    """Exécute le fichier SQL de création des tables."""
    if not BD_CONFIG["database"]:
        messagebox.showwarning("Aucune base", "Veuillez d'abord créer ou sélectionner une base.")
        return
    ok, erreur = executer_fichier_sql(FICHIER_CREATION)
    if ok:
        messagebox.showinfo("Succès", "✔  Toutes les tables ont été créées.")
    else:
        messagebox.showerror("Erreur", erreur)

def insertion():
    """Exécute le fichier SQL d'insertion des données."""
    if not BD_CONFIG["database"]:
        messagebox.showwarning("Aucune base", "Veuillez d'abord créer ou sélectionner une base.")
        return
    ok, erreur = executer_fichier_sql(FICHIER_INSERTION)
    if ok:
        messagebox.showinfo("Succès", "✔  Toutes les données ont été insérées.")
    else:
        messagebox.showerror("Erreur", erreur)

def suppression_table():
    """Supprime toutes les tables après confirmation."""
    if not messagebox.askyesno("Confirmation", "⚠️ Supprimer toutes les tables ?"):
        return
    db, cur = connecter_bd()
    if not db:
        return
    try:
        cur.execute("SHOW TABLES")
        tables = cur.fetchall()
        cur.execute("SET FOREIGN_KEY_CHECKS = 0")
        for t in tables:
            cur.execute(f"DROP TABLE {t[0]}")
        cur.execute("SET FOREIGN_KEY_CHECKS = 1")
        db.commit()
        messagebox.showinfo("Succès", "Tables supprimées ✔")
    except Exception as e:
        messagebox.showerror("Erreur", str(e))
    finally:
        cur.close()
        db.close()
    admin()

# ============================================================
# AJOUTER UN ENREGISTREMENT
# ============================================================

def ajouter():
    """Affiche la liste des tables pour choisir où ajouter."""
    nettoyer()
    titre("Ajouter un enregistrement")
    afficher_selection_tables(cmd_par_table=formulaire_ajout, retour_cmd=menu_principal)

def formulaire_ajout(table):
    """
    Affiche un formulaire avec un champ pour chaque colonne de la table.
    La clé primaire (première colonne) est exclue car auto-incrémentée.
    """
    nettoyer()
    titre(f"Ajouter dans : {table}", sous=True)

    db, cur = connecter_bd()
    if not db:
        return

    cur.execute(f"DESCRIBE {table}")
    resultats = cur.fetchall()

    # On construit la liste des colonnes en excluant la première (clé primaire)
    colonnes = []
    for i in range(1, len(resultats)):   # On commence à 1 pour sauter la clé primaire
        colonnes.append(resultats[i][0]) # On prend l'index 0 = le nom de la colonne

    cur.close()
    db.close()

    champs = {}  # Dictionnaire {nom_colonne: widget Entry}

    for col in colonnes:
        frame = tk.Frame(zone, bg=COULEURS["bg"])
        frame.pack(pady=4)
        tk.Label(frame, text=col, width=24, anchor="w",
                 bg=COULEURS["bg"], fg=COULEURS["texte"], font=POLICE_CORPS).pack(side=tk.LEFT)
        entry = tk.Entry(frame, font=POLICE_MONO, width=26,
                         bg=COULEURS["bg_input"], fg=COULEURS["texte"],
                         insertbackground=COULEURS["texte"], relief="flat")
        entry.pack(side=tk.LEFT)
        champs[col] = entry

    btn_action(zone, "✔  Valider l'ajout", COULEURS["vert"],
               lambda: valider_ajout(table, colonnes, champs))
    btn_retour(ajouter)

def valider_ajout(table, colonnes, champs):
    """Lit les valeurs du formulaire et les insère dans la table."""
    try:
        db, cur = connecter_bd()
        if not db:
            return

        # On construit la liste des valeurs (None = NULL si champ vide)
        valeurs = []
        for col in colonnes:
            valeur_saisie = champs[col].get()
            if valeur_saisie == "":
                valeurs.append(None)   # Champ vide → NULL en SQL
            else:
                valeurs.append(valeur_saisie)

        # Construit les "?" pour la requête : "%s, %s, %s, ..."
        placeholders = ", ".join(["%s"] * len(valeurs))

        cur.execute(
            f"INSERT INTO {table} ({', '.join(colonnes)}) VALUES ({placeholders})",
            valeurs
        )
        db.commit()
        cur.close()
        db.close()
        messagebox.showinfo("Succès", "Enregistrement ajouté ✔")
        ajouter()

    except Exception as erreur:
        messagebox.showerror("Erreur SQL", str(erreur))

# ============================================================
# MODIFIER UN ENREGISTREMENT
# ============================================================

def modifier():
    """Affiche la liste des tables pour choisir laquelle modifier."""
    nettoyer()
    titre("Modifier un enregistrement")
    afficher_selection_tables(cmd_par_table=liste_modifier, retour_cmd=menu_principal)

def liste_modifier(table):
    """Affiche les données. Double-clic sur une ligne pour la modifier."""
    nettoyer()
    titre(f"Double-clic pour modifier : {table}", sous=True)
    tree = creer_treeview()
    colonnes = charger_table(tree, table)
    tree.bind("<Double-1>",
              lambda event: ouvrir_formulaire_modification(tree, table, colonnes))
    btn_retour(modifier)

def ouvrir_formulaire_modification(tree, table, colonnes):
    """Ouvre une popup avec les valeurs pré-remplies pour les modifier."""
    ligne = tree.selection()
    if not ligne:
        return

    valeurs = tree.item(ligne[0])["values"]

    fen = tk.Toplevel(fenetre)
    fen.title("Modifier un enregistrement")
    fen.configure(bg=COULEURS["bg"])
    fen.resizable(False, False)

    champs = {}

    for i in range(len(colonnes)):
        col = colonnes[i]
        frame = tk.Frame(fen, bg=COULEURS["bg"])
        frame.pack(pady=5, padx=20)
        tk.Label(frame, text=col, width=22, anchor="w",
                 bg=COULEURS["bg"], fg=COULEURS["texte"], font=POLICE_CORPS).pack(side=tk.LEFT)
        entry = tk.Entry(frame, width=26, bg=COULEURS["bg_input"],
                         fg=COULEURS["texte"], insertbackground=COULEURS["texte"],
                         font=POLICE_MONO, relief="flat")
        entry.insert(0, valeurs[i])

        # La clé primaire (i==0) n'est pas modifiable
        if i == 0:
            entry.config(state="readonly", bg=COULEURS["bg_clair"],
                         fg=COULEURS["texte_gris"])

        entry.pack(side=tk.LEFT)
        champs[col] = entry

    tk.Button(fen, text="✔  Valider la modification",
              bg=COULEURS["vert"], fg="white", font=POLICE_CORPS_B,
              relief="flat", padx=15, pady=8, cursor="hand2",
              command=lambda: valider_modification(table, colonnes, champs, valeurs, fen)
              ).pack(pady=12)

def valider_modification(table, colonnes, champs, valeurs, fen):
    """Enregistre les modifications dans la base (toutes les colonnes sauf la clé primaire)."""
    db, cur = connecter_bd()
    if not db:
        return
    try:
        # On construit "col1=%s, col2=%s, ..." pour toutes les colonnes sauf la clé primaire
        updates = []
        for col in colonnes[1:]:
            updates.append(f"{col}=%s")

        # Nouvelles valeurs + clé primaire pour le WHERE à la fin
        valeurs_new = []
        for col in colonnes[1:]:
            valeurs_new.append(champs[col].get())
        valeurs_new.append(valeurs[0])

        cur.execute(
            f"UPDATE {table} SET {', '.join(updates)} WHERE {colonnes[0]}=%s",
            valeurs_new
        )
        db.commit()

    except Exception as e:
        messagebox.showerror("Erreur SQL", str(e))
    finally:
        cur.close()
        db.close()

    fen.destroy()
    liste_modifier(table)

# ============================================================
# SUPPRIMER UN ENREGISTREMENT
# ============================================================

def supprimer_cascade(cur, table, cle):
    """
    Supprime d'abord les données liées avant de supprimer l'enregistrement principal.
    C'est obligatoire à cause des clés étrangères (contraintes de référence).

    Ordre de suppression basé sur le MCD :
    approvisionner référence entree ET tournee
    livraison référence tournee ET client
    tournee référence livreur ET vehicule
    vehicule référence type_vehicule
    coefficientco2 référence type_vehicule
    """

    if table == "partenaire":
        # partenaire → entree → approvisionner
        cur.execute(
            "DELETE FROM approvisionner WHERE id_entree IN "
            "(SELECT id_entree FROM entree WHERE id_partenaire=%s)", (cle,)
        )
        cur.execute("DELETE FROM entree WHERE id_partenaire=%s", (cle,))

    elif table == "entree":
        # entree est référencée dans approvisionner (id_entree)
        # Il faut supprimer les liens dans approvisionner avant de supprimer l'entrée
        cur.execute("DELETE FROM approvisionner WHERE id_entree=%s", (cle,))

    elif table == "client":
        # client est référencé dans livraison (id_client)
        cur.execute("DELETE FROM livraison WHERE id_client=%s", (cle,))

    elif table == "livreur":
        #livreur → tournee → approvisionner ET livraison
        # On doit supprimer approvisionner en premier car il référence tournee
        cur.execute(
            "DELETE FROM approvisionner WHERE id_tournee IN "
            "(SELECT id_tournee FROM tournee WHERE id_livreur=%s)", (cle,)
        )
        cur.execute(
            "DELETE FROM livraison WHERE id_tournee IN "
            "(SELECT id_tournee FROM tournee WHERE id_livreur=%s)", (cle,)
        )
        cur.execute("DELETE FROM tournee WHERE id_livreur=%s", (cle,))

    elif table == "vehicule":
        # vehicule → tournee → approvisionner ET livraison
        cur.execute(
            "DELETE FROM approvisionner WHERE id_tournee IN "
            "(SELECT id_tournee FROM tournee WHERE id_vehicule=%s)", (cle,)
        )
        cur.execute(
            "DELETE FROM livraison WHERE id_tournee IN "
            "(SELECT id_tournee FROM tournee WHERE id_vehicule=%s)", (cle,)
        )
        cur.execute("DELETE FROM tournee WHERE id_vehicule=%s", (cle,))

    elif table == "tournee":
        #tournee est référencée dans approvisionner ET livraison
        cur.execute("DELETE FROM approvisionner WHERE id_tournee=%s", (cle,))
        cur.execute("DELETE FROM livraison WHERE id_tournee=%s", (cle,))

    elif table == "type_vehicule":
        #type_vehicule → vehicule → tournee → approvisionner ET livraison
        # On descend la cascade complète du plus profond au plus proche
        cur.execute(
            "DELETE FROM approvisionner WHERE id_tournee IN "
            "(SELECT id_tournee FROM tournee WHERE id_vehicule IN "
            "(SELECT id_vehicule FROM vehicule WHERE id_type_vehicule=%s))", (cle,)
        )
        cur.execute(
            "DELETE FROM livraison WHERE id_tournee IN "
            "(SELECT id_tournee FROM tournee WHERE id_vehicule IN "
            "(SELECT id_vehicule FROM vehicule WHERE id_type_vehicule=%s))", (cle,)
        )
        cur.execute(
            "DELETE FROM tournee WHERE id_vehicule IN "
            "(SELECT id_vehicule FROM vehicule WHERE id_type_vehicule=%s)", (cle,)
        )
        cur.execute("DELETE FROM coefficientco2 WHERE id_type_vehicule=%s", (cle,))
        cur.execute("DELETE FROM vehicule WHERE id_type_vehicule=%s", (cle,))


def supprimer_ligne(tree, table, colonnes):
    """Supprime la ligne sélectionnée dans le tableau (avec cascade si nécessaire)."""
    sel = tree.selection()
    if not sel:
        return

    valeurs = tree.item(sel[0])["values"]
    cle = valeurs[0]  # La clé primaire est toujours la première colonne

    db, cur = connecter_bd()
    if not db:
        return

    try:
        # Supprime d'abord les données liées (sauf pour requetes_sql)
        if table != "requetes_sql":
            supprimer_cascade(cur, table, cle)

        # Supprime ensuite l'enregistrement principal
        cur.execute(f"DELETE FROM {table} WHERE {colonnes[0]}=%s", (cle,))
        db.commit()

    except Exception as e:
        messagebox.showerror("Erreur SQL", str(e))
    finally:
        cur.close()
        db.close()

    liste_supprimer(table)

def liste_supprimer(table):
    """Affiche les données avec un bouton pour supprimer la ligne sélectionnée."""
    nettoyer()
    titre(f"Sélectionner puis supprimer : {table}", sous=True)
    tree = creer_treeview()
    colonnes = charger_table(tree, table)
    btn_action(zone, "🗑️  Supprimer la sélection", COULEURS["rouge"],
               lambda: supprimer_ligne(tree, table, colonnes))
    btn_retour(supprimer)

def supprimer():
    """Affiche la liste des tables pour choisir laquelle modifier."""
    nettoyer()
    titre("Supprimer un enregistrement")
    afficher_selection_tables(cmd_par_table=liste_supprimer, retour_cmd=menu_principal)

# ============================================================
# REQUÊTES SQL
# ============================================================

def afficher_requete(label, sql):
    """Exécute une requête SQL et affiche ses résultats dans un tableau."""
    nettoyer()
    titre(label, sous=True)
    tree = creer_treeview()

    try:
        db, cur = connecter_bd()
        if not db:
            return

        cur.execute(sql)
        rows = cur.fetchall()

        # Récupère les noms de colonnes du résultat
        cols = []
        for description_colonne in cur.description:
            nom_colonne = description_colonne[0]
            cols.append(nom_colonne)

        tree["columns"] = cols
        tree["show"]    = "headings"
        for c in cols:
            tree.heading(c, text=c)
            tree.column(c, width=150)

        for r in rows:
            tree.insert("", "end", values=r)

        cur.close()
        db.close()

    except Exception as erreur:
        messagebox.showerror("Erreur SQL", str(erreur))

    btn_retour(requetes)

def requetes():
    """Affiche toutes les requêtes enregistrées dans la table requetes_sql."""
    nettoyer()
    titre("Requêtes SQL (BDD)", sous=True)

    db, cur = connecter_bd()
    if not db:
        tk.Label(zone, text="Aucune base de données connectée.",
                 bg=COULEURS["bg"], fg=COULEURS["texte_gris"],
                 font=POLICE_CORPS).pack(pady=20)
        btn_retour(menu_principal)
        return

    try:
        cur.execute("SELECT NOM, CODE_SQL FROM requetes_sql")
        rows = cur.fetchall()

        if not rows:
            tk.Label(zone, text="Aucune requête enregistrée dans la base de données.",
                     bg=COULEURS["bg"], fg=COULEURS["texte_gris"],
                     font=POLICE_CORPS).pack(pady=20)
        else:
            for nom, sql in rows:
                btn_table(zone, nom, lambda l=nom, s=sql: afficher_requete(l, s))

    except Exception as erreur:
        messagebox.showerror("Erreur", f"Impossible de charger les requêtes :\n{erreur}")
    finally:
        cur.close()
        db.close()

    btn_retour(menu_principal)

# ============================================================
# LANCEMENT DE L'APPLICATION
# ============================================================

charger_config()   # 1. Charge la dernière base utilisée

fenetre = tk.Tk()  # 2. Crée la fenêtre principale
fenetre.title("GreenSD v11")
fenetre.geometry("1000x720")
fenetre.configure(bg=COULEURS["bg"])

label_connexion = None  # Ces variables sont remplies dans creer_topbar()
label_bd_active = None

creer_topbar()          # 3. Crée la barre du haut

zone = tk.Frame(fenetre, bg=COULEURS["bg"])  # 4. Zone principale (contenu)
zone.pack(fill=tk.BOTH, expand=True)

menu_principal()        # 5. Affiche le tableau de bord

fenetre.mainloop()      # 6. Lance la boucle Tkinter