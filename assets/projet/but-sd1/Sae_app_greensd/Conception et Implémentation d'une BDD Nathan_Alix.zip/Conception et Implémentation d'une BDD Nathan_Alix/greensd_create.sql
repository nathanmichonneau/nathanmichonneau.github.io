CREATE TABLE partenaire(
   id_partenaire INT AUTO_INCREMENT,
   nom_partenaire VARCHAR(50) NOT NULL,
   ville_partenaire VARCHAR(50) NOT NULL,
   PRIMARY KEY(id_partenaire)
)ENGINE = InnoDB;

CREATE TABLE entree(
   id_entree INT AUTO_INCREMENT,
   date_entree DATE NOT NULL,
   quantite_colis INT NOT NULL,
   id_partenaire INT NOT NULL,
   PRIMARY KEY(id_entree),
   FOREIGN KEY(id_partenaire) REFERENCES partenaire(id_partenaire)
)ENGINE = InnoDB;

CREATE TABLE type_vehicule(
   id_type_vehicule INT AUTO_INCREMENT,
   nom_type_vehicule VARCHAR(50) NOT NULL,
   PRIMARY KEY(id_type_vehicule)
)ENGINE = InnoDB;

CREATE TABLE vehicule(
   id_vehicule INT AUTO_INCREMENT,
   autonomie_km DOUBLE NOT NULL,
   capacite_kg DOUBLE NOT NULL,
   id_type_vehicule INT NOT NULL,
   PRIMARY KEY(id_vehicule),
   FOREIGN KEY(id_type_vehicule) REFERENCES type_vehicule(id_type_vehicule)
)ENGINE = InnoDB;

CREATE TABLE client(
   id_client INT AUTO_INCREMENT,
   nom_client VARCHAR(50) NOT NULL,
   ville_client VARCHAR(50) NOT NULL,
   PRIMARY KEY(id_client)
)ENGINE = InnoDB;

CREATE TABLE coefficientCO2(
   id_type_vehicule INT,
   annee INT,
   co2_g_km INT NOT NULL,
   PRIMARY KEY(id_type_vehicule, annee),
   FOREIGN KEY(id_type_vehicule) REFERENCES type_vehicule(id_type_vehicule)
)ENGINE = InnoDB;

CREATE TABLE Livreur(
   id_livreur INT AUTO_INCREMENT,
   nom_livreur VARCHAR(50) NOT NULL,
   prenom_livreur VARCHAR(50) NOT NULL,
   date_embauche DATE NOT NULL,
   PRIMARY KEY(id_livreur)
)ENGINE = InnoDB;

CREATE TABLE tournee(
   id_tournee INT AUTO_INCREMENT,
   date_tournee DATE NOT NULL,
   id_livreur INT NOT NULL,
   id_vehicule INT NOT NULL,
   PRIMARY KEY(id_tournee),
   FOREIGN KEY(id_livreur) REFERENCES Livreur(id_livreur),
   FOREIGN KEY(id_vehicule) REFERENCES vehicule(id_vehicule)
)ENGINE = InnoDB;

CREATE TABLE Livraison(
   id_livraison INT AUTO_INCREMENT,
   date_sortie DATE NOT NULL,
   poids_total_kg DECIMAL(15,2) DEFAULT NULL,
   adresse_complete VARCHAR(50) NOT NULL,
   nb_colis INT NOT NULL,
   id_client INT NOT NULL,
   id_tournee INT NOT NULL,
   PRIMARY KEY(id_livraison),
   FOREIGN KEY(id_client) REFERENCES client(id_client),
   FOREIGN KEY(id_tournee) REFERENCES tournee(id_tournee)
)ENGINE = InnoDB;

CREATE TABLE approvisionner(
   id_entree INT,
   id_tournee INT,
   PRIMARY KEY(id_entree, id_tournee),
   FOREIGN KEY(id_entree) REFERENCES entree(id_entree),
   FOREIGN KEY(id_tournee) REFERENCES tournee(id_tournee)
)ENGINE = InnoDB;

CREATE TABLE requetes_sql(
  ID_SQL INT AUTO_INCREMENT,
  NOM VARCHAR(255) NOT NULL,
  CODE_SQL TEXT NOT NULL,
  PRIMARY KEY(ID_SQL)
) ENGINE=InnoDB;