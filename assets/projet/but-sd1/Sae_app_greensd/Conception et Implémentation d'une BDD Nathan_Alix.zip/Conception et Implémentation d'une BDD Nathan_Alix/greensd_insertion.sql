-- ============================================================
-- FICHIER D'INSERTION DES DONNÉES - Base GreenSD
-- Ordre d'insertion important : respecter les clés étrangères
-- (insérer les tables "parents" avant les tables "enfants")
-- ============================================================


-- ============================================================
-- 1. PARTENAIRES (12 fournisseurs)
-- Table "parent" : aucune dépendance vers d'autres tables
-- Un partenaire = entreprise qui envoie des colis à GreenSD
-- ============================================================

INSERT INTO partenaire (id_partenaire, nom_partenaire, ville_partenaire) 
VALUES (1, 'LogiPro', 'Paris');
-- id=1 | Partenaire basé à Paris

INSERT INTO partenaire (id_partenaire, nom_partenaire, ville_partenaire) 
VALUES (2, 'TransExpress', 'Lyon');

INSERT INTO partenaire (id_partenaire, nom_partenaire, ville_partenaire) 
VALUES (3, 'CargoMart', 'Marseille');

INSERT INTO partenaire (id_partenaire, nom_partenaire, ville_partenaire) 
VALUES (4, 'SupplyChain SA', 'Bordeaux');

INSERT INTO partenaire (id_partenaire, nom_partenaire, ville_partenaire) 
VALUES (5, 'EcoLogistique', 'Lille');

INSERT INTO partenaire (id_partenaire, nom_partenaire, ville_partenaire) 
VALUES (6, 'FastDelivery', 'Toulouse');

INSERT INTO partenaire (id_partenaire, nom_partenaire, ville_partenaire) 
VALUES (7, 'GreenSupply', 'Nantes');

INSERT INTO partenaire (id_partenaire, nom_partenaire, ville_partenaire) 
VALUES (8, 'MegaStock', 'Strasbourg');

INSERT INTO partenaire (id_partenaire, nom_partenaire, ville_partenaire) 
VALUES (9, 'ParcelPro', 'Nice');

INSERT INTO partenaire (id_partenaire, nom_partenaire, ville_partenaire) 
VALUES (10, 'Distribution+', 'Rennes');

INSERT INTO partenaire (id_partenaire, nom_partenaire, ville_partenaire) 
VALUES (11, 'ExpressLog', 'Montpellier');

INSERT INTO partenaire (id_partenaire, nom_partenaire, ville_partenaire) 
VALUES (12, 'CargoVert', 'Grenoble');


-- ============================================================
-- 2. ENTRÉES (14 réceptions de colis)
-- Dépend de : partenaire (id_partenaire)
-- Une entrée = réception physique de colis à l'entrepôt GreenSD
-- Champs : id, date de réception, quantité de colis reçus, partenaire source
-- ============================================================

INSERT INTO entree (id_entree, date_entree, quantite_colis, id_partenaire) 
VALUES (1, '2024-01-05', 50, 1);

INSERT INTO entree (id_entree, date_entree, quantite_colis, id_partenaire) 
VALUES (2, '2024-01-08', 75, 2);

INSERT INTO entree (id_entree, date_entree, quantite_colis, id_partenaire) 
VALUES (3, '2024-01-12', 100, 3);

INSERT INTO entree (id_entree, date_entree, quantite_colis, id_partenaire) 
VALUES (4, '2024-01-15', 60, 4);

INSERT INTO entree (id_entree, date_entree, quantite_colis, id_partenaire) 
VALUES (5, '2024-01-18', 85, 5);

INSERT INTO entree (id_entree, date_entree, quantite_colis, id_partenaire) 
VALUES (6, '2024-01-22', 120, 1);

INSERT INTO entree (id_entree, date_entree, quantite_colis, id_partenaire) 
VALUES (7, '2024-01-25', 90, 6);

INSERT INTO entree (id_entree, date_entree, quantite_colis, id_partenaire) 
VALUES (8, '2024-02-01', 110, 7);

INSERT INTO entree (id_entree, date_entree, quantite_colis, id_partenaire) 
VALUES (9, '2024-02-05', 95, 8);

INSERT INTO entree (id_entree, date_entree, quantite_colis, id_partenaire) 
VALUES (10, '2024-02-10', 70, 9);

INSERT INTO entree (id_entree, date_entree, quantite_colis, id_partenaire) 
VALUES (11, '2024-02-15', 80, 10);

INSERT INTO entree (id_entree, date_entree, quantite_colis, id_partenaire) 
VALUES (12, '2024-02-20', 105, 2);
-- 2ème entrée de TransExpress (id=2)

INSERT INTO entree (id_entree, date_entree, quantite_colis, id_partenaire) 
VALUES (13, '2024-02-25', 65, 11);

INSERT INTO entree (id_entree, date_entree, quantite_colis, id_partenaire) 
VALUES (14, '2024-03-01', 125, 12);


-- ============================================================
-- 3. TYPES DE VÉHICULES (10 types)
-- Table "parent" : aucune dépendance
-- Sert de référentiel pour classer les véhicules et calculer le CO2
-- ============================================================

INSERT INTO type_vehicule (id_type_vehicule, nom_type_vehicule) 
VALUES (1, 'Camionnette electrique');

INSERT INTO type_vehicule (id_type_vehicule, nom_type_vehicule) 
VALUES (2, 'Velo cargo');       

INSERT INTO type_vehicule (id_type_vehicule, nom_type_vehicule) 
VALUES (3, 'Camion diesel');        

INSERT INTO type_vehicule (id_type_vehicule, nom_type_vehicule)
VALUES (4, 'Scooter electrique');  

INSERT INTO type_vehicule (id_type_vehicule, nom_type_vehicule) 
VALUES (5, 'Voiture hybride');    

INSERT INTO type_vehicule (id_type_vehicule, nom_type_vehicule) 
VALUES (6, 'Camion GNV');              

INSERT INTO type_vehicule (id_type_vehicule, nom_type_vehicule) 
VALUES (7, 'Triporteur electrique');

INSERT INTO type_vehicule (id_type_vehicule, nom_type_vehicule) 
VALUES (8, 'Fourgon electrique');      

INSERT INTO type_vehicule (id_type_vehicule, nom_type_vehicule) 
VALUES (9, 'Camion electrique');       

INSERT INTO type_vehicule (id_type_vehicule, nom_type_vehicule) 
VALUES (10, 'Voiture essence');     


-- ============================================================
-- 4. VÉHICULES (13 véhicules)
-- Dépend de : type_vehicule (id_type_vehicule)
-- Chaque véhicule a une autonomie, une capacité de charge et un type
-- Plusieurs véhicules peuvent avoir le même type (ex: 3 camionnettes électriques)
-- ============================================================

INSERT INTO vehicule (id_vehicule, autonomie_km, capacite_kg, id_type_vehicule) 
VALUES (1, 250.0, 500.0, 1);

INSERT INTO vehicule (id_vehicule, autonomie_km, capacite_kg, id_type_vehicule) 
VALUES (2, 40.0, 150.0, 2);

INSERT INTO vehicule (id_vehicule, autonomie_km, capacite_kg, id_type_vehicule)
VALUES (3, 600.0, 2000.0, 3);

INSERT INTO vehicule (id_vehicule, autonomie_km, capacite_kg, id_type_vehicule) 
VALUES (4, 80.0, 50.0, 4);

INSERT INTO vehicule (id_vehicule, autonomie_km, capacite_kg, id_type_vehicule) 
VALUES (5, 400.0, 800.0, 5);

INSERT INTO vehicule (id_vehicule, autonomie_km, capacite_kg, id_type_vehicule) 
VALUES (6, 500.0, 1800.0, 6);

INSERT INTO vehicule (id_vehicule, autonomie_km, capacite_kg, id_type_vehicule) 
VALUES (7, 35.0, 120.0, 7);

INSERT INTO vehicule (id_vehicule, autonomie_km, capacite_kg, id_type_vehicule) 
VALUES (8, 300.0, 1200.0, 8);

INSERT INTO vehicule (id_vehicule, autonomie_km, capacite_kg, id_type_vehicule) 
VALUES (9, 350.0, 3000.0, 9);

INSERT INTO vehicule (id_vehicule, autonomie_km, capacite_kg, id_type_vehicule) 
VALUES (10, 450.0, 700.0, 10);

INSERT INTO vehicule (id_vehicule, autonomie_km, capacite_kg, id_type_vehicule) 
VALUES (11, 280.0, 550.0, 1);

INSERT INTO vehicule (id_vehicule, autonomie_km, capacite_kg, id_type_vehicule) 
VALUES (12, 320.0, 1100.0, 8);

INSERT INTO vehicule (id_vehicule, autonomie_km, capacite_kg, id_type_vehicule) 
VALUES (13, 270.0, 480.0, 1);


-- ============================================================
-- 5. CLIENTS (15 clients)
-- Table "parent" : aucune dépendance
-- Un client = destinataire final des livraisons (commerces, restaurants...)
-- ============================================================

INSERT INTO client (id_client, nom_client, ville_client) 
VALUES (1, 'Restaurant Le Gourmet', 'Paris');

INSERT INTO client (id_client, nom_client, ville_client) 
VALUES (2, 'Boutique Mode&Style', 'Boulogne');

INSERT INTO client (id_client, nom_client, ville_client) 
VALUES (3, 'Pharmacie Centrale', 'Versailles');

INSERT INTO client (id_client, nom_client, ville_client) 
VALUES (4, 'Supermarche BioPlus', 'Paris');

INSERT INTO client (id_client, nom_client, ville_client) 
VALUES (5, 'Librairie du Coin', 'Neuilly');

INSERT INTO client (id_client, nom_client, ville_client) 
VALUES (6, 'Cafe des Arts', 'Saint-Cloud');

INSERT INTO client (id_client, nom_client, ville_client) 
VALUES (7, 'Boulangerie Artisan','Levallois');

INSERT INTO client (id_client, nom_client, ville_client) 
VALUES (8, 'Fleuriste Jardin', 'Courbevoie');

INSERT INTO client (id_client, nom_client, ville_client) 
VALUES (9, 'Epicerie Fine', 'Suresnes');

INSERT INTO client (id_client, nom_client, ville_client) 
VALUES (10, 'Restaurant Saveurs', 'Puteaux');

INSERT INTO client (id_client, nom_client, ville_client) 
VALUES (11, 'Magasin Sport', 'Nanterre');

INSERT INTO client (id_client, nom_client, ville_client) 
VALUES (12, 'Bijouterie Etoile', 'Paris');

INSERT INTO client (id_client, nom_client, ville_client) 
VALUES (13, 'Pressing Eclair', 'Clichy');

INSERT INTO client (id_client, nom_client, ville_client) 
VALUES (14, 'Animalerie Compagnon', 'Asnieres');

INSERT INTO client (id_client, nom_client, ville_client) 
VALUES (15, 'Papeterie Bureau', 'Colombes');
-- Note : les clients 8, 10, 12, 14 n'ont aucune livraison dans les données
-- → ils apparaîtront dans la requête "Clients sans livraison"


-- ============================================================
-- 6. COEFFICIENTS CO2 (30 entrées : 10 types × 3 années)
-- ============================================================

INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (1, 2024, 0);
INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (1, 2023, 0);
INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (1, 2022, 0);

INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (2, 2024, 0);
INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (2, 2023, 0);
INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (2, 2022, 0);

INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (3, 2024, 180);
INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (3, 2023, 185);
INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (3, 2022, 190);

INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (4, 2024, 0);
INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (4, 2023, 0);
INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (4, 2022, 0);

INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (5, 2024, 95);
INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (5, 2023, 100);
INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (5, 2022, 105);

INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (6, 2024, 120);
INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (6, 2023, 125);
INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (6, 2022, 130);

INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (7, 2024, 0);
INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (7, 2023, 0);
INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (7, 2022, 0);

INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (8, 2024, 0);
INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (8, 2023, 0);
INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (8, 2022, 0);

INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (9, 2024, 0);
INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (9, 2023, 0);
INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (9, 2022, 0);

INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (10, 2024, 140);
INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (10, 2023, 145);
INSERT INTO coefficientCO2 (id_type_vehicule, annee, co2_g_km) VALUES (10, 2022, 150);


-- ============================================================
-- 7. LIVREURS (12 livreurs)
-- ============================================================

INSERT INTO Livreur (id_livreur, nom_livreur, prenom_livreur, date_embauche) 
VALUES (1, 'Dupont', 'Jean', '2022-01-10');

INSERT INTO Livreur (id_livreur, nom_livreur, prenom_livreur, date_embauche) 
VALUES (2, 'Martin', 'Sophie', '2022-03-15');

INSERT INTO Livreur (id_livreur, nom_livreur, prenom_livreur, date_embauche) 
VALUES (3, 'Bernard', 'Luc', '2022-06-01');

INSERT INTO Livreur (id_livreur, nom_livreur, prenom_livreur, date_embauche) 
VALUES (4, 'Petit', 'Marie', '2022-09-12');

INSERT INTO Livreur (id_livreur, nom_livreur, prenom_livreur, date_embauche) 
VALUES (5, 'Dubois', 'Thomas', '2023-01-20');

INSERT INTO Livreur (id_livreur, nom_livreur, prenom_livreur, date_embauche) 
VALUES (6, 'Leroy', 'Julie', '2023-02-14');

INSERT INTO Livreur (id_livreur, nom_livreur, prenom_livreur, date_embauche) 
VALUES (7, 'Moreau', 'Pierre', '2023-04-05');

INSERT INTO Livreur (id_livreur, nom_livreur, prenom_livreur, date_embauche) 
VALUES (8, 'Simon', 'Claire', '2023-06-18');

INSERT INTO Livreur (id_livreur, nom_livreur, prenom_livreur, date_embauche) 
VALUES (9, 'Laurent', 'Marc', '2023-08-22');

INSERT INTO Livreur (id_livreur, nom_livreur, prenom_livreur, date_embauche) 
VALUES (10, 'Lefebvre', 'Emma', '2023-10-10');

INSERT INTO Livreur (id_livreur, nom_livreur, prenom_livreur, date_embauche) 
VALUES (11, 'Michel', 'Alexandre', '2023-11-15');

INSERT INTO Livreur (id_livreur, nom_livreur, prenom_livreur, date_embauche) 
VALUES (12, 'Garcia', 'Léa', '2024-01-08');

-- ============================================================
-- 8. TOURNÉES (14 tournées)
-- Dépend de : livreur (id_livreur) et vehicule (id_vehicule)
-- ============================================================

INSERT INTO tournee (id_tournee, date_tournee, id_livreur, id_vehicule) 
VALUES (1, '2024-01-06', 1, 1);

INSERT INTO tournee (id_tournee, date_tournee, id_livreur, id_vehicule) 
VALUES (2, '2024-01-09', 2, 2);

INSERT INTO tournee (id_tournee, date_tournee, id_livreur, id_vehicule) 
VALUES (3, '2024-01-13', 3, 3);

INSERT INTO tournee (id_tournee, date_tournee, id_livreur, id_vehicule) 
VALUES (4, '2024-01-16', 4, 4);

INSERT INTO tournee (id_tournee, date_tournee, id_livreur, id_vehicule) 
VALUES (5, '2024-01-19', 5, 5);

INSERT INTO tournee (id_tournee, date_tournee, id_livreur, id_vehicule) 
VALUES (6, '2024-01-23', 6, 6);

INSERT INTO tournee (id_tournee, date_tournee, id_livreur, id_vehicule) 
VALUES (7, '2024-01-26', 7, 7);

INSERT INTO tournee (id_tournee, date_tournee, id_livreur, id_vehicule) 
VALUES (8, '2024-02-02', 8, 8);

INSERT INTO tournee (id_tournee, date_tournee, id_livreur, id_vehicule)
VALUES (9, '2024-02-06', 9, 9);

INSERT INTO tournee (id_tournee, date_tournee, id_livreur, id_vehicule) 
VALUES (10, '2024-02-11', 10, 10);

INSERT INTO tournee (id_tournee, date_tournee, id_livreur, id_vehicule) 
VALUES (11, '2024-02-16', 11, 11);

INSERT INTO tournee (id_tournee, date_tournee, id_livreur, id_vehicule) 
VALUES (12, '2024-02-21', 12, 12);

INSERT INTO tournee (id_tournee, date_tournee, id_livreur, id_vehicule) 
VALUES (13, '2024-02-26', 1, 13);

INSERT INTO tournee (id_tournee, date_tournee, id_livreur, id_vehicule) 
VALUES (14, '2024-03-02', 2, 1);



-- ============================================================
-- 9. LIVRAISONS (12 livraisons)
-- ============================================================

INSERT INTO Livraison (id_livraison, date_sortie, poids_total_kg, adresse_complete, nb_colis, id_client, id_tournee)
VALUES (1, '2024-01-06', 120.50, '12 rue de Rivoli, Paris', 5, 1, 1);

INSERT INTO Livraison (id_livraison, date_sortie, poids_total_kg, adresse_complete, nb_colis, id_client, id_tournee) 
VALUES (2, '2024-01-06', 85.75, '45 av Victor Hugo, Boulogne', 3, 2, 1);

INSERT INTO Livraison (id_livraison, date_sortie, poids_total_kg, adresse_complete, nb_colis, id_client, id_tournee)
VALUES (3, '2024-01-09', 40.00, '8 bd des Champs, Versailles', 2, 3, 2);

INSERT INTO Livraison (id_livraison, date_sortie, poids_total_kg, adresse_complete, nb_colis, id_client, id_tournee) 
VALUES (4, '2024-01-13', 200.00, '30 rue du Louvre, Paris', 8, 5, 3);

INSERT INTO Livraison (id_livraison, date_sortie, poids_total_kg, adresse_complete, nb_colis, id_client, id_tournee) 
VALUES (5, '2024-01-13', 150.25, '15 av de Neuilly, Neuilly', 6, 6, 3);

INSERT INTO Livraison (id_livraison, date_sortie, poids_total_kg, adresse_complete, nb_colis, id_client, id_tournee) 
VALUES (6, '2024-01-16', 35.80, '7 pl de la Mairie, Saint-Cloud', 2, 7, 4);

INSERT INTO Livraison (id_livraison, date_sortie, poids_total_kg, adresse_complete, nb_colis, id_client, id_tournee) 
VALUES (7, '2024-01-19', 95.40, '33 bd de la République, Courbevoie', 5, 9, 5);

INSERT INTO Livraison (id_livraison, date_sortie, poids_total_kg, adresse_complete, nb_colis, id_client, id_tournee) 
VALUES (8, '2024-01-23', 175.90, '50 quai de Dion Bouton, Puteaux', 7, 11, 6);

INSERT INTO Livraison (id_livraison, date_sortie, poids_total_kg, adresse_complete, nb_colis, id_client, id_tournee) 
VALUES (9, '2024-01-26', 45.75, '9 av des Champs, Paris', 2, 13, 7);

INSERT INTO Livraison (id_livraison, date_sortie, poids_total_kg, adresse_complete, nb_colis, id_client, id_tournee) 
VALUES (10, '2024-02-02', 135.50, '19 rue de la Gare, Asnières', 6, 15, 8);

INSERT INTO Livraison (id_livraison, date_sortie, poids_total_kg, adresse_complete, nb_colis, id_client, id_tournee) 
VALUES (11, '2024-02-06', 220.00, '28 rue de la Paix, Paris', 9, 2, 9);

INSERT INTO Livraison (id_livraison, date_sortie, poids_total_kg, adresse_complete, nb_colis, id_client, id_tournee) 
VALUES (12, '2024-02-11', 78.90, '5 rue du Marché, Versailles', 3, 4, 10);

-- ============================================================
-- 10. TABLE DE LIAISON APPROVISIONNER (14 relations)
-- ============================================================

INSERT INTO approvisionner (id_entree, id_tournee) VALUES (1, 1);
INSERT INTO approvisionner (id_entree, id_tournee) VALUES (2, 2);
INSERT INTO approvisionner (id_entree, id_tournee) VALUES (3, 3);
INSERT INTO approvisionner (id_entree, id_tournee) VALUES (4, 4);
INSERT INTO approvisionner (id_entree, id_tournee) VALUES (5, 5);
INSERT INTO approvisionner (id_entree, id_tournee) VALUES (6, 6);
INSERT INTO approvisionner (id_entree, id_tournee) VALUES (7, 7);
INSERT INTO approvisionner (id_entree, id_tournee) VALUES (8, 8);
INSERT INTO approvisionner (id_entree, id_tournee) VALUES (9, 9);
INSERT INTO approvisionner (id_entree, id_tournee) VALUES (10, 10);
INSERT INTO approvisionner (id_entree, id_tournee) VALUES (11, 11);
INSERT INTO approvisionner (id_entree, id_tournee) VALUES (12, 12);
INSERT INTO approvisionner (id_entree, id_tournee) VALUES (13, 13);
INSERT INTO approvisionner (id_entree, id_tournee) VALUES (14, 14);

INSERT INTO requetes_sql (NOM, CODE_SQL) VALUES
('Livraisons par livreur',
"SELECT CONCAT(l.prenom_livreur,' ',l.nom_livreur) AS livreur,
        COUNT(liv.id_livraison) AS nb_livraisons
 FROM livreur l
 LEFT JOIN tournee t ON l.id_livreur=t.id_livreur
 LEFT JOIN livraison liv ON t.id_tournee=liv.id_tournee
 GROUP BY l.id_livreur
 ORDER BY nb_livraisons DESC");

INSERT INTO requetes_sql (NOM, CODE_SQL) VALUES
('Vehicules utilises >= 2 fois',
"SELECT tv.nom_type_vehicule, COUNT(t.id_tournee) AS nb_fois
 FROM vehicule v
 JOIN type_vehicule tv ON v.id_type_vehicule=tv.id_type_vehicule
 LEFT JOIN tournee t ON v.id_vehicule=t.id_vehicule
 GROUP BY v.id_vehicule, tv.nom_type_vehicule
 HAVING COUNT(t.id_tournee) >= 2");

 INSERT INTO requetes_sql (NOM, CODE_SQL) VALUES
('Clients sans livraison',
"SELECT c.nom_client, c.ville_client
 FROM client c
 LEFT JOIN livraison liv ON c.id_client=liv.id_client
 WHERE liv.id_livraison IS NULL");

INSERT INTO requetes_sql (NOM, CODE_SQL) VALUES
('Entrees par partenaire',
"SELECT p.nom_partenaire,
        COUNT(e.id_entree) AS nb_entrees,
        SUM(e.quantite_colis) AS total_colis
 FROM partenaire p
 LEFT JOIN entree e ON p.id_partenaire=e.id_partenaire
 GROUP BY p.id_partenaire
 ORDER BY total_colis DESC");

 INSERT INTO requetes_sql (NOM, CODE_SQL) VALUES
('Top 3 villes',
"SELECT c.ville_client, COUNT(liv.id_livraison) AS nb_livraisons
 FROM client c
 JOIN livraison liv ON c.id_client=liv.id_client
 GROUP BY c.ville_client
 ORDER BY nb_livraisons DESC
 LIMIT 3");

 INSERT INTO requetes_sql (NOM, CODE_SQL) VALUES
('Tournees par mois',
"SELECT DATE_FORMAT(date_tournee,'%Y-%m') AS mois,
        COUNT(*) AS nb_tournees
 FROM tournee
 GROUP BY DATE_FORMAT(date_tournee,'%Y-%m')
 ORDER BY mois");

 INSERT INTO requetes_sql (NOM, CODE_SQL) VALUES
('Emissions CO2 par tournee',
"SELECT t.id_tournee, t.date_tournee,
        CONCAT(l.prenom_livreur,' ',l.nom_livreur) AS livreur,
        tv.nom_type_vehicule, c.co2_g_km
 FROM tournee t
 JOIN livreur l ON t.id_livreur=l.id_livreur
 JOIN vehicule v ON t.id_vehicule=v.id_vehicule
 JOIN type_vehicule tv ON v.id_type_vehicule=tv.id_type_vehicule
 JOIN coefficientCO2 c ON tv.id_type_vehicule=c.id_type_vehicule
 WHERE c.annee=2024");

INSERT INTO requetes_sql (NOM, CODE_SQL) VALUES
('CO2 moyen par type vehicule',
"SELECT tv.nom_type_vehicule,
        COUNT(t.id_tournee) AS nb_tournees,
        AVG(c.co2_g_km) AS co2_moyen
 FROM type_vehicule tv
 JOIN coefficientCO2 c ON tv.id_type_vehicule=c.id_type_vehicule
 LEFT JOIN vehicule v ON tv.id_type_vehicule=v.id_type_vehicule
 LEFT JOIN tournee t ON v.id_vehicule=t.id_vehicule
 GROUP BY tv.id_type_vehicule");

 INSERT INTO requetes_sql (NOM, CODE_SQL) VALUES
('Livreurs sans tournee',
"SELECT CONCAT(l.prenom_livreur,' ',l.nom_livreur) AS livreur
 FROM livreur l
 LEFT JOIN tournee t ON l.id_livreur=t.id_livreur
 WHERE t.id_tournee IS NULL");

 INSERT INTO requetes_sql (NOM, CODE_SQL) VALUES
('Livraisons avec poids manquant',
"SELECT liv.id_livraison, c.nom_client, liv.nb_colis, liv.poids_total_kg
 FROM livraison liv
 JOIN client c ON liv.id_client=c.id_client
 WHERE liv.poids_total_kg IS NULL");