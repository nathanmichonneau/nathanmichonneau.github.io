#Les requetes SQL


INSERT INTO requetes_sql (NOM, CODE_SQL) VALUES
('Livraisons par livreur',
"SELECT CONCAT(l.prenom_livreur,' ',l.nom_livreur) AS livreur,
        COUNT(liv.id_livraison) AS nb_livraisons
 FROM livreur l
 LEFT JOIN tournee t ON l.id_livreur=t.id_livreur
 LEFT JOIN livraison liv ON t.id_tournee=liv.id_tournee
 GROUP BY l.id_livreur
 ORDER BY nb_livraisons DESC");

INSERT INTO requetes_sql (NOM, CODE_SQL) VALUES
('Vehicules utilises >= 2 fois',
"SELECT tv.nom_type_vehicule, COUNT(t.id_tournee) AS nb_fois
 FROM vehicule v
 JOIN type_vehicule tv ON v.id_type_vehicule=tv.id_type_vehicule
 LEFT JOIN tournee t ON v.id_vehicule=t.id_vehicule
 GROUP BY v.id_vehicule, tv.nom_type_vehicule
 HAVING COUNT(t.id_tournee) >= 2");

 INSERT INTO requetes_sql (NOM, CODE_SQL) VALUES
('Clients sans livraison',
"SELECT c.nom_client, c.ville_client
 FROM client c
 LEFT JOIN livraison liv ON c.id_client=liv.id_client
 WHERE liv.id_livraison IS NULL");

INSERT INTO requetes_sql (NOM, CODE_SQL) VALUES
('Entrees par partenaire',
"SELECT p.nom_partenaire,
        COUNT(e.id_entree) AS nb_entrees,
        SUM(e.quantite_colis) AS total_colis
 FROM partenaire p
 LEFT JOIN entree e ON p.id_partenaire=e.id_partenaire
 GROUP BY p.id_partenaire
 ORDER BY total_colis DESC");

 INSERT INTO requetes_sql (NOM, CODE_SQL) VALUES
('Top 3 villes',
"SELECT c.ville_client, COUNT(liv.id_livraison) AS nb_livraisons
 FROM client c
 JOIN livraison liv ON c.id_client=liv.id_client
 GROUP BY c.ville_client
 ORDER BY nb_livraisons DESC
 LIMIT 3");

 INSERT INTO requetes_sql (NOM, CODE_SQL) VALUES
('Tournees par mois',
"SELECT DATE_FORMAT(date_tournee,'%Y-%m') AS mois,
        COUNT(*) AS nb_tournees
 FROM tournee
 GROUP BY DATE_FORMAT(date_tournee,'%Y-%m')
 ORDER BY mois");

 INSERT INTO requetes_sql (NOM, CODE_SQL) VALUES
('Emissions CO2 par tournee',
"SELECT t.id_tournee, t.date_tournee,
        CONCAT(l.prenom_livreur,' ',l.nom_livreur) AS livreur,
        tv.nom_type_vehicule, c.co2_g_km
 FROM tournee t
 JOIN livreur l ON t.id_livreur=l.id_livreur
 JOIN vehicule v ON t.id_vehicule=v.id_vehicule
 JOIN type_vehicule tv ON v.id_type_vehicule=tv.id_type_vehicule
 JOIN coefficientCO2 c ON tv.id_type_vehicule=c.id_type_vehicule
 WHERE c.annee=2024");

INSERT INTO requetes_sql (NOM, CODE_SQL) VALUES
('CO2 moyen par type vehicule',
"SELECT tv.nom_type_vehicule,
        COUNT(t.id_tournee) AS nb_tournees,
        AVG(c.co2_g_km) AS co2_moyen
 FROM type_vehicule tv
 JOIN coefficientCO2 c ON tv.id_type_vehicule=c.id_type_vehicule
 LEFT JOIN vehicule v ON tv.id_type_vehicule=v.id_type_vehicule
 LEFT JOIN tournee t ON v.id_vehicule=t.id_vehicule
 GROUP BY tv.id_type_vehicule");

 INSERT INTO requetes_sql (NOM, CODE_SQL) VALUES
('Livreurs sans tournee',
"SELECT CONCAT(l.prenom_livreur,' ',l.nom_livreur) AS livreur
 FROM livreur l
 LEFT JOIN tournee t ON l.id_livreur=t.id_livreur
 WHERE t.id_tournee IS NULL");

 INSERT INTO requetes_sql (NOM, CODE_SQL) VALUES
('Livraisons avec poids manquant',
"SELECT liv.id_livraison, c.nom_client, liv.nb_colis, liv.poids_total_kg
 FROM livraison liv
 JOIN client c ON liv.id_client=c.id_client
 WHERE liv.poids_total_kg IS NULL");