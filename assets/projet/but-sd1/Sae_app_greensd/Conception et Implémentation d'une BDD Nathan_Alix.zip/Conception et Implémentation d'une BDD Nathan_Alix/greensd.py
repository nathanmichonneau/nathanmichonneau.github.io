# -*- coding: utf-8 -*-
"""
Créateur: Alix Gouriet et Nathan MICHONNEAU
nettoyer CSV GreenSD - Version 6
"""

import csv        # importe les ressources nécessaires pour lire les fichiers csv
import os         # importe les ressources pour gérer les chemins de fichiers
from datetime import datetime  # importe le nécessaire pour les dates
import re         # importe les ressources pour manipuler les chaînes de caractères
import subprocess, sys  # importe les fonctions liés à des subs pour les exécuter par exemple
import json
# pip install mysql-connector-python
import mysql.connector

# ============================================================
# CHEMINS DES FICHIERS
# ============================================================

# On récupère le dossier où se trouve CE script Python
# Cela fonctionne peu importe depuis où le script est lancé (GreenSD, terminal, etc.)
DOSSIER_SCRIPT = os.path.dirname(os.path.abspath(__file__))

# On construit le chemin complet vers chaque fichier dont on a besoin
# os.path.join colle le dossier et le nom du fichier avec le bon séparateur (\ ou /)
CHEMIN_CONFIG     = os.path.join(DOSSIER_SCRIPT, "greensd_config.json")

# On ouvre et on lit le fichier JSON avec le chemin complet
with open(CHEMIN_CONFIG, "r") as f:
    config = json.load(f)  # json.load transforme le fichier JSON en dictionnaire Python

# On récupère le nom de la base de données depuis le dictionnaire
nom_base = config["last_database"]

# On se connecte avec le nom de la base récupéré depuis le JSON
db = mysql.connector.connect(
    host="127.0.0.1",
    user="root",
    password="",
    database=nom_base  # on utilise la valeur du JSON au lieu d'écrire en dur
)

curseur = db.cursor()  # Le curseur permet d'envoyer des requêtes SQL

print("Connexion OK !")
print("")


def nettoyer(texte):
    # Enlève les espaces inutiles et corrige les accents mal encodés.
    if texte is None: 
        return ""

    texte = texte.strip() # Enlève les espaces gauche et droite
    # Corrige les accents courants mal lus 
    texte = texte.replace("\xf4", "o")  # ô → o
    texte = texte.replace("\xe8", "e")  # è → e
    texte = texte.replace("\xe9", "e")  # é → e
    texte = texte.replace("\xe0", "a")  # à → a
    texte = texte.replace("\xea", "e")  # ê → e
    texte = texte.replace("\xe7", "c")  # ç → c
    texte = texte.replace("\xfb", "u")  # û → u
    texte = texte.replace("\xf9", "u")  # ù → u
    return texte


def cle_simple(texte): 
    # Crée une clé de comparaison très simplifiée depuis un texte.
    # Enlève espaces, tirets, underscores et met tout en minuscules.
    texte = nettoyer(texte).lower() # met en minuscule 
    for caractere in [" ", "_", "-", ".", "'"]: 
        texte = texte.replace(caractere, "")  
    return texte


def convertir_date(date_texte):
    
    # Converti JJ/MM/AAAA en AAAA-MM-JJ
    # Retourne None si la valeur est vide ou pas bonne
    date_texte = nettoyer(date_texte) # utilise la fonction nettoyer pour faire une date propre et conforme
    if date_texte == "": 
        return None
    parties = date_texte.split("/") # sépare la chaine au niveau des / et les met dans une liste 
    if len(parties) != 3:
        return None
    return parties[2] + "-" + parties[1] + "-" + parties[0] # remet la liste en str et met des tirets entre chaquer partie 


def extraire_poids(texte):
    texte = nettoyer(texte) # On nettoie le texte à l'aide de la fonction existante 
    texte = texte.replace("kg", "") 
    texte = texte.replace(",", ".") 
    if texte == "":
        return None 
    try:
        # Essaie de convertir en nombre décimal à partir du str du dessus
        return float(texte)
    except:
        # si le float ne marche pas on retourne none 
        return None

def normaliser_vehicule(nom):
    # Ramène tous les noms de véhicules à 3 valeurs
    nom = nettoyer(nom) # toujours à l'aide de notre fonction on nettoie le nom en propre 
    nom = nom.lower()
    nom = nom.replace("-", "")
    nom = nom.replace(" ", "")

    if "utilitaire" in nom or "elec" in nom: 
        return "Utilitaire electrique"
    elif "velo" in nom or "cargo" in nom:
        return "Velo cargo"
    elif "tri" in nom:
        return "Triporteur"
    else:
        return nettoyer(nom)

def lire_csv(nom_fichier):
    nom_fichier = os.path.join(DOSSIER_SCRIPT, nom_fichier)
    try:
        # On ouvre juste pour tester, puis on referme
        f_test = open(nom_fichier, "r", encoding="latin-1")
        f_test.close()
    except:
        print("ERREUR FICHIER")
    lignes = []
    f = open(nom_fichier, "r", encoding="latin-1")
    lecteur = csv.DictReader(f, delimiter=";") # DictReader sert à transformer chaque ligne en dictionnaire et utilise la 1ère comme clé de celui ci, ; est le délimiteur utilisé
    lignes = []
    for ligne in lecteur:
        ligne_propre = {} 
        for nom_colonne, valeur in ligne.items():
            if nom_colonne is not None:
                nom_colonne = nom_colonne.strip() # strip sert à supprimer les espaces inutiles dans sur les en têtes
                ligne_propre[nom_colonne] = valeur # ajoute la clé et la valeur nettoyée dans la ligne propre 
        lignes.append(ligne_propre)  # ligne propre ajoutée dans le dictionnaire
    return lignes

def trouver_dans_dict(dictionnaire, texte_cherche):
    # Cherche dans un dictionnaire par clé simplifiée.
    cle = cle_simple(texte_cherche) # à l'aide de notre fonction du haut on transforme notre clé de base en clé simplifiée 
    if cle in dictionnaire: # On essaie quand même de trouver la clé via la correspondance exacte 
        return dictionnaire[cle]

    for cle_connue, valeur in dictionnaire.items(): # On essaie si la correspondance marche pas de faire via un bout de soit la clé de base soit la clé simplifiée 
        if cle_connue in cle or cle in cle_connue:
            return valeur

    return None


# 1. IMPORTER LES PARTENAIRES 



partenaires_ids = {} # Creation du dictionnaire, pour mémoriser les partenaires sans doublons 
for ligne in lire_csv("partenaire.csv"): # pour chaque ligne, sachant que chaque ligne est un dictionnaire qui contient une valeur  
    nom   = nettoyer(ligne.get("nomPartenaire", "")) # à l'aide de notre fonction nettoyer on enlève les espaces et les accents, de plus on récupère les valeurs du partenaire  
    ville = nettoyer(ligne.get("ville", "")) # pareil pour la fonction nettoyer mais ce coup ci on récupère la ville du Partenaire 

    if not nom : # si nom est vide après le nettoyage alors on passe cette étape 
        pass  
    else :
        cle = cle_simple(nom) # sinon on transforme notre clé en clé simplifiée 

    if cle in partenaires_ids: # on vérifie si notre clé est déjà dans le dictionnaire 
        print("  Doublon ignoré :", nom) 
    else :
        curseur.execute( "INSERT INTO partenaire (nom_partenaire, ville_partenaire) VALUES (%s, %s)",(nom, ville))# cela exécute la requète sql pour insérer le partenaire dans notre base. Les %s sont des valeurs qui vont être afféctée correspondant à pour le 1er %s le nom et le deuxième la ville
        partenaires_ids[cle] = curseur.lastrowid  # la clé de notre partenaire se revient attribuer avec la clé simplifée l'id généré par SQL, on le récupère via lastrowid. 
        print("  Ajouté :", nom, "/", ville) 

db.commit() # cela permet de valider officiellement les insertions que nous venons de faire 
print("  Total insérés :", len(partenaires_ids), "| Lignes insérées :", curseur.rowcount) # affiche à lutilisateur le nombre de partenaire inséré visiuelement, et le nombre que SQL en à réellement reçu, cela sert à vérifier que tout s'est bien passé et que toutes les lignes sont bien insérées.

# 2. IMPORTER LES VEHICULES ET LES LIVREURS

# création de 3 dictionnaires 
types_vehicules_ids = {}
vehicules_ids = {}
livreurs_ids = {}

for ligne in lire_csv("vehicule_livreur.csv"): # pour chaque ligne qui est chacune un dictionnaire 
    
    # VEHICULE : si la ligne a type + autonomie + capacite
    type_v = nettoyer(ligne.get("typeVeh", "")) # comme à chaque fois on reprend notre fonction nettoyer pour enlever les caractères inutiles, et on assigne à type_v notre valeur de notre ficher
    auto = nettoyer(ligne.get("autonomie", "")) # comme à chaque fois on reprend notre fonction nettoyer pour enlever les caractères inutiles, et on assigne à auto notre valeur de notre ficher
    capa = nettoyer(ligne.get("capacite", "")) # comme à chaque fois on reprend notre fonction nettoyer pour enlever les caractères inutiles, et on assigne à capa notre valeur de notre ficher
    
    if type_v != "" and auto != "" and capa != "": # vérification que les 3 valeurs sont bien remplies
        type_nom = normaliser_vehicule(type_v) # à l'aide de notre fonction normaliser_véhicule on remplace 
        autonomie = int(auto) # on s'assure que la valeur associée à autonomie est bien un int 
        capacite = int(capa) # on s'assure que la valeur associée à capacité est bien un int
        
        # Ajouter le type s'il est nouveau
        if type_nom not in types_vehicules_ids: # on vérifie si ce type de véhicule à déjà été traité, si c'est le cas on saute tout 
            curseur.execute("SELECT id_type_vehicule FROM type_vehicule WHERE nom_type_vehicule = %s",(type_nom,)) # cela exécute la requète sql, ici un select. Le type nom à la fin, signifie la valeur que %s va prendre est celle correspondante au type nom. 
            resultat = curseur.fetchone() # .fetchone signifie que le resultat va être assigné à une seule ligne du résultat de la requête 
            
            if resultat: # vérifie le résultat du .fetchone s'il n'y a rien : None, alors on passe 
                types_vehicules_ids[type_nom] = resultat[0]  
            else:
                curseur.execute("INSERT INTO type_vehicule (nom_type_vehicule) VALUES (%s)",(type_nom,))
                types_vehicules_ids[type_nom] = curseur.lastrowid
        
        # Ajouter le vehicule
        cle = type_nom + "_" + str(autonomie) + "_" + str(capacite)
        
        if cle not in vehicules_ids:
            curseur.execute(
                "INSERT INTO vehicule (autonomie_km, capacite_kg, id_type_vehicule) VALUES (%s, %s, %s)",
                (autonomie, capacite, types_vehicules_ids[type_nom])
            )
            vehicules_ids[cle] = curseur.lastrowid
            print("  +", type_nom)
    
    # LIVREUR : si la ligne a nom + prenom + date
    nom = nettoyer(ligne.get("nomLivreur", ""))
    prenom = nettoyer(ligne.get("prenomLivreur", ""))
    date = nettoyer(ligne.get("dateEmbauche", ""))
    
    if nom != "" and prenom != "" and date != "":
        date_mysql = convertir_date(date)
        cle = cle_simple(nom)
        
        if cle not in livreurs_ids:
            curseur.execute(
                "INSERT INTO livreur (nom_livreur, prenom_livreur, date_embauche) VALUES (%s, %s, %s)",
                (nom, prenom, date_mysql)
            )
            livreurs_ids[cle] = curseur.lastrowid
            print("  +", prenom, nom)

db.commit()
print("OK -", len(vehicules_ids), "vehicules,", len(livreurs_ids), "livreurs")

# 3. IMPORTER LES TOURNEES

tournees_ids = {} # Dictionnaire pour mémoriser les tournées déjà insérées sans doublons

for ligne in lire_csv("tournee.csv"): # Pour chaque ligne du CSV, chaque ligne est un dictionnaire

    # On récupère et nettoie toutes les valeurs de la ligne
    date     = nettoyer(ligne.get("dateTour", ""))   # On récupère et nettoie la date de la tournée
    type_v   = nettoyer(ligne.get("vehicule", ""))   # On récupère et nettoie le type de véhicule
    auto     = nettoyer(ligne.get("autonomie", ""))  # On récupère et nettoie l'autonomie
    capa     = nettoyer(ligne.get("capacite", ""))   # On récupère et nettoie la capacité
    livreur  = nettoyer(ligne.get("livreur", ""))    # On récupère et nettoie le nom du livreur

    if date == "" or type_v == "" or livreur == "": # On vérifie que les valeurs essentielles sont bien remplies
        continue # Si une valeur est vide on passe à la ligne suivante

    date_mysql = convertir_date(date) # On convertit la date en format MySQL AAAA-MM-JJ

    # On retrouve l'ID du véhicule dans notre dictionnaire vehicules_ids
    type_nom  = normaliser_vehicule(type_v) # On normalise le nom du véhicule
    autonomie = int(auto) if auto != "" else 0 # On convertit l'autonomie en entier, 0 si vide
    capacite  = int(capa) if capa != "" else 0 # On convertit la capacité en entier, 0 si vide
    cle_veh   = type_nom + "_" + str(autonomie) + "_" + str(capacite) # On recrée la clé du véhicule comme on l'a fait avant
    id_vehicule = vehicules_ids.get(cle_veh) # On cherche l'ID du véhicule dans le dictionnaire

    # On retrouve l'ID du livreur dans notre dictionnaire livreurs_ids
    cle_livreur = cle_simple(livreur) # On simplifie le nom du livreur
    id_livreur  = livreurs_ids.get(cle_livreur) # On cherche l'ID du livreur dans le dictionnaire

    if id_vehicule is None or id_livreur is None: # Si on ne trouve pas le véhicule ou le livreur on passe
        print("  IGNORÉ (véhicule ou livreur introuvable) :", date, livreur)
        continue

    cle = date + "_" + cle_livreur # On crée une clé unique pour cette tournée

    if cle not in tournees_ids: # Si cette tournée n'a pas encore été insérée
        curseur.execute(
            "INSERT INTO tournee (date_tournee, id_vehicule, id_livreur) VALUES (%s, %s, %s)", # On insère la tournée
            (date_mysql, id_vehicule, id_livreur) # Les %s sont remplacés par date, id_vehicule et id_livreur
        )
        tournees_ids[cle] = curseur.lastrowid # On sauvegarde l'ID auto généré par MySQL
        print("  + Tournée :", date, "/", livreur)
    else:
        print("  Doublon ignoré :", date, "/", livreur) # On signale le doublon

db.commit() # On valide définitivement toutes les insertions
print("OK -", len(tournees_ids), "tournees insérées") # On affiche le bilan final

# 4. IMPORTER LES ENTREES

entrees_ids = {} # Dictionnaire pour mémoriser les entrées déjà insérées sans doublons

for ligne in lire_csv("entree.csv"): # Pour chaque ligne du CSV, chaque ligne est un dictionnaire

    date       = nettoyer(ligne.get("date_entree", ""))      # On récupère et nettoie la date d'entrée
    quantite   = nettoyer(ligne.get("quantite colis", ""))   # On récupère et nettoie la quantité de colis
    partenaire = nettoyer(ligne.get("partenaire", ""))       # On récupère et nettoie le nom du partenaire

    if date == "" or quantite == "" or partenaire == "":  # On vérifie que les trois valeurs sont bien remplies
        continue # Si une valeur est vide on passe à la ligne suivante

    date_mysql = convertir_date(date) # On convertit la date en format MySQL AAAA-MM-JJ
    quantite   = int(quantite)        # On convertit la quantité en nombre entier

    # On retrouve l'ID du partenaire dans notre dictionnaire partenaires_ids
    id_partenaire = trouver_dans_dict(partenaires_ids, partenaire) # On cherche l'ID via notre fonction de recherche flexible

    if id_partenaire is None: # Si on ne trouve pas le partenaire on passe
        print("  IGNORÉ (partenaire introuvable) :", partenaire)
        continue

    cle = date + "_" + cle_simple(partenaire) # On crée une clé unique pour cette entrée

    if cle not in entrees_ids: # Si cette entrée n'a pas encore été insérée
        curseur.execute(
            "INSERT INTO entree (date_entree, quantite_colis, id_partenaire) VALUES (%s, %s, %s)", # On insère l'entrée
            (date_mysql, quantite, id_partenaire) # Les %s sont remplacés par date, quantite et id_partenaire
        )
        entrees_ids[cle] = curseur.lastrowid # On sauvegarde l'ID auto généré par MySQL
        print("  + Entrée :", date, "/", partenaire, "/", quantite, "colis")
    else:
        print("  Doublon ignoré :", date, "/", partenaire) # On signale le doublon

db.commit() # On valide définitivement toutes les insertions
print("OK -", len(entrees_ids), "entrees insérées") # On affiche le bilan final


# 5. IMPORTER LES LIVRAISONS

livraisons_ids = {} # Dictionnaire pour mémoriser les livraisons déjà insérées sans doublons
clients_ids    = {} # Dictionnaire pour mémoriser les clients déjà insérés sans doublons

for ligne in lire_csv("livraison.csv"): # Pour chaque ligne du CSV, chaque ligne est un dictionnaire

    # On récupère et nettoie toutes les valeurs de la ligne
    date     = nettoyer(ligne.get("date_sortie", ""))       # On récupère et nettoie la date de sortie
    client   = nettoyer(ligne.get("client", ""))            # On récupère et nettoie le nom du client
    ville    = nettoyer(ligne.get("ville_client", ""))      # On récupère et nettoie la ville du client
    adresse  = nettoyer(ligne.get("adresse_complete", ""))  # On récupère et nettoie l'adresse complète
    nb_colis = nettoyer(ligne.get("nb colis", ""))          # On récupère et nettoie le nombre de colis
    poids    = nettoyer(ligne.get("poids total", ""))       # On récupère et nettoie le poids total
    livreur  = nettoyer(ligne.get("livreur", ""))           # On récupère et nettoie le nom du livreur

    # On vérifie que les valeurs essentielles sont bien remplies
    if date == "" or client == "" or livreur == "":
        continue # Si une valeur manque on passe à la ligne suivante

    # On convertit les valeurs dans le bon format
    date_mysql   = convertir_date(date)                          # Convertit JJ/MM/AAAA en AAAA-MM-JJ
    poids_kg = extraire_poids(poids)  # Enlève "kg" et convertit en float                                  
    nb_colis_int = int(nb_colis) if nb_colis != "" else 0        # Convertit en entier, 0 si vide

    # --- TROUVER L'ID DE LA TOURNÉE ---
    # La tournée a été insérée dans la section 3 avec la clé : date + "_" + cle_simple(livreur)
    # On reconstruit cette même clé pour retrouver l'ID correspondant
    cle_livreur = cle_simple(livreur)          # On simplifie le nom du livreur (minuscules, sans espaces)
    cle_tournee = date + "_" + cle_livreur     # On recrée la clé exacte utilisée dans la section 3

    id_tournee = tournees_ids.get(cle_tournee) # On cherche l'ID de la tournée dans le dictionnaire

    if id_tournee is None: # Si on ne trouve pas la tournée correspondante, on ignore cette livraison
        print("  IGNORÉ (tournée introuvable pour ce livreur/date) :", date, "/", livreur)
        continue

    # --- TROUVER OU CRÉER LE CLIENT ---
    # On crée une clé unique par client avec son nom simplifié + sa ville simplifiée
    # cle_simple met tout en minuscule et enlève les espaces → "Boulangerie du Centre" = "boulangerieducentre"
    # Cela permet de détecter les doublons comme "La Rochelle" et "LaRochelle"
    cle_client = cle_simple(client) + "_" + cle_simple(ville)

    if cle_client not in clients_ids: # Si ce client n'a jamais été inséré
        curseur.execute(
            "INSERT INTO client (nom_client, ville_client) VALUES (%s, %s)",
            (client, ville) # On insère le nom et la ville du client
        )
        clients_ids[cle_client] = curseur.lastrowid # On sauvegarde l'ID généré par MySQL
        print("  + Client :", client, "/", ville)
    else:
        print("  Client déjà connu :", client) # Le client existe déjà, pas besoin de le réinsérer

    id_client = clients_ids[cle_client] # On récupère l'ID du client (qu'il soit nouveau ou existant)

    # --- INSÉRER LA LIVRAISON ---
    # La clé de doublon combine la date + le client simplifié + la ville simplifiée
    # Cela permet de détecter : "Boulangerie du Centre"/"LaRochelle" = "Boulangerie du centre"/"La Rochelle"
    cle = date + "_" + cle_simple(client) + "_" + cle_simple(ville)

    if cle not in livraisons_ids: # Si cette livraison n'a pas encore été insérée
        curseur.execute(
            "INSERT INTO livraison (date_sortie, poids_total_kg, adresse_complete, nb_colis,id_client,id_tournee) "    # On insère avec les bons noms de colonnes du MCD 
            "VALUES (%s, %s, %s, %s, %s, %s)",
            (date_mysql, poids_kg, adresse, nb_colis_int, id_client, id_tournee)
        )
        livraisons_ids[cle] = curseur.lastrowid # On sauvegarde l'ID généré par MySQL
        print("  + Livraison :", date, "/", client, "/", ville)
    else:
        print("  Doublon ignoré :", date, "/", client) # On signale le doublon détecté

db.commit() # On valide définitivement toutes les insertions dans la base
print("OK -", len(livraisons_ids), "livraisons insérées,", len(clients_ids), "clients créés")














